UNACCEPTED CANDIDATE: this archive identifies source only. Approval and runtime outcomes require revision-specific evidence; packaging does not establish acceptance, installation authorization or a stable release. Historical evidence retains its original scope.

# Prax Teach 3.0.2

The complete teacher and compatible teach-pro-max source trees are in skills/.
Keep every supporting file. Core use is explanation first; practice and
persistent learner state require consent.

Install teacher to an explicit agent folder:

    bash skills/teacher/install.sh --dir /path/to/agent/skills

teach-pro-max can also be copied as one whole folder. It uses teacher when
present and its bundled compatibility engine when installed alone.

Full regression orchestration and CI setup require the complete exact Git checkout,
including Git metadata, test utilities and the new-skills mirror. The source ZIP
is not a full-checkout validation environment. run_teacher_regressions.py and
setup_teacher_ci.sh fail explicitly there before tests or dependency setup.
See scripts/TEACHER-CANDIDATE.md in the combined candidate archive.

Python and Node are needed by individual included skill build/check scripts. Browser/video work also needs
Playwright, Chromium and ffmpeg. Optional voices/models are separate setup
steps. No dependency downloads or paid services start merely by extracting.

For untrusted executable examples, use the bundled Docker sandbox instructions:
skills/teacher/skills/explorable/references/SANDBOX.md
A Docker daemon and explicitly provisioned image are required for that mode.

Engineering and runtime evidence has the scope recorded in current delivery receipts.
No subjective listening, learner outcome or perfection claim is made.
Source commit: e97fe5b916095c69401f59dc573bcf2fd628ce04
