UNACCEPTED CANDIDATE: consent-aware evaluator v2 was approved and adopted on 2026-10-24. Three original narrated fresh-container runs pass at 64 tasks/512 MiB; the disclosed independent fixture passes regression after caption repair. Whole-branch review and release decisions remain pending. No installation or stable release is authorized by this archive. Historical evidence retains its original scope.

# Prax Teach 3.0.2

The complete teacher and compatible teach-pro-max source trees are in skills/.
Keep every supporting file. Core use is explanation first; practice and
persistent learner state require consent.

Install teacher to an explicit agent folder:

    bash skills/teacher/install.sh --dir /path/to/agent/skills

teach-pro-max can also be copied as one whole folder. It uses teacher when
present and its bundled compatibility engine when installed alone.

Python and Node are needed by build/check scripts. Browser/video work also needs
Playwright, Chromium and ffmpeg. Optional voices/models are separate setup
steps. No dependency downloads or paid services start merely by extracting.

For untrusted executable examples, use the bundled Docker sandbox instructions:
skills/teacher/skills/explorable/references/SANDBOX.md
A Docker daemon and explicitly provisioned image are required for that mode.

Engineering and runtime evidence has the scope recorded in current delivery receipts.
No subjective listening, learner outcome or perfection claim is made.
Source commit: d8085a4d02bfaadaaf6a799b40b4e9274270be57
