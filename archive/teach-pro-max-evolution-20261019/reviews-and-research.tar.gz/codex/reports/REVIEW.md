# Prax Teach v2: visual production audit

Date: 2026-10-18. Scope: supplied clean-install ZIP, its accepted teacher and implemented runtime, and the neuron course actually delivered in this conversation. Three independent reviews: GPT-6 Astra (skill/policy), GPT-6.1 Sol (course/design), GPT-6 Sol (media capability). Findings are synthesized against files and rendered screenshots. No private holdout bank was accessed. This is an artifact and capability audit, not a measured learner study or a complete controlled multi-model benchmark.

## Verdict

**Both generation failure and skill production gaps.** The neuron course is primarily an execution failure against requirements that already exist: connected explanatory scenes, visible intermediate mechanisms, purposeful controls, claim-linked annotations and useful responsive delivery. The clean skill does not force plain, repetitive lab cards. However, it also does not make excellent production repeatable: art direction is underspecified, its packaged interactive browser binding covers one topic, and video/TTS are guidance and external-tool routes rather than a demonstrated narrated-media pipeline.

A clean installation fixes packaging and canonical entry selection. It does not fix these production weaknesses. The 22 tests can all pass while a generated course is visually poor.

## Baseline and installation checks

- ZIP: `Developer/prax-teach-evaluation-20261016/clean-install-20261018/deliverables/prax-teach-v2-clean-install.zip`.
- ZIP SHA-256: `c4827533185ad7db90aaf3af25edd97f6cf9d3a8b3e868a1b683ef3ba552205f`.
- Accepted source commit: `389f6f9067c40de4ebed10a48d6048ed90d58b0c`.
- Extracted entire archive, including `.engine` and `.verification`, to `../baseline/prax-teach-v2`. All 1,637 manifest-listed files matched hashes; there are 1,638 ZIP entries including the manifest.
- One non-hidden skill entry: root `SKILL.md`. A new live Codex skill-discovery session was not run; this is a filesystem visibility check, not a claim about every host's discovery behavior.
- Ran `configure.py` in a separate `../check-install/prax-teach-v2` copy: configured, all 1,637 files verified, local runtime byte verifier passed, no global configuration changed.
- Restored the documented root, engine and Flint lockfiles with installation scripts disabled. Ran with Node 22.23.3 and Python 3.13.16.
- **22/22 JavaScript tests passed**, zero failures/skips. See `javascript-tests.log`.
- Full engine validator: **passed**, zero errors. See `package-validation.json`. It validates historical receipts; their presence is not a fresh browser or learner study.
- Fresh Answer-now routing returns `answer_now`, `quick`, persistence false. Forced interactive neuron job reports a static bundled fallback, not a compatible delivered neuron runtime. The documented host-authoring route remains available independently.
- Fresh static rendering and artifact validation passed. See `render-validation.json` and `../render-smoke/lesson.html`.
- Active installation still points through `~/.agents/skills/prax-teach-v2` to the existing visual-intuition worktree. The isolated audit did not replace active symlinks or edit the course.

## What failed in my generated course

### 1. The phone layout hides the mechanism

`/Users/prax/Developer/neuron-to-deep-learning/assets/style.css:2` forces SVGs to a minimum 620px within a horizontally scrolling region. `verification/mobile-2.png` shows inputs and sum while the activation and output are off-screen. That defeats simultaneous comparison and breaks the visual chain.

The browser test checked document overflow, not whether the whole relationship was visible in the diagram. It therefore passed the defective experience. Correct response: recompose the diagram vertically or into linked small multiples for narrow screens, retaining an overview and adjacent controls. Horizontal scrolling can remain a deliberate option for a dense technical figure, but cannot be the sole readable view of this simple mechanism.

### 2. The capstone hides the network

`assets/course.js:41` and `verification/trained-network.png` show a probability map, aggregate loss and table. Training jumps 100/500/2,000 steps. The actual 2→4→1 network, hidden activations, weight changes and gradient paths never appear. The user sees success metrics without seeing the mechanism that caused them.

Correct response: show the current network, trace one input through it, expose prediction and loss, then visualize one simultaneous parameter update. Keep the probability map as a complementary result view. A longer training run should be an optional acceleration of a mechanism the learner can already inspect.

### 3. Controls are a dashboard, not a coherent visual experiment

The neuron panel exposes six controls at once with no retained baseline, contribution highlighting, activation-function graph or panel reset. It redraws the current calculation, while the explanatory paragraph below still describes the default state. The learner must mentally compare past/current states and reconcile two examples.

Correct response: begin with one identified relationship, put its control beside the effect, retain an explicit before/after comparison and recompute the nearby explanation from the same authoritative model. Offer deeper controls progressively without withholding the complete model.

### 4. Surface style substitutes for art direction

`assets/make_labs.py:8` reuses a 760×330 generic stage and identical bordered shell across topics. Large fixed empty regions, repeated circles/lines, default sliders and repeated banners make the course feel templated. `.coach` is defined but unused. The biology axon's blocks are not labeled as myelin or any other entity, so their visual meaning is ambiguous.

The chosen paper/ink/blue palette is permitted by the skill. The failure is not that these colors or serif type are intrinsically bad; it is that I copied palette tokens without designing an explanatory visual language, density, hierarchy or transitions for this subject. The user's rejection is direct preference evidence for this artifact, not proof that one universal aesthetic is best.

### 5. Testing was presented too broadly

34 mathematical assertions establish selected toy computations, a few gradients and one fixed-seed convergence run. The 58 control-state count is largely slider endpoints and select options; it does not assert each visual effect against an expected value or inspect every state. Keyboard evidence covers one slider arrow; reduced-motion evidence checks a media-query boolean; no-script evidence checks visible chapters and a text string.

These are useful narrow checks. They do not establish visual quality, comprehensive keyboard operation, motion equivalence or teaching effectiveness. My handoff should have made those limits clearer instead of letting the counts imply a polished experience.

### 6. Entry selection was inconsistent

The conversation used an archived attempt-11 skill attachment for the quiz-first turn, then the current canonical teacher for course production. The clean loader explicitly directs the agent to `.engine/SKILL.md` and forbids loading historical snapshots. Canonical entry resolution matters; the clean current teacher says explanation first. The initial quiz barrier is not evidence that the clean teacher requires quizzes.

## Capability matrix

| Medium | What this clean package actually contains | What remains unproven or missing |
| --- | --- | --- |
| Exact still diagrams/charts | Static Markdown/HTML, linked images, optional Flint SVG adapter, SVG/HTML authoring guidance | Consistently excellent diagram composition, subject-specific visual language, editorial craft and cross-subject reference examples |
| Interactive explanations | Packaged Python floating-point browser lab with stepper, slider and comparison; host-authored browser-native route for other topics | A general subject renderer; neuron-specific mechanism implementation; reliable quality for arbitrary new mechanisms |
| Explanatory animation | Routing, storyboard/timeline/reduced-motion guidance and a motion fixture whose verified delivery is ordered static states | Demonstrated timed visual transformation, pacing and visual causality across representative topics |
| Exported video | Tool registry and production instructions for specialist tools | An exercised, inspectable video production path and actual current video/audio output |
| TTS/narration | Prose mentions of narration, captions and transcripts | Voice selection, pronunciation handling, pacing, synthesis, listening QA, caption generation, sync, audio mix and export |

Local tool availability was checked separately: Manim Community 0.22.0, FFmpeg/ffprobe 9.0.2, macOS `say` voices, browser automation and image generation capabilities are available. This session also exposes connector speech/video tools. Availability is not output quality, account authorization, successful rendering or a listening test. No paid generation was submitted and no video/audio render was claimed.

## Concrete skill gaps

1. **No art-direction acceptance standard.** `ASKTHEMOVE-PRESENTATION.md:7` describes semantic font/color roles. `VISUALIZATION-ROUTER.md:182` asks for a semantic brief. Neither defines how to judge diagram composition, subject-specific visual language, density, contemporary craft or responsive recomposition. Better wording alone will not supply those judgments.
2. **Narrow implemented runtime.** `VISUAL-RUNTIME.md:3` identifies Python floating point as the implemented browser binding. Source-level tests for other domains do not demonstrate their browser delivery. Host-created media is explicitly supported, so limited packaged scope is a dependency on agent capability, not a prohibition.
3. **Media guidance without demonstrated production.** `LEGACY-VISUALIZATION-ROUTER.md:212` has sensible storyboarding, narration/caption and timeline requirements. No generated video/audio/caption files or synthesis/sync/export implementation were found in the inspected package. This is not proof that agents cannot use external tools; it means broad media-production claims need actual demonstrations.
4. **Quality tests are engineering-oriented.** `EVALUATION.md:15` correctly separates validity, policy, engineering, browser, accessibility and learning claims. It does not define an artistic-production tier. Runtime tests inspect determinism, model behavior and source wiring; the policy test also checks text phrases. These cannot reject every ugly but correct result.
5. **The package discloses the media limit itself.** `.verification/ACCEPTANCE.json` lists bounded text/static evaluation and explicitly says generated video/audio were not validated. Historical high teaching scores must not be promoted into proof of universal visual quality.

## Proposed correction, in priority order

This is a concrete proposal, not an applied change or a new acceptance policy.

1. **Prove one excellent mechanism before rebuilding ten chapters.** Produce one polished artificial-neuron explanation, with an immediately readable full view, integrated labels, contribution-level visual encoding, activation graph, controlled comparison and responsive layout. Compare with the rejected artifact and a user-selected visual reference. Let that establish a visual direction rather than extrapolating ten repeated cards.
2. **Make media selection depend on the explanatory job.** Still: structure/comparison. Interaction: inspect causal parameter changes. Animation: reveal transformation or timing. Video/TTS: narrated causal story when that medium helps. Do not force all media into every lesson or call a static state stepper an exported animation.
3. **Prove a short narrated scene end to end.** Use the same neuron model; author a short narration, select an authorized voice, check pronunciation and pacing, synthesize, listen, align a seekable timeline, generate captions/transcript, render and inspect keyframes. Retain editable sources and static equivalent. A successful scene proves that route for that scene, not all future subjects.
4. **Add production guidance as a separately reviewable candidate.** Specify visual brief fields, responsive composition patterns, meaningful control/comparison patterns, storyboarding, TTS/audio QA and export deliverables. Keep package policy, implementation guidance and examples separate. Do not inflate the root skill or build a universal framework.
5. **Evaluate candidate output under a separately approved contract version.** Preserve the original baseline and current accepted skill. Freeze task set, exemplars/quality criteria, budgets, protected paths and stop rules before changing candidate instructions. Keep existing correctness/privacy/assessment constraints. Do not weaken or rewrite accepted evaluators to make a candidate pass. Combine independent rendered critique with real controls and audio/video review; do not claim learning superiority from craft preference.

## What was changed

Only the isolated audit directory, dependency restoration in its check-install copy, smoke artifact and these reports were written. No active skill, course, governing evaluator, identity policy or learner state was changed. Baseline bytes remain available for comparison. No 'world-class' certification is justified by this audit.
