# What the three conversations contribute

## Reading scope and provenance

The two exports were read end to end by dedicated readers: Claude Code has 910 logical lines; Codex has 13,767 lines, six user messages, 30 assistant messages and 199 activity blocks. Repeated manuals, large manifests and minified code in the Codex activity were structurally inspected rather than reread word for word. The Claude export collapses some tool output, so it cannot expose every hidden command result.

The Desktop bridge ID `session_019X3PnGRsDY2WNFxYmXJdAk` resolves through local session metadata to CLI log `ff394d66-ca3e-47d2-830d-06ce3eb04ec0`, an older C/C++ project conversation that later turns to Prax Teach. The reader indexed all 4,112 records before the recursive request, including 254 conversational text blocks, 472 tool calls and 472 tool results; reconstructed the full chronology and read relevant task completions, all 11 question answers, queued human steering and selected underlying evidence. Large embedded manuals, hidden thinking, binary images and repeated metadata were not exhaustively reread, and not all tool-result bytes or subsidiary workflow transcripts were inspected. The session is live. Its newer response to this same cross-session-reading request is excluded from the independent-evidence comparison, while its new WP0 completion is included.

This synthesis also inspected current candidate status, saved logs, the Desktop progress/specification/acceptance documents, current skill symlinks, and four actual C renders. Full test suites and audio listening were not repeated. Source paths and snapshot hashes are recorded in `sources.json`.

## 1. Claude Code export: package audit, routing patch and cross-vendor council

Source: `/Users/prax/.claude/projects/-Users-prax/memory/2026-10-18-105839-local-command-caveatthe-command-below-was-run-d.txt`.

It reviewed the clean ZIP, checked installation/discovery, exercised video/audio request routing, inspected old visual evidence and created an isolated routing candidate. It then ran a four-vendor council: GPT through Codex, Grok, Cursor Composer and Claude Opus, followed by anonymized peer rankings and a chair synthesis. The council brief expressly disabled tools and browsing: these were independent reasoning passes over supplied facts, not four independent artifact audits.

Present outputs include a review, council report, screenshots, logs and an uncommitted 15-file worktree on `candidate/media-routing-20261018`. The candidate adds media vocabulary, narration as a separate layer, speech-tool entries and delivery documentation. It also changes validation and provenance, which is why it needs reworking before acceptance.

The most useful self-critique is that the patch lets edited receipts/test counts define its own completeness expectations. It can detect disagreement among those files, but coordinated edits can satisfy the check without independently preserving the accepted registry. A real current-byte hash check is also needed; merely rewriting a stale digest does not repair the missing validation.

The final transcript reports focused 65-test and 13-registry-test passes. The saved broad Python log contains an earlier 281-test run with one failure, one error and one skip; the validator log lists 60 problems. Many concern stale acceptance receipts, so they are neither proof of an accepted release nor necessarily 60 independent implementation defects. Keep these evidence dates and scopes separate.

Its original next step was to separate the governing-method revision from the routing candidate, then demonstrate real media on a held-out topic. Its old statements that no video/audio had been produced describe the reviewed ZIP, not our later Atlas.

Key evidence: transcript lines 666–697 and 876–910; `~/Developer/prax-teach-evaluation-20261016/review-20261018/council/brief.md`; `candidate-python-tests.log`; `validator-candidate.txt`.

## 2. Codex export: the history of our accepted Neuron Atlas

Source: `/Users/prax/codex-session-01a14ba6-d02a-7180-a198-5047ec3cea8b.md`.

This is our original production history, not a separate external endorsement. It records the obsolete/archived teaching-entry mistake, the rejected ten-chapter course, the audit, CEO/engineering/specification work, the improved single-neuron demonstration, your visual approval and the later recommendation council.

Completed artifacts include six SVGs, six PNGs, an 82.97-second narrated film, the live explorer, optional Q&A/flashcards and pause/explore/return video behavior. Recorded evidence covers 2,736 mathematical checks across 72 cases, actual offline browser behavior and fresh ZIP extraction. The 20 approaches are a researched selection library, not 20 implemented pipelines.

Its candidate skill is only a loader/reference overlay and patch; it is not a complete installable skill. Missing evidence includes subjective narration listening, complete real-time watching, assistive-technology use, physical devices and learner outcomes. The renderer/checklist-validator mismatch remains disclosed. The full course has not been upgraded to the accepted visual standard.

Its next steps were a complete isolated skill candidate, decision boundaries → XOR → hidden layers, and a different subject to test broader reuse. These remain useful; there is no reason to restart the already accepted Atlas.

Key evidence: export lines 5396–5414, 7058–7068, 13368–13383 and 13715–13734; `production-v2/reports/DELIVERY.md`; `production-v2/candidate/CANDIDATE-STATUS.json`.

## 3. Claude Desktop: a C-learning context and a broader lesson-production system

The session originally concerns C/C++ and competitive-programming setup, including the compiler runner/editor workflow and later code review. That explains its strong emphasis on executed C traces and the C workspace's prediction-first teaching contract. The earlier cpx practice engine added verdicts, import/stress tests, prediction drills, revisit logs and editor commands. PRs #2 and #3 were merged on explicit request; later status still listed unchecked findings and deferred work, so merge did not prove review completion. Those are historical reports, not a fresh audit of cpx today. Its recent teaching-skill review begins around JSONL line 3216.

It installed the clean v2 package, ran five reviews reporting 114 findings, cataloged 13–16 approaches per artifact type, and built compiler-backed still/explorer/card/video proofs. The reviews and proofs exist under `~/Developer/prax-teach-evaluation-20261016/clean-install-20261018/review-20261018/`. Findings vary in evidence and severity; their count is not directly comparable to our 48-item inventory.

A particularly valuable discovery: its byte/printf proof passed numerical checks but used misleading same-bits wording around a conversion. The inspected still still contains that wording. The lesson is to test explanatory claims, captions and alt text independently of generated numbers. A shared model can propagate a shared conceptual mistake.

It then completed CEO/engineering planning and a ten-work-package specification for v2.1: routing/protocol, lesson model/capture, stills, explorer/Q&A/cards, narration/video, interactive video, claims review, packaging and exemplars. CEO adversarial review reached 7/10 at its final round; ensuing fixes were recorded as not re-reviewed. 'Planning completed' therefore must not be read as a perfect independent verdict.

The first vertical slice, WP0, is now built: switch fall-through, an exact still, narrated film and interactive video. Current `PROGRESS.md` reports selftest 8/8, agent tests 1/1 and 24/24 slice gates. The saved `build-report.json` reports `verified` and contains the gate results. This synthesis confirms the files/report, not a fresh execution of the suite. The WP0 film is recorded as 53.2 seconds with seven chapters and 11 captions. A separate WP0 code review was launched; no completed outcome for it is claimed here. The full v2.1 system remains unfinished, and its stronger acceptance proposal is still explicitly proposed. The original 72-second proof disclosed telemetry/font-network activity and warnings; the later WP0 reports bundled fonts and render isolation, so do not mix their evidence.

Current symlinks for `.agents`, `.codex`, `.claude` and `.hermes` resolve to `~/.agents/skill-library/prax-teach-v2`. Desktop changed these independently. Our prior 'active skill unchanged' statement was true of our run; it should not be generalized to all concurrent sessions. v2.1 has not replaced the active v2.

Current status: `~/Developer/prax-teach-evaluation-20261016/v2.1/PROGRESS.md`. Governing proposal: `plan/ACCEPTANCE-PROPOSAL.md`. Product: `spec/SPEC.md`. WP0: `lessons/switch-fallthrough/build/`.

## Ideas worth carrying forward

| Idea | Why it helps | How to incorporate it |
| --- | --- | --- |
| Whole-to-part zoom | The C still connects the 32-bit value to one byte and individual place values. | Use a clear scale transition when a hidden detail explains the whole: network → neuron → contribution, for example. |
| Linked representations | Bits, hex, decimal and character update together; relations become visible. | Give every linked view the same authoritative state and explicit conversion labels. Do not imply all representations have identical storage. |
| Controls attached to the diagram | Clicking individual bits has a more direct causal meaning than a generic settings panel. | Prefer manipulating the explanatory object itself, with equivalent keyboard controls. |
| Execution paths and causal margin notes | The switch still puts arrows beside executed code and annotations beside the relevant branch. | Add a restrained annotation/trace vocabulary to the skill. Keep it subject-specific rather than copying the same composition everywhere. |
| Counterfactual comparison | With/without break makes the mechanism visible in the difference. | Preserve a baseline and change one meaningful cause; Atlas already uses this successfully. |
| Independent claim review | Correct numeric outputs did not catch misleading explanation or unsupported alt text. | Review claims against authoritative semantics, then plant false claims to test whether review catches them. Treat model review as fallible. |
| One lesson state, several outputs | Shared trace/state reduces drift among figures, narration, cards and video. | Reuse a small common content/state contract. Expand a general compiler only when multiple lessons demonstrate a need. |
| Narration as an optional layer | A voice request should add speech without discarding the visual explanation. | Preserve the chosen visual medium, audio controls, captions and transcript. |
| Time-indexed explorer states | Desktop adds code/output states tied to the film timeline. | Extend our existing media-clock design for executable traces; spoiler hiding belongs only to explicitly selected prediction/practice modes. |
| Real media measurements | Desktop reports loudness/peak, ASR/caption timing, OCR and contrast checks. | Use these as diagnostic tools; define any new acceptance thresholds separately. They do not replace listening, readability or comprehension judgment. |
| Delivery capability checks | Local-file, HTTP and embedded chat surfaces have different restrictions. | Test the delivery surface actually promised; single-file HTML does not guarantee every chat can execute it. |
| Small runtime, external history | Large archives contain duplicates and old skill entries that can confuse discovery. | Package the live skill/runtime clearly and keep historical evidence outside ordinary discovery, retaining traceability and rollback. |

## What needs a pinch of salt

- Do not add 48 and 114 findings or count overlapping sessions as independent confirmations. They inspect different scopes and include risks/preferences as well as defects.
- Preserve your accepted Atlas aesthetic. The paper-and-ink C compositions are an additional useful visual vocabulary, not a reason to discard it.
- The C workspace's prediction-first instruction is local. It does not justify imposing a quiz barrier on the general explanation-first teacher or this course.
- Correct outputs from two compilers are useful observations, not by themselves proof of defined C behavior. The Desktop outside review identified that limitation too.
- A report saying 'verified' reflects its particular gates. For example, the inspected WP0 report accepts a minimum displayed text size of 11.7px; that alone cannot establish comfortable phone reading.
- WP0 reports five internal claims-review rounds while the frozen run caps implement/review rounds per work package at three. Whether these nested jobs consume the same budget needs explicit accounting; the record does not establish a violation by itself. Schema additions and timing refinements also deserve review against the fixed specification.
- An eight-artifact pilot, mandatory tools, new loudness/ASR thresholds, and a broad lesson compiler are proposals. They are not silently inherited requirements.
- Council votes assess answers built on a shared brief. Their factual premises still need checking; a preferred renderer remains provisional until demonstrated for the particular job.

## Recommended next move

Reconcile the three lines of work without merging their entire designs. Keep Atlas as the accepted visual reference. Review and reuse the narrow media-routing fixes after separating their governing changes. Let Desktop finish and review its C vertical slice; use that as the materially different subject we already wanted rather than commissioning a duplicate. Bring the best specific ideas—claim checking, direct manipulation, causal annotations, counterfactuals and shared state—into the next isolated skill candidate.

Then make the next neuron-course lesson on decision boundaries and XOR. Compare it with the accepted Atlas and the C slice on their actual explanatory jobs. Resolve conflicting teaching protocols explicitly by context, and adopt any new governing acceptance standard only as its own approved version. The current request authorizes reading and synthesis; no skill, course, evaluator or concurrent work was changed during this review.
