# Prax Teach: principal engineering and product audit

Snapshot: 18 October 2026, approximately 23:32 IST. Candidate HEAD `1a1eb968`. Read-only review of product, source, rendered artifacts, raw saved receipts and proposed repair plan. No installation, product changes, new build rounds, paid reviewer runs or sync probes.

## Decision

Keep v2 installed. Preserve v2.1 as a useful but unaccepted development candidate. Do not approve REPAIR-PLAN.md unchanged. The largest gap is the product: a general visual teacher has become a C lesson compiler. Fixing the four examples is necessary evidence, but is not sufficient delivery of the original goal.

## Original goal, restored in plain language

A reusable teacher skill, usable across capable hosts, that explains any subject at the learner's level; builds intuition through accurate, beautiful, mechanism-led visuals; selects suitable available tools; supports stills, exploratory interaction, layered Q&A, cards, narration, video and interactive video; adapts and continues across a lesson or course. Explanation is complete by default. Practice is optional and learner-led. Every medium earns its place by explaining something. Verification supports this product.

This direction is corroborated by the user-confirmed 16 October product note and the current conversation. "World's best" is an ambition, not an objectively established label. Acceptance needs concrete artifact comparisons and transfer examples, without claiming universal coverage from a few demos.

## Evidence and limitations

- Read current skill, schema, teaching protocol, renderer/checker code, all three new decision/repair documents and supporting investigations.
- Three bounded independent reviews covered privacy/state, verification provenance, and product/rendered quality.
- Current git working tree was clean. `git diff 22032c7 HEAD -- package lessons` is empty: product code and lessons match the final-verification base.
- Four installed `prax-teach-v2` links still resolve to `/Users/prax/.agents/skill-library/prax-teach-v2`.
- Recomputed lesson/code identities and artifact inventories through the verification audit. Main build artifacts match their canary receipts. Full-suite receipt artifacts match current artifacts except the four APKG files; do not claim byte identity for those.
- Directly inspected current stills and a recorded video frame through the product review. This audit did not listen to narration or replay every interaction.
- Ran five new read-only router probes and one pure axis-check probe with bytecode disabled. No files were created by these probes.
- Inspected raw retained synthetic privacy-probe files and configured backup-root evidence without exposing learner contents or creating new synced fixtures.
- Did not rerun the entire compiler/media/reviewer suite. Historical tests below are independently reconciled saved results, not fresh test executions.
- The final-verification report itself publishes old holdout prompts. They were encountered while reading the report. No holdout files were opened. That set is now a regression set, not a fresh unseen evaluation.

## Confirmed progress

Reusable work includes shared themes, exact-value capture, fact/claim associations, media projectors, static HTML delivery, narration scheduling, captions/chapters, stable card identifiers, artifact inventories and review provenance. The C compiler is worth retaining as an optional adapter.

Current main-tree reports are `canary-verified`; full-suite results are failed for all four lessons. These are distinct scopes, not interchangeable statuses.

| Evidence | Supported result |
|---|---|
| Selftests | 216 passed, 1 not-run (Anki), reconciled across a clean-copy run and targeted reruns; not one clean-suite pass |
| Live protocol | quiz/exam-drill/Q&A validation passed; predict-first failed twice |
| Full mutation suite | **40/40 caught** in saved sensitivity rows, not the report's 38/38 |
| Unchanged controls | 33/40 accepted: switch 8/11, byte 8/10, factorial 8/10, neuron 9/9 |
| Full lesson acceptance | 0/4 pass; factorial and neuron also fail their actual lesson review |
| Old routing evaluation | mode 20/32 → 27/32; visual route 15/32 → 25/32; medium 6/32 → 23/32 |
| Visual judgment | one independent final reviewer gave Looks 6–8 and Interaction 8–9; user acceptance remains open |

The routing comparison uses an adaptation layer; v2 has no native medium field, making that comparison less direct. The evaluator also contains the unwanted predict-first policy. Its score is evidence for that frozen task, not proof of the intended teaching behavior.

"Unchanged controls" does not mean independently established valid text. Some rejected controls exposed real defects. Separate false rejection of valid material, legitimate rejection of flawed material, and disagreement on the same material. Mutation catch rate measures useful detection sensitivity; it does not establish overall review reliability or mathematical truth.

## Required findings, in priority order

### P1: product scope is wrong

`package/prax-teach/SKILL.md:3,50`, `README.md:3`, and `schemas/lesson.schema.json:38-60` prescribe C, C17 citations and at least one C program. The schema expressly says other subjects still obtain values from C runs. Figure kinds and several explorer mechanisms are specialized to the examples. There is no demonstrated general course/resume path.

Fresh route probe: "Teach me neurons and build a complete visual course from neurons to deep learning" becomes one still lesson. A normal request to understand recursion becomes chat-only with no visual build. Biology/history requests can route to builds, but routing success does not supply a compatible general lesson model.

Remedy: retain the C compiler as an adapter below a general teaching contract. Support evidence appropriate to the domain: calculations, simulations, sourced facts, and expert-reviewed explanations. Do not force history or biology through C. Demonstrate the smallest non-code path before building a large universal framework.

### P1: explanation-first is not merely a router repair

Current `references/TEACHING.md:40-43` requires observed evidence before ordinary closure on satisfaction. Its explain mode pauses long explanations for "go on" and builds no visuals unless requested (`:124-128`). The authoring guide prescribes a prediction question before mechanism explanation (`LESSON-MODEL.md:86-89`). Q&A layers are sequentially locked (`project/qa.py:3-12`).

IVE `project/ive.py:139-171` and `templates/ive/ive.js:95-138` interrupt normal playback with a question for each options scene, without an opt-in teaching-mode parameter or explicit skip action. Timeline seeking can bypass it, so it is not an unbreakable lock. It remains a forced interruption in the normal learner flow.

Remedy: restore explanation-first across routing, instructions, authoring, Q&A, video playback and session closure. Give explicit practice mode and an obvious skip/show-explanation path. Satisfaction ends exploration without claiming that mastery has been measured. Do not ask Prax to decide his already-stated preference again; version the governing correction transparently.

### P1: consent withdrawal does not make reads nonmutating

`ptk/state/io.py:208,881,910,994,1377` can add binding xattrs when missing before consent is checked; `state.py:2965` calls the affected path. Adoption and locks add further mutation paths. The existing withdrawal check covers refused navigation, not filesystem metadata preservation.

Remedy: keep validation/read operations nonmutating. Establish or migrate metadata only in explicitly authorized state-changing operations. Check the entire read path, not one helper.

### P1: deletion result overstates its scope

`state.py:2916-2962` returns `all_state_deleted` after removing its workspace. The independent audit confirmed the reported synthetic learner file remains in Drive's local staging directory after the original is deleted. This is a real mismatch between result wording and storage behavior.

Remedy: report "workspace state deleted" and explain the boundary. Report known outside aliases separately, and mark remote copies unknown. Keep deletion available even where creation requires opt-in. Do not promise secure erasure of backup or cloud copies.

### P1: full claims acceptance is still failing

Remaining reviewed issues include the factorial frame count/title, video-only instructions copied into written transcripts, an incomplete/edited C-standard quote, and overly broad byte/cast wording. Three dropped claims need correct restoration, not merely removal to pass: switch warning guidance, neuron formula and byte recap.

Remedy: repair source claims and their context, keep actual source excerpts available to reviewers, and calibrate against adjudicated valid and invalid examples. Three agreeing LLM reviewers is not a proof and is not a substitute for calibrated controls.

### P2: two verifier gaps remain, with one partial fix underreported

- **Axis:** round 18 added `axis_anchor_problem` (`ptk/verify/claims.py:187`) using independently expected data. A fresh pure probe rejected coherently shifted ticks when the zero anchor was present. The same shifted labels passed when anchor metadata was absent because `rebind_ticks` only invokes the anchor check when metadata exists (`:224-225`). Thus the old "ticks only fit themselves" description is stale, but missing-required-anchor behavior remains open. The brief says A5 will finish this; A5 does not actually list it.
- **Overlap:** `project/video.py:700` exempts return-value `.chip` elements. `verify/frames.py:77-83` covers `.mlayer`, not that exemption. It needs a bounded overlap check.

These are focused repairs, not reasons to launch another broad council.

### P2: cloud evidence contains unsupported leaps

Actual evidence supports configured Drive backup roots and local retained staging. It does not establish successful upload of the specific learner probes, timing of upload, remote version retention, or comprehensive deletion by emptying cloud trash. `plan/EVIDENCE-HARDLINKS.md:9,62,183,203,209-210,221` overstates those conclusions; other sections acknowledge the uncertainty.

A hard link is another name for the same inode; later copies and uploads have different properties. Neither presence nor absence of a staging folder gives a complete backup inventory. Do not infer the source of every hard link from one proved Drive example.

Remedy: distinguish local workspace, local staging, configured sync and confirmed remote state. Do not touch Drive settings or existing uploads as part of this teaching-skill repair. Use nonsynced locations for both temporary and explicit learner-test roots; changing TMPDIR alone is insufficient (`tests/test_state.py:34,205,230`).

### P2: repair plan would reintroduce the loop

- A3 says reviewer disagreement can be resolved by clarifying the rubric during Track A (`REPAIR-PLAN.md:52`), although Track A changes the candidate. That repeats the spec/evaluator-and-code problem.
- The proposed 3/3 reviewer agreement and >=8 aesthetic score can reward consensus or score optimization without improving explanations.
- Old test prompts are disclosed. Relabeling them can correct a regression benchmark, not make them unseen again. Prax can approve the policy; he need not hand-author every test case.
- A/B ownership is not actually file-separated: claims, storyboard and figure live in the same lesson JSON, and builds share outputs (`:130-132`). Use isolated candidates with one merge/rebuild owner or serialize changes to shared lessons.
- A6 promises to report *any* outside copy (`:61`), which is not observable. Do not add a gate no implementation can honestly satisfy.
- "No empty region over 20%" is an arbitrary aesthetic constraint, not a universal quality rule. Whitespace can improve hierarchy. Use layout-specific checks and rendered comparison. A narration pace is a useful target, but equation density and comprehension matter too.
- The plan still ends at four examples; it lacks a non-code transfer demonstration, tool-light fallback and a complete optional-practice flow.
- `v2.1-rc1` is proposed, not an existing tag at this snapshot. The current commit is preserved, but do not claim the named rollback tag/archive is already complete.

### P2: documentation still contradicts the corrected summary

`PROGRESS.md:181-184` retains unqualified numeric-audit wording and 38/38. Raw receipts show 40/40. `reviews/final-verification.md:40` says run C was 16/1/1; its raw log is 18/1/1. The final 216/217 composite remains supported. `README.md` still attributes links to macOS backup/versioning. `SKILL.md:52` promises a roughly two-minute build despite the observed expensive review process.

Remedy: one concise candidate status manifest/report linked to exact code and artifact identities; label differing scopes, superseded receipts, unrun checks and timing honestly. Do not add a new status bureaucracy.

## Why it feels like a loop

The run froze an agent-derived teaching policy instead of the user's preference; selected a C-only implementation as the whole product; used known examples as proof of generality; changed evaluation while implementing; and discovered content/layout defects late through repeated expensive reviews. The follow-up plan then added more reviewer consensus and user decisions instead of directly correcting product scope.

This is both a skill/spec gap and an execution gap. It is not evidence that more tools or more model reviewers alone will solve the problem. The significant reusable implementation should be preserved.

## Proposed next steps — not executed or silently approved

1. **One governing correction, before implementation.** Preserve v2 and this candidate. Publish a short versioned contract restoring general teaching, explanation-first, optional practice, truthful privacy limits and full verification for accepted releases. Separate domain adapters from the teacher. Approve specific evaluator changes as one reviewable version; do not ask for repetitive permission on the same product preference.
2. **Repair the known failures in one bounded candidate.** Correct claims, withdrawal/read behavior, deletion wording, anchor/overlap checks and the full learner flow. Keep canaries as development smoke tests only. Use source-grounded review and adjudicated controls; surface disagreements rather than editing the rubric to make the current candidate pass.
3. **Prove transfer and polish actual artifacts.** Retain the C exemplar and produce a new conceptual/non-code lesson through the same teacher without C scaffolding, with static fallback on a tool-light host. Choose media for the explanation. Make landscape stills, readable video mechanisms, state-correct captions and listenable narration. Compare rendered artifacts with Atlas and the retained baseline, not only a score.
4. **One final acceptance pass on immutable inputs.** Full checks, complete source/artifact identity, explicit Anki/host limitations, fresh withheld transfer prompts under the approved contract, and Prax's visual verdict. Preserve the two-no-gain stop rule. If anything remains, report the bounded failure; do not silently extend rounds or weaken gates.

The current proposed 5+5 rounds are estimates, not permission and not evidence of required effort. No new rounds were run by this audit. The next approval should be for a concrete scope and fixed contract, not ten unrelated implementation decisions or another open-ended review loop.

## Practical decision split

Already clear from the user's instructions: explanation-first, optional practice, visually excellent accurate artifacts, general teaching scope, no installation yet. These are not questions to re-ask.

Human approval still needed before execution where applicable: the new version of frozen evaluation, a bounded implementation budget, any actual change to sync/privacy policy, final visual acceptance and eventual installation. Technical report corrections, evidence reconciliation and proposing the exact patch are ordinary engineering work.

## Reproduction notes

Fresh route probes used `ptk.route.route` directly with PYTHONDONTWRITEBYTECODE=1, without workspace mutation. The course request became one still; photosynthesis became still+explorer; a French-Revolution visual timeline became still; an ordinary recursion request became explain/no-build; a narrated recursion request refusing quizzes became video.

Fresh axis probe called `rebind_ticks` on labels 100/101/102 at x=0/100/200. With the independent zero anchor it returned axis-tick-off-scale for each tick; without anchor metadata it returned plain axis-tick. This proves the narrower metadata fail-open condition, not a full fresh media-build exploit.
