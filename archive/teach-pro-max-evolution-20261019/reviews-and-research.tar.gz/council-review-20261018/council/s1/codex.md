### Q1
**Rework into two sequential versions: an approved method repair, then a candidate-only media update.**

The mixed patch cannot be accepted under the stated policy, even though its tests pass. Prax must explicitly approve a new method version covering validator count derivation and provenance correction; preserve the stale receipt, document the discrepancy, and check the replacement against actual bytes. Deriving expected counts from candidate-controlled receipts or tests risks circular validation, so retain independent structural and completeness checks. Router, registry, implementation tests, and descriptive docs need no separate approval within authorized scope, but any normative acceptance-rule changes do. Freeze the repaired method before evaluating the media candidate, and describe its passing tests as routing evidence, not multimedia quality evidence.

### Q2
**Approve a tool-enabled, two-topic multimedia pilot gate; reserve “world-class” for a broader benchmark.**

Use one development topic and one held-out topic chosen after implementation freezes, each producing a still, interactive HTML, narrated MP4, and separate narration file with transcript: eight artifacts. Require accurate explanations, readable figures, meaningful interactive controls with correct state changes, intentional video motion, intelligible speech, and synchronized captions. Receipts should bind artifact hashes, source revision, method version, generation commands, dependencies, render settings, failures, and grader observations to the exact outputs. An independent grader must open the images, operate the pages, watch the videos, and hear the audio using tools; Prax then judges teaching quality against agreed reference examples. This governing change needs explicit approval and demonstrates representative capability, not universal excellence.

### Q3
**Default to local Kokoro through `hyperframes tts`; fall back to `say`, then viewer-side Web Speech.**

Kokoro offers the strongest stated quality while producing a reusable audio artifact for videos and standalone delivery. Use `say` when Kokoro fails or exceeds an agreed latency budget, recording the substitution. Web Speech suits optional page playback, but cannot replace a downloadable narration artifact and depends on the viewer’s environment. Preserve a transcript throughout; verify actual output quality and duration before treating any backend as dependable.

### Q4
**Build a standalone single-file interactive template first; expand Visual Lab after it proves reusable value.**

Embed scripts, styles, and assets, avoid module imports and network dependencies, and test directly through `file://`. Verify each supported chat renderer separately: some sanitize scripts or sandbox execution, so single-file packaging cannot guarantee compatibility. Keep Visual Lab as the richer HTTP option, reuse its teaching ideas where practical, and add a second lesson only after the portable template passes. Prioritize controls that reveal a concept through experimentation over additional decorative lessons.

### Q5
**Use hyperframes HTML/GSAP as the provisional general-explainer default, with Manim for mathematical animation.**

HTML composition offers flexible typography, diagrams, and pacing, while browser preview makes iteration accessible to an agent. That is a promising fit, not established reliability: benchmark it against Manim on the pilot before freezing the default, measuring retries and render time alongside quality. Choose Manim when equations, geometry, or precise mathematical transformations dominate. Keep ffmpeg stills plus TTS as an explicitly labeled fallback; it proves video packaging and narration, but does not satisfy a motion-explainer gate.

### Q6
**Run three capped milestones, with human approval at governance and quality boundaries.**

Budget 4 agent-hours for the method repair, 12 for the portable interactive and media pipelines, and 8 for held-out evaluation plus one repair cycle; cap rendering at 4 machine-hours and use no paid services. First approve and freeze the method, then land the routing candidate and build development artifacts, then freeze implementation before revealing the held-out topic. Stop on budget exhaustion, two consecutive candidates without measured improvement, or a protected regression; report partial capability without weakening the gate. Prax’s three decisions are approval of the method version, approval of the multimedia rubric and reference standard, and final acceptance of demonstrated quality. Within those boundaries, the agent should implement, render, inspect, and repair without routine confirmation.
