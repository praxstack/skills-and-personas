**Q1. Split into two versions. Do not accept as one.**

Identity-preservation is the rule this package already runs on. Validator count derivation and the provenance digest re-record are method-tier. Prax has to approve those, and they need their own version.

Ship governing first: validator reads registry and test counts from the receipt and the test file, and re-record the stale SHA-256 so it matches current bytes. That unmasks defect 7 and unblocks registry growth.

Then ship the candidate: router vocabulary, media-explainer rule, three TTS tools, docs, HTTP note, fixtures. Those do not need a new governing version. They still need a normal candidate gate.

The mixed patch would make the next registry change undiagnosable. Order is governing, then candidate, same week.

**Q2. One concept, four playable artifacts, tool-enabled grader, Prax signs quality.**

Teach one topic (reuse Python float) as a still figure on disk, an interactive page a browser actually runs, an MP4 with picture and speech, and a TTS file or muxed narration. Each receipt records path, bytes, dimensions or duration, and a tool-using grader that opens or plays it.

The grader needs tools. Text-only grading cannot prove media. The agent proves exists-and-plays. Prax grades world-class on the four files.

This gate is a governing change: new evaluator, new receipts, new version, explicit approval. Missing any playable medium means the claim is unproven.

**Q3. Default: hyperframes tts (Kokoro). Fallback: macOS say, then on-screen transcript.**

World-class means the audio that ships is a file you can pin. Kokoro is local, already on the Mac, and good enough under a video. `say` is the reliability floor: instant, always there when Kokoro is slow or fails.

Web Speech produces no file and depends on the viewer’s browser, so it cannot sit in an evidence pin. Use it as an optional overlay on live pages only. Drafts and routing smokes can use `say`. Packaged lessons and videos use Kokoro.

**Q4. Standalone single-file HTML first. Grow the lab after it can export to that.**

Agents deliver files into chat. file:// and chat renderers are the student surface. The lab’s HTTP and CSP constraint is why the one existing lesson already fails that surface.

Build a generator that emits one HTML file with inlined CSS and JS, working from file://. Port the float lesson as the proof. Then treat Visual Lab as the authoring runtime: more lessons live there, and the skill exports them.

More ES-module lab lessons before a file:// path exists repeats the same dead end.

**Q5. Default: hyperframes HTML/GSAP rendered to MP4 with Kokoro on the timeline. Manim opt-in. Slideshow as fallback.**

Agents write HTML more reliably than Manim scenes. Hyperframes is already on the host with Chrome headless, ffmpeg, and TTS. Quality ceiling is high for explainers: type, diagrams, motion, narration.

Manim’s ceiling is higher for math-heavy proofs and costs more agent failures and render time. Keep it as an explicit path.

ffmpeg stills plus TTS is the reliability floor when composition fails. It will not look world-class, so it is a fallback.

**Q6. Governing split, then candidate routing, then Prax picks the gate and defaults, then one four-medium proof.**

Milestone A, Prax decides then the agent ships: approve the validator and provenance version.

Milestone B, agent proceeds: candidate routing, registry, docs, tests. Stop. This does not prove world-class.

Milestone C, Prax decides: the four-medium gate, Kokoro vs say, hyperframes vs Manim.

Milestone D, agent proceeds: one proof topic across four media against that gate. One focused run.

Stop rule: no more vocabulary, tools, or lab lessons until D has four playable receipts. After that Prax looks at the files and says ship, raise the bar, or change the pipeline.

The three decisions that are actually Prax’s: approve the governing version, what counts as proof, and the narration plus video defaults.
