
**Q1. Split into two governed releases; do not accept the patch as one blob.**

The identity-preservation rule is clear: candidate routing/registry/docs/tests can ship as **vNext candidate** without re-approving method tier, but **validator count derivation** and **provenance digest re-record** are governing changes and must not ride along silently. Accept the multimedia routing work after stripping method-tier edits into a separate **method v+1** that Prax explicitly approves. The stale `legacy-assets.json` digest fix belongs in that method release, not as camouflage inside a feature patch. Router vocabulary, narration flag, registry tools (+3), fixtures, and docs are candidate-tier and can proceed under normal gates once method is clean. **Prax must approve:** method version bump, validator behavior change, provenance receipt updates. **Agent can proceed:** router, registry, tests, user-facing docs that don’t change acceptance law.

**Q2. Add a four-artifact “multimedia smoke gate” with tool-enabled grading and pinned receipts.**

Smallest honest gate: one canonical lesson topic (e.g. floating point or a fixed neuron stub) must produce **four pinned artifacts** in one run: (1) still — PNG/SVG with manifest hash, (2) interactive — URL-served lab page *or* file:// HTML per chosen strategy, (3) video — MP4 with duration & codec in receipt, (4) narration — WAV/MP3 *or* documented Web Speech transcript + timing sidecar. Receipts must record route taken, tools invoked, output paths, and configure evidence pin. **Grader needs tools** (or a harness that opens HTTP, ffprobe, image hash) — text-only grading already failed to prove multimedia. **Prax approves** the gate spec and golden topic; agent implements fixtures and runs until receipts exist.

**Q3. Default: hyperframes TTS; fallback: macOS `say`, then Web Speech transcript-only.**

Hyperframes matches “world-class” narration on a Mac agent host: local, high quality, reproducible **files** agents can attach and mux with video. `say` is the fast fallback when hyperframes is slow, missing, or the user asked for instant preview. Web Speech is viewer-side and non-archival — use only when no file is required (chat preview) with a explicit transcript fallback in the receipt. Order: **hyperframes → say → web-speech (transcript mode)**.

**Q4. Standalone file://-safe HTML first; expand Visual Lab second, in parallel only after HTTP serving is documented.**

The evidence gap is “skill produces explainer interactives anywhere,” not “one demo lesson on localhost.” Single-file or inlined-bundle HTML works in chat renderers and file:// without CSP/module pain. Visual Lab remains the **reference runtime** for richer ES-module lessons once `npx serve` (or equivalent) is part of the documented path. Order: **(1) generator path for portable HTML, (2) second Visual Lab lesson, (3) shared components** if duplication hurts.

**Q5. Default video: ffmpeg slideshow of stills + TTS; aspirational tier Manim; hyperframes for motion-heavy branded explainers.**

Slideshow+TTS is the most **reliable** for agents: deterministic inputs, fast iteration, easy receipt (ffprobe). Manim has the highest **quality ceiling** but is slow and brittle for open-ended agent authoring. Hyperframes sits in the middle for animated explainers when HTML/GSAP → MP4 is already in the stack — use when the lesson is motion-first, not as default. Default pipeline label in registry: **stills+TTS → MP4**; route “cinematic math” requests to Manim explicitly.

**Q6. Milestones: (M0) split patch + fix provenance in method release → (M1) ship routing/registry without method mix → (M2) multimedia smoke gate + one golden lesson → (M3) interactive HTML generator → (M4) video default pipeline → (M5) Visual Lab lesson #2.**

**Human must decide:** (1) accept method v+1 (validator derivation + provenance), (2) pick golden lesson topic for the smoke gate, (3) quality bar — “good enough explainer” vs Manim-grade for default video. **Agent proceeds:** split commits, routing/tests, hyperframes-first narration wiring, ffmpeg slideshow implementation, gate harness with receipts. **Stop rule:** do not claim “world-class across four media” until M2 passes with tool-enabled grader artifacts on disk and pinned — not transcript-only.

**Budget sketch:** M0–M1 ~1 session; M2 ~1–2 sessions (gate is the critical path); M3–M5 ~2–3 sessions depending on HTML generator scope.
