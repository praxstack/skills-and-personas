RANKING: D > B > A > C

WHY

D: Strongest on governance, evidence, and honest claims: it separates representative capability from “world-class,” requires actual viewing and listening, and catches chat-renderer limitations. Its weakest point is an ambitious, unvalidated 24-hour implementation budget; the pilot supports a bounded capability claim, not the full goal.

B: Strong acceptance receipts, explicit budgets, and a useful stop rule make this actionable. Its weakest point is claiming derived counts “can never catch drift”: circularity is a credible risk, but that absolute conclusion needs implementation evidence. It also overstates renderer compatibility and pipeline reliability.

A: Clear sequencing and a sensible division between machine verification and Prax’s quality judgment. Its weakest point is treating one familiar topic across four artifacts as sufficient proof of “world-class.” It also lacks a concrete budget and assumes correcting the digest unmasks the provenance defect without requiring ongoing byte verification.

C: Correctly separates method changes and prioritizes portable interactive delivery. Its weakest point is accepting a Web Speech transcript and timing sidecar as narration evidence; neither proves audio exists or sounds acceptable. Its smoke gate and slideshow default also fall short of its proposed “world-class” completion claim.

DISAGREEMENTS:

Q1: All reject the mixed patch. D’s position is strongest: repair and freeze the method first, preserve provenance history, and require independent checks. B’s circularity concern warrants inspection, not a categorical verdict.

Q2: D is right that eight inspected artifacts can demonstrate representative capability while leaving broader excellence unproven. A and C’s single-topic smoke gates are insufficient; C’s transcript substitute is invalid audio evidence.

Q3: Consensus on Kokoro first and `say` second. D correctly limits Web Speech to optional playback; it cannot satisfy the downloadable narration requirement.

Q4: Consensus on standalone HTML first, then Lab expansion. D correctly distinguishes file portability from chat execution: each renderer needs separate verification.

Q5: Prefer D’s provisional hyperframes default, benchmarked before commitment, with Manim for mathematical animation. C’s slideshow is a useful fallback but cannot demonstrate motion explanation.

Q6: D and B offer meaningful caps and no-gain stops; A and C mostly offer schedules. Prefer D’s human decisions at method approval, quality-standard approval, and final acceptance, with implementation delegated within those boundaries.

WATCH-OUTS:

- Passing routing tests or producing playable files does not establish teaching quality or “world-class” performance.
- Re-recording a digest does not repair missing validation against actual bytes; preserve the discrepancy and enforce the check.
- Single-file HTML does not guarantee chat execution, and transcripts do not prove narration.
