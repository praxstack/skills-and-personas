# Council stage 2: anonymous peer review

You are one member of an LLM council. Below is the original brief, followed by four anonymous answers (A, B, C, D) from council members. One of them may be yours; you cannot tell which, so judge purely on merit. Do not run tools, browse, or edit files.

Task: evaluate the four answers for accuracy against the brief's facts and governance policy, for insight, and for how actionable they are. Then rank them best to worst.

Output exactly this structure, under 450 words, plain human voice, no filler:

RANKING: <letter> > <letter> > <letter> > <letter>
WHY (one short paragraph per letter, best first, naming the strongest and weakest point of each)
DISAGREEMENTS: list each question Q1..Q6 where the answers materially disagree, say which position you find right and why in one or two sentences. Where they all agree, say "consensus".
WATCH-OUTS: up to three risks or errors you spotted in any answer that a chairman must not carry into the final synthesis.

---
## Original brief

# Council brief: Prax Teach v2 multimedia way forward

You are one member of an LLM council (Karpathy-style: independent answers, then anonymous peer ranking, then a chairman synthesis). Answer on your own, from the facts below. Do not run tools, do not browse, do not edit files. Write in plain human voice, answer first, no filler. Keep it under 700 words.

## Facts (verified 18 Oct 2026 by a review of the shipped package)

Prax Teach v2 is a teaching skill for coding agents (Codex, Claude Code). It ships as a ZIP: a root loader `SKILL.md`, the authoritative teacher in `.engine/SKILL.md`, a 1637-file hashed manifest, a `configure.py` that verifies hashes and writes an evidence pin, a regex router `scripts/prax_teach.py` (routes: none / static / interactive / motion), a 38-tool visualization registry, a zero-dependency interactive runtime called Prax Visual Lab, and a deterministic Markdown-to-HTML renderer. Governance follows an identity-preservation policy: a change may touch the candidate OR its governing spec/evaluator/gates, never both in one run; governing changes need explicit human approval and a new version; acceptance only through gates with receipts.

What the review found:
1. The four packaging claims hold (one Codex entry, engine byte-identical to commit 389f6f9, setup/routing/rendering/validation pass, 22 JS tests pass), with two conditions: JS tests need `npm ci` in three directories, and the validator only passes after configure writes its evidence pin.
2. The accepted teaching evaluation was tool-disabled text only. No receipt anywhere exercised a rendered image, an interactive page, a video, or audio. The grader report says so itself.
3. Still images: policy and registry exist (Mermaid, Excalidraw, matplotlib, Graphviz and others), but every rendered lesson in the evidence is a text transcript with no figure.
4. Interactive: Prax Visual Lab works, but implements exactly one lesson (Python floating point) and only mounts over HTTP because it uses ES modules with a strict CSP. Opened from file:// it shows the fallback text.
5. Video: policy prose and registry entries (Manim 0.22, ffmpeg, Remotion, hyperframes) exist, but the router did not know the words video, clip, animated. "A short explainer video of how a neuron fires" routed to `none`; "make me a video explaining X" routed to ordinary task, not teaching. No video artifact was ever produced.
6. Narration / TTS: nothing. No route, no registry entry, no doc line. The host Mac has `hyperframes tts` (Kokoro-82M, local, v0.8.169), macOS `say` (188 voices), ffmpeg, Manim, Chrome headless, Node 24, Python 3.13.
7. A pre-existing defect: `evidence/provenance/legacy-assets.json` records a stale SHA-256 for `references/LEGACY-VISUALIZATION-ROUTER.md` (matches an older baseline, not the accepted bytes). The pinned validator never checks against current bytes, so it was masked.
8. The validator hard-codes registry counts (38 tools / 12 tests), so any registry growth fails validation unless the validator itself changes.

A candidate patch exists, tested, uncommitted, not installed (branch `candidate/media-routing-20261018`, 15 files, +2332/-398). It adds: video and animation vocabulary to the motion route; a `narration` flag on visual routing with a host-speech surface and a transcript fallback; three registry tools (web-speech-api, hyperframes-tts, macos-say; registry now 41); a media-explainer rule so "video explaining X" counts as a teaching request; docs updates; an HTTP-serving note for the lab; 8 new fixture cases and tests. It ALSO changes `scripts/validate_workspace.py` to derive the registry counts from the receipt and the test file instead of hard-coding them, and re-records the stale digest in the provenance receipt. All relevant tests pass (65 routing/CLI/validator, 13 registry, lint clean, 43 renderer pairs). Note: the validator and provenance receipt are part of the governing "method" tier, so the patch as it stands mixes candidate and governing changes.

Prax's stated goal: the skill must be able to produce world-class explainer visualisation across still, interactive, video, and TTS/narration.

## Questions for the council

Q1. The candidate patch mixes candidate changes (router, registry, docs, tests) with governing changes (validator count derivation, provenance digest re-record). Should it be accepted as one, split into two versions, or reworked? Say which parts need Prax's explicit approval and which do not.

Q2. "World-class across four media" is currently unproven and the acceptance gate was text-only. Define the smallest honest acceptance gate that would actually prove it: what artifacts per medium, what receipts, who grades, and whether the grader needs tools. Treat this as a governing change proposal.

Q3. Default narration stack for a local Mac agent: hyperframes tts (Kokoro, local, high quality, slow-ish), macOS `say` (instant, lower quality), or in-browser Web Speech API (no file, viewer-side). Pick one default and the fallback order, with reasoning.

Q4. Interactive: should the next investment expand Prax Visual Lab (ES modules, needs HTTP, one lesson) with more lessons, or should the skill generate standalone single-file interactive HTML that works from file:// and chat renderers? Or both, in what order?

Q5. Video: for "explainer video of X", which default pipeline: Manim scenes, hyperframes HTML/GSAP compositions rendered to MP4, or an ffmpeg slideshow of stills plus TTS audio? Consider quality ceiling, reliability from an agent, and render time.

Q6. Sequencing and stop rule: order the work (Q1 to Q5) into milestones with a budget, and say where the human must decide versus where the agent should just proceed. Name the two or three decisions that are genuinely Prax's.

Format your answer as six short sections Q1..Q6, each starting with a one-line recommendation in bold, then at most five sentences of reasoning.

---

## Answer A

**Q1. Split into two versions. Do not accept as one.**

Identity-preservation is the rule this package already runs on. Validator count derivation and the provenance digest re-record are method-tier. Prax has to approve those, and they need their own version.

Ship governing first: validator reads registry and test counts from the receipt and the test file, and re-record the stale SHA-256 so it matches current bytes. That unmasks defect 7 and unblocks registry growth.

Then ship the candidate: router vocabulary, media-explainer rule, three TTS tools, docs, HTTP note, fixtures. Those do not need a new governing version. They still need a normal candidate gate.

The mixed patch would make the next registry change undiagnosable. Order is governing, then candidate, same week.

**Q2. One concept, four playable artifacts, tool-enabled grader, Prax signs quality.**

Teach one topic (reuse Python float) as a still figure on disk, an interactive page a browser actually runs, an MP4 with picture and speech, and a TTS file or muxed narration. Each receipt records path, bytes, dimensions or duration, and a tool-using grader that opens or plays it.

The grader needs tools. Text-only grading cannot prove media. The agent proves exists-and-plays. Prax grades world-class on the four files.

This gate is a governing change: new evaluator, new receipts, new version, explicit approval. Missing any playable medium means the claim is unproven.

**Q3. Default: hyperframes tts (Kokoro). Fallback: macOS say, then on-screen transcript.**

World-class means the audio that ships is a file you can pin. Kokoro is local, already on the Mac, and good enough under a video. `say` is the reliability floor: instant, always there when Kokoro is slow or fails.

Web Speech produces no file and depends on the viewer’s browser, so it cannot sit in an evidence pin. Use it as an optional overlay on live pages only. Drafts and routing smokes can use `say`. Packaged lessons and videos use Kokoro.

**Q4. Standalone single-file HTML first. Grow the lab after it can export to that.**

Agents deliver files into chat. file:// and chat renderers are the student surface. The lab’s HTTP and CSP constraint is why the one existing lesson already fails that surface.

Build a generator that emits one HTML file with inlined CSS and JS, working from file://. Port the float lesson as the proof. Then treat Visual Lab as the authoring runtime: more lessons live there, and the skill exports them.

More ES-module lab lessons before a file:// path exists repeats the same dead end.

**Q5. Default: hyperframes HTML/GSAP rendered to MP4 with Kokoro on the timeline. Manim opt-in. Slideshow as fallback.**

Agents write HTML more reliably than Manim scenes. Hyperframes is already on the host with Chrome headless, ffmpeg, and TTS. Quality ceiling is high for explainers: type, diagrams, motion, narration.

Manim’s ceiling is higher for math-heavy proofs and costs more agent failures and render time. Keep it as an explicit path.

ffmpeg stills plus TTS is the reliability floor when composition fails. It will not look world-class, so it is a fallback.

**Q6. Governing split, then candidate routing, then Prax picks the gate and defaults, then one four-medium proof.**

Milestone A, Prax decides then the agent ships: approve the validator and provenance version.

Milestone B, agent proceeds: candidate routing, registry, docs, tests. Stop. This does not prove world-class.

Milestone C, Prax decides: the four-medium gate, Kokoro vs say, hyperframes vs Manim.

Milestone D, agent proceeds: one proof topic across four media against that gate. One focused run.

Stop rule: no more vocabulary, tools, or lab lessons until D has four playable receipts. After that Prax looks at the files and says ship, raise the bar, or change the pipeline.

The three decisions that are actually Prax’s: approve the governing version, what counts as proof, and the narration plus video defaults.

---

## Answer B

**Q1. Split it into two versions, and rework the validator part before it goes to Prax.**
The router, narration flag, three registry tools, media-explainer rule, docs, fixtures and tests are all candidate changes, so they need gates, not Prax's sign-off. The validator count derivation and the provenance digest re-record are governing changes, so both need his explicit approval and a new method version. The count derivation also has a flaw: it reads counts from the receipt and the test file it's meant to check, so it can never catch drift. Better to pin the expected counts in a versioned spec that gets bumped on purpose. Land the governing version first, then run the candidate against it unchanged.

**Q2. Gate on rendered artifacts from a frozen holdout, graded by a tool-enabled model, with Prax grading a sample.**
Use two holdout topics per medium. That's eight artifacts: a figure embedded in the lesson, a single-file interactive page, a 60 to 90 second MP4, and a narration audio file with its transcript. Each receipt holds the render command, exit code, output hash and machine checks: the image decodes; the page loads from both file:// and HTTP in headless Chrome with zero console errors and a scripted interaction that changes state; ffprobe confirms the video and audio streams; a transcription of the audio matches the script within a set error rate. The grader must have tools, meaning vision on screenshots and video keyframe sheets and a browser to click through the page, or we're grading text again. "World-class" can't be checked by a script, so Prax grades four of the eight blind against a reference explainer, and that rubric is part of the governing proposal he approves.

**Q3. Default to hyperframes tts (Kokoro), fall back to macOS `say`, and use Web Speech only for live interactive pages.**
Video needs an audio file with known timing, and Kokoro is local, offline and good enough to carry a world-class claim. Its slowness doesn't matter in an offline render. `say` is the fallback when Kokoro fails, and the fast way to draft a preview. Web Speech makes no file and sounds different on every viewer's machine, so it fits interactive pages but shouldn't count as a narration artifact, and a transcript always ships with it.

**Q4. Both, but standalone single-file HTML first.**
Lessons get opened from file:// and in chat renderers, and right now the Lab shows fallback text in exactly those places. One lesson after all this work tells me the Lab isn't the bottleneck. How lessons get delivered is. Build the single-file generator first. Then give the Lab a bundle step that inlines its modules and CSP into one file, so new Lab lessons ship the same way. Add more Lab lessons only after that.

**Q5. Default to hyperframes HTML/GSAP rendered to MP4, use Manim for math-heavy topics, and keep the ffmpeg slideshow as the fallback that always works.**
Agents write HTML reliably. Hyperframes has lint and check steps, renders deterministically, and shares a stack with the interactive pages and the TTS. Manim has the higher ceiling for math, but LaTeX dependencies, API changes between versions and slow renders make it less reliable from an agent. The slideshow has the lowest ceiling but almost never fails, so it guarantees a video ships even when the better pipelines break. I haven't timed any of these here, so render time per pipeline should go into the receipts.

**Q6. Five milestones over about a week of agent time: Prax decides in M0 and M4, and the agent just proceeds in between.**
M0 (half a day, Prax): approve the method version (reworked validator, digest fix, Q2 gate) and freeze the holdout. M1 (1 day, agent): the candidate without its governing files, run against the new gate. M2 (2 days, agent): still images plus the single-file interactive generator, both passing their gates. M3 (2 to 3 days, agent): Kokoro narration plus the hyperframes video pipeline, then M4 is Prax's blind grade. Stop rule: two no-gain candidates or a spent budget in any milestone means stop and report the stall, never loosen a gate. The calls that are really Prax's: approving the governing version, defining "world-class" (rubric, reference bar, him as final grader), and whether Kokoro and headless Chrome become required installs or stay optional.
---

## Answer C


**Q1. Split into two governed releases; do not accept the patch as one blob.**

The identity-preservation rule is clear: candidate routing/registry/docs/tests can ship as **vNext candidate** without re-approving method tier, but **validator count derivation** and **provenance digest re-record** are governing changes and must not ride along silently. Accept the multimedia routing work after stripping method-tier edits into a separate **method v+1** that Prax explicitly approves. The stale `legacy-assets.json` digest fix belongs in that method release, not as camouflage inside a feature patch. Router vocabulary, narration flag, registry tools (+3), fixtures, and docs are candidate-tier and can proceed under normal gates once method is clean. **Prax must approve:** method version bump, validator behavior change, provenance receipt updates. **Agent can proceed:** router, registry, tests, user-facing docs that don’t change acceptance law.

**Q2. Add a four-artifact “multimedia smoke gate” with tool-enabled grading and pinned receipts.**

Smallest honest gate: one canonical lesson topic (e.g. floating point or a fixed neuron stub) must produce **four pinned artifacts** in one run: (1) still — PNG/SVG with manifest hash, (2) interactive — URL-served lab page *or* file:// HTML per chosen strategy, (3) video — MP4 with duration & codec in receipt, (4) narration — WAV/MP3 *or* documented Web Speech transcript + timing sidecar. Receipts must record route taken, tools invoked, output paths, and configure evidence pin. **Grader needs tools** (or a harness that opens HTTP, ffprobe, image hash) — text-only grading already failed to prove multimedia. **Prax approves** the gate spec and golden topic; agent implements fixtures and runs until receipts exist.

**Q3. Default: hyperframes TTS; fallback: macOS `say`, then Web Speech transcript-only.**

Hyperframes matches “world-class” narration on a Mac agent host: local, high quality, reproducible **files** agents can attach and mux with video. `say` is the fast fallback when hyperframes is slow, missing, or the user asked for instant preview. Web Speech is viewer-side and non-archival — use only when no file is required (chat preview) with a explicit transcript fallback in the receipt. Order: **hyperframes → say → web-speech (transcript mode)**.

**Q4. Standalone file://-safe HTML first; expand Visual Lab second, in parallel only after HTTP serving is documented.**

The evidence gap is “skill produces explainer interactives anywhere,” not “one demo lesson on localhost.” Single-file or inlined-bundle HTML works in chat renderers and file:// without CSP/module pain. Visual Lab remains the **reference runtime** for richer ES-module lessons once `npx serve` (or equivalent) is part of the documented path. Order: **(1) generator path for portable HTML, (2) second Visual Lab lesson, (3) shared components** if duplication hurts.

**Q5. Default video: ffmpeg slideshow of stills + TTS; aspirational tier Manim; hyperframes for motion-heavy branded explainers.**

Slideshow+TTS is the most **reliable** for agents: deterministic inputs, fast iteration, easy receipt (ffprobe). Manim has the highest **quality ceiling** but is slow and brittle for open-ended agent authoring. Hyperframes sits in the middle for animated explainers when HTML/GSAP → MP4 is already in the stack — use when the lesson is motion-first, not as default. Default pipeline label in registry: **stills+TTS → MP4**; route “cinematic math” requests to Manim explicitly.

**Q6. Milestones: (M0) split patch + fix provenance in method release → (M1) ship routing/registry without method mix → (M2) multimedia smoke gate + one golden lesson → (M3) interactive HTML generator → (M4) video default pipeline → (M5) Visual Lab lesson #2.**

**Human must decide:** (1) accept method v+1 (validator derivation + provenance), (2) pick golden lesson topic for the smoke gate, (3) quality bar — “good enough explainer” vs Manim-grade for default video. **Agent proceeds:** split commits, routing/tests, hyperframes-first narration wiring, ffmpeg slideshow implementation, gate harness with receipts. **Stop rule:** do not claim “world-class across four media” until M2 passes with tool-enabled grader artifacts on disk and pinned — not transcript-only.

**Budget sketch:** M0–M1 ~1 session; M2 ~1–2 sessions (gate is the critical path); M3–M5 ~2–3 sessions depending on HTML generator scope.

---

## Answer D

### Q1
**Rework into two sequential versions: an approved method repair, then a candidate-only media update.**

The mixed patch cannot be accepted under the stated policy, even though its tests pass. Prax must explicitly approve a new method version covering validator count derivation and provenance correction; preserve the stale receipt, document the discrepancy, and check the replacement against actual bytes. Deriving expected counts from candidate-controlled receipts or tests risks circular validation, so retain independent structural and completeness checks. Router, registry, implementation tests, and descriptive docs need no separate approval within authorized scope, but any normative acceptance-rule changes do. Freeze the repaired method before evaluating the media candidate, and describe its passing tests as routing evidence, not multimedia quality evidence.

### Q2
**Approve a tool-enabled, two-topic multimedia pilot gate; reserve “world-class” for a broader benchmark.**

Use one development topic and one held-out topic chosen after implementation freezes, each producing a still, interactive HTML, narrated MP4, and separate narration file with transcript: eight artifacts. Require accurate explanations, readable figures, meaningful interactive controls with correct state changes, intentional video motion, intelligible speech, and synchronized captions. Receipts should bind artifact hashes, source revision, method version, generation commands, dependencies, render settings, failures, and grader observations to the exact outputs. An independent grader must open the images, operate the pages, watch the videos, and hear the audio using tools; Prax then judges teaching quality against agreed reference examples. This governing change needs explicit approval and demonstrates representative capability, not universal excellence.

### Q3
**Default to local Kokoro through `hyperframes tts`; fall back to `say`, then viewer-side Web Speech.**

Kokoro offers the strongest stated quality while producing a reusable audio artifact for videos and standalone delivery. Use `say` when Kokoro fails or exceeds an agreed latency budget, recording the substitution. Web Speech suits optional page playback, but cannot replace a downloadable narration artifact and depends on the viewer’s environment. Preserve a transcript throughout; verify actual output quality and duration before treating any backend as dependable.

### Q4
**Build a standalone single-file interactive template first; expand Visual Lab after it proves reusable value.**

Embed scripts, styles, and assets, avoid module imports and network dependencies, and test directly through `file://`. Verify each supported chat renderer separately: some sanitize scripts or sandbox execution, so single-file packaging cannot guarantee compatibility. Keep Visual Lab as the richer HTTP option, reuse its teaching ideas where practical, and add a second lesson only after the portable template passes. Prioritize controls that reveal a concept through experimentation over additional decorative lessons.

### Q5
**Use hyperframes HTML/GSAP as the provisional general-explainer default, with Manim for mathematical animation.**

HTML composition offers flexible typography, diagrams, and pacing, while browser preview makes iteration accessible to an agent. That is a promising fit, not established reliability: benchmark it against Manim on the pilot before freezing the default, measuring retries and render time alongside quality. Choose Manim when equations, geometry, or precise mathematical transformations dominate. Keep ffmpeg stills plus TTS as an explicitly labeled fallback; it proves video packaging and narration, but does not satisfy a motion-explainer gate.

### Q6
**Run three capped milestones, with human approval at governance and quality boundaries.**

Budget 4 agent-hours for the method repair, 12 for the portable interactive and media pipelines, and 8 for held-out evaluation plus one repair cycle; cap rendering at 4 machine-hours and use no paid services. First approve and freeze the method, then land the routing candidate and build development artifacts, then freeze implementation before revealing the held-out topic. Stop on budget exhaustion, two consecutive candidates without measured improvement, or a protected regression; report partial capability without weakening the gate. Prax’s three decisions are approval of the method version, approval of the multimedia rubric and reference standard, and final acceptance of demonstrated quality. Within those boundaries, the agent should implement, render, inspect, and repair without routine confirmation.

---

