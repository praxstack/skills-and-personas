RANKING: D > B > A > C

WHY

D. Strongest point is the governance read: split the patch, keep count checks independent of the files they police, preserve the stale digest as a discrepancy, and verify any replacement against current bytes. The two-topic pilot, revealed only after the code freezes, is the gate that stays honest about "world-class." Weakest point is the 4/12/8 hour budget and the "no paid services" cap. Those are estimates, and they read like measurements.

B. Strongest point is the receipt checklist: image decodes, page loads from file:// and HTTP, a scripted click changes state, ffprobe sees both streams, transcript error stays inside a bound. Pinning expected counts in a versioned spec fixes the circular validator. Weakest point is freezing hyperframes and Kokoro before any timed artifact, plus LaTeX and API-churn claims the brief never shows. "Two holdout topics per medium" also fights the eight-artifact arithmetic.

A. Strongest point is the stop rule: method version, then routing, then one four-medium proof, and no more vocabulary or lab lessons until four playable receipts exist. Weakest point is treating count derivation and a digest rewrite as the repair. A count taken from the receipt cannot catch drift, and rewriting the stale hash hides defect 7 unless something checks current bytes. One recycled float lesson graded "exists and plays" is too thin for the claim.

C. Strongest point is a clear split of who signs the method version and who may land router, registry, and docs. Weakest point is the gate around that split. A transcript sidecar or an HTTP-only lab can pass, slideshow is the default video path, and the smoke milestone sits before the generator and video pipeline.

DISAGREEMENTS

Q1. All four refuse the mixed patch. A and C would ship the validator derivation and a digest rewrite inside the method version. B and D are right. Prax approves a reworked method check with an independent expected count, and the old hash stays visible until a byte check replaces it.

Q2. A and C use one topic. B and D use two topics and eight artifacts. The right shape is D's, with B's machine checks. One in-sample lesson proves a pipeline. A frozen dev topic plus a held-out topic, opened with tools, and a sample Prax judges against a reference, is the smallest gate that can carry a quality claim. The general "world-class" label waits on a wider set. C's Web Speech sidecar fails narration.

Q3. Consensus. Default Kokoro via hyperframes tts, fall back to say, keep Web Speech off the evidence pin. D's latency budget and a real listen-before-trust check belong on the receipt.

Q4. Consensus. Standalone single-file HTML first, Visual Lab only after export works. Each chat renderer still needs its own check. A file:// success can still die in a sanitizing preview.

Q5. A, B, and D pick hyperframes for general explainers, Manim for math, and slideshow as a labeled fallback. C picks slideshow as the default. D is right: hyperframes is the provisional pilot path, and the default stays unfrozen until that pilot records retries, render time, and picture quality. The brief has no timing evidence for any pipeline.

Q6. D's sequence is the one to run. Prax approves the method repair, the agent builds on a dev topic, implementation freezes, the holdout is revealed, then Prax accepts or rejects quality. A's stop-until-four-receipts and B's "never loosen a gate" ride along. C's smoke-before-pipeline order does not. Prax owns the method version, the rubric and reference, and the final quality call. Pipeline taste and Kokoro-versus-say are settled enough for a pilot.

WATCH-OUTS

- Count derivation that reads the receipt or the test file makes registry growth self-certifying. A and C call that a fix.
- Overwriting `legacy-assets.json` so the stale SHA-256 matches current bytes, with no check against current bytes, erases the only record of defect 7.
- C's pass conditions (transcript sidecar, HTTP-only lab, slideshow as the default) and a smoke gate scheduled before those pipelines exist would let a synthesis say "proven" over the same text-only hole this review already found.
