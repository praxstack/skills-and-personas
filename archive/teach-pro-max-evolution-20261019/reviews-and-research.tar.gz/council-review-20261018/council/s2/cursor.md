
RANKING: B > D > A > C

WHY  
**B** nails governance and proof: it flags that deriving validator counts from the receipt and test file under check is circular (aligned with the brief’s method tier), proposes versioned expected counts instead, and gives the most operable Q2 gate (file:// + HTTP, ffprobe, scripted interaction, Prax blind sample). Weakest: eight artifacts and two holdouts may be heavy for “smallest honest” gate.  
**D** matches policy on split releases, calls out the same circular-validation risk, and separates a multimedia pilot from a full “world-class” benchmark with explicit budgets and stop rules. Weakest: fewer concrete machine checks than B.  
**A** is crisp on identity-preservation ordering, stop rule (no feature churn until four playable receipts), and hyperframes-first video/narration—highly actionable. Weakest: accepts the patch’s validator derivation without the circularity critique.  
**C** agrees on split, TTS stack, and file:// HTML first. Weakest: default video as ffmpeg slideshow+TTS fights the stated world-class motion goal and disagrees with A/B/D; Q6 puts a four-medium smoke gate before the standalone HTML milestone, which clashes with its own Q4 priority.

DISAGREEMENTS  
**Q1:** Consensus to split; **B and D** right that count derivation from self-referenced receipts/tests weakens the gate—prefer independent versioned expectations (B’s spec bump is clearest).  
**Q2:** All require tool-enabled grading; **A/C** lean one-topic/four artifacts, **B/D** eight with holdout—**B/D** better for honest generalization; **D** rightly narrows “world-class” wording.  
**Q3:** Consensus: Kokoro → `say` → Web Speech (non-archival).  
**Q4:** Consensus: standalone file:// HTML first, lab second (B’s lab bundle step is a plus).  
**Q5:** **A/B/D** default hyperframes→MP4; **C** defaults slideshow+TTS—**A/B/D** fit explainer motion and agent reliability on HTML; slideshow stays fallback only.  
**Q6:** All split method then candidate; order of gate vs pipelines differs—**A/B** gate after routing then one proof run is cleaner than **C**’s gate-before-generator sequencing.

WATCH-OUTS  
1. Treating validator count derivation from candidate-controlled artifacts as sufficient governance—chairman should not endorse without independent pinned expectations (B/D).  
2. **C**’s slideshow-default video and early four-medium gate before a file:// interactive path risks proving the wrong delivery surface.  
3. None of the answers fully resolves defect 7 beyond re-recording digest—**D**’s “document discrepancy until repaired method lands” avoids false green on provenance.
