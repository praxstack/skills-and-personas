RANKING: B > D > A > C

WHY

B: Strongest: it catches that deriving the counts from the receipt and the test file it checks is circular, and it proposes counts pinned in a versioned spec instead. Its gate has the most concrete machine checks: file:// and HTTP in headless Chrome, ffprobe, transcription error rate, blind grading by Prax. Weakest: M1 runs the routing-only candidate "against the new gate", but that patch makes no media, so it can't pass a media gate.

D: Strongest: the clearest policy fit. It keeps the stale receipt, checks the new digest against current bytes, picks the held-out topic after the freeze, sets hour budgets with a machine-hour cap, and uses the two-no-gain stop rule. It's also honest that passing tests are routing evidence, not media evidence. Weakest: its gate criteria are vaguer than B's, and the prose is heavier.

A: Strongest: tight and actionable. It splits governing from candidate cleanly and won't add more vocabulary or lab lessons until four playable receipts exist. Weakest: it accepts count derivation as-is, uses one topic with no holdout, and gives no real budget or no-gain stop rule.

C: Strongest: a solid tier split in Q1 and a clear "don't claim world-class until M2" rule. Weakest: it makes the ffmpeg slideshow the default video and lets a Web Speech transcript count as narration, so the gate could pass with no motion and no audio file. M2's four-medium gate also comes before the M3/M4 pipelines it depends on.

DISAGREEMENTS

Q1: All four split the patch. They differ on whether the count derivation is acceptable. B and D are right: counts read from the thing being validated can't catch drift, so they need an independent pinned expectation.

Q2: One topic (A, C) or a held-out topic (B, D). The policy requires an evaluator/holdout, so B and D are right. Without a holdout, a single proof topic just gets tuned until it passes.

Q3: Consensus. Kokoro first, then `say`, with Web Speech as a viewer-side extra only, plus a transcript.

Q4: Consensus on single-file HTML first. D is right to add that chat renderers may sanitize or sandbox scripts, so each one needs its own test.

Q5: Hyperframes default (A, B, D) or slideshow default (C). Hyperframes is the better default because a slideshow can't meet a motion-explainer bar. D's framing is the right one: call it provisional and benchmark it, since nobody has measured reliability.

Q6: They broadly agree on governance first, then candidate, then a media proof. Budgets differ: none in A, sessions in C, days in B, hours in D. D's capped hours plus the policy stop rule should win.

WATCH-OUTS

1. Don't carry A's or C's approval of receipt-derived counts. And re-recording the digest must keep the stale record and check against current bytes, not just overwrite it.
2. Nothing on the host has timed or proven hyperframes "agent reliability" or Kokoro render speed. Treat those as hypotheses the pilot measures, not facts.
3. Don't let a Web Speech transcript or a slideshow count as passing narration or video in the gate. That recreates the text-only problem in a new form.