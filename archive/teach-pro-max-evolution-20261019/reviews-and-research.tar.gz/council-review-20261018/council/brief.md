# Council brief: Prax Teach v2 multimedia way forward

You are one member of an LLM council (Karpathy-style: independent answers, then anonymous peer ranking, then a chairman synthesis). Answer on your own, from the facts below. Do not run tools, do not browse, do not edit files. Write in plain human voice, answer first, no filler. Keep it under 700 words.

## Facts (verified 18 Oct 2026 by a review of the shipped package)

Prax Teach v2 is a teaching skill for coding agents (Codex, Claude Code). It ships as a ZIP: a root loader `SKILL.md`, the authoritative teacher in `.engine/SKILL.md`, a 1637-file hashed manifest, a `configure.py` that verifies hashes and writes an evidence pin, a regex router `scripts/prax_teach.py` (routes: none / static / interactive / motion), a 38-tool visualization registry, a zero-dependency interactive runtime called Prax Visual Lab, and a deterministic Markdown-to-HTML renderer. Governance follows an identity-preservation policy: a change may touch the candidate OR its governing spec/evaluator/gates, never both in one run; governing changes need explicit human approval and a new version; acceptance only through gates with receipts.

What the review found:
1. The four packaging claims hold (one Codex entry, engine byte-identical to commit 389f6f9, setup/routing/rendering/validation pass, 22 JS tests pass), with two conditions: JS tests need `npm ci` in three directories, and the validator only passes after configure writes its evidence pin.
2. The accepted teaching evaluation was tool-disabled text only. No receipt anywhere exercised a rendered image, an interactive page, a video, or audio. The grader report says so itself.
3. Still images: policy and registry exist (Mermaid, Excalidraw, matplotlib, Graphviz and others), but every rendered lesson in the evidence is a text transcript with no figure.
4. Interactive: Prax Visual Lab works, but implements exactly one lesson (Python floating point) and only mounts over HTTP because it uses ES modules with a strict CSP. Opened from file:// it shows the fallback text.
5. Video: policy prose and registry entries (Manim 0.22, ffmpeg, Remotion, hyperframes) exist, but the router did not know the words video, clip, animated. "A short explainer video of how a neuron fires" routed to `none`; "make me a video explaining X" routed to ordinary task, not teaching. No video artifact was ever produced.
6. Narration / TTS: nothing. No route, no registry entry, no doc line. The host Mac has `hyperframes tts` (Kokoro-82M, local, v0.8.169), macOS `say` (188 voices), ffmpeg, Manim, Chrome headless, Node 24, Python 3.13.
7. A pre-existing defect: `evidence/provenance/legacy-assets.json` records a stale SHA-256 for `references/LEGACY-VISUALIZATION-ROUTER.md` (matches an older baseline, not the accepted bytes). The pinned validator never checks against current bytes, so it was masked.
8. The validator hard-codes registry counts (38 tools / 12 tests), so any registry growth fails validation unless the validator itself changes.

A candidate patch exists, tested, uncommitted, not installed (branch `candidate/media-routing-20261018`, 15 files, +2332/-398). It adds: video and animation vocabulary to the motion route; a `narration` flag on visual routing with a host-speech surface and a transcript fallback; three registry tools (web-speech-api, hyperframes-tts, macos-say; registry now 41); a media-explainer rule so "video explaining X" counts as a teaching request; docs updates; an HTTP-serving note for the lab; 8 new fixture cases and tests. It ALSO changes `scripts/validate_workspace.py` to derive the registry counts from the receipt and the test file instead of hard-coding them, and re-records the stale digest in the provenance receipt. All relevant tests pass (65 routing/CLI/validator, 13 registry, lint clean, 43 renderer pairs). Note: the validator and provenance receipt are part of the governing "method" tier, so the patch as it stands mixes candidate and governing changes.

Prax's stated goal: the skill must be able to produce world-class explainer visualisation across still, interactive, video, and TTS/narration.

## Questions for the council

Q1. The candidate patch mixes candidate changes (router, registry, docs, tests) with governing changes (validator count derivation, provenance digest re-record). Should it be accepted as one, split into two versions, or reworked? Say which parts need Prax's explicit approval and which do not.

Q2. "World-class across four media" is currently unproven and the acceptance gate was text-only. Define the smallest honest acceptance gate that would actually prove it: what artifacts per medium, what receipts, who grades, and whether the grader needs tools. Treat this as a governing change proposal.

Q3. Default narration stack for a local Mac agent: hyperframes tts (Kokoro, local, high quality, slow-ish), macOS `say` (instant, lower quality), or in-browser Web Speech API (no file, viewer-side). Pick one default and the fallback order, with reasoning.

Q4. Interactive: should the next investment expand Prax Visual Lab (ES modules, needs HTTP, one lesson) with more lessons, or should the skill generate standalone single-file interactive HTML that works from file:// and chat renderers? Or both, in what order?

Q5. Video: for "explainer video of X", which default pipeline: Manim scenes, hyperframes HTML/GSAP compositions rendered to MP4, or an ffmpeg slideshow of stills plus TTS audio? Consider quality ceiling, reliability from an agent, and render time.

Q6. Sequencing and stop rule: order the work (Q1 to Q5) into milestones with a budget, and say where the human must decide versus where the agent should just proceed. Name the two or three decisions that are genuinely Prax's.

Format your answer as six short sections Q1..Q6, each starting with a one-line recommendation in bold, then at most five sentences of reasoning.
