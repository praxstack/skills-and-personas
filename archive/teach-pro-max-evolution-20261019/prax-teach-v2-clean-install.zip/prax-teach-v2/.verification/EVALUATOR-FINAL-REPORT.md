# E6 independent teaching evaluation

Primary teaching gates and receipt integrity passed. All four secondary content and transport checks passed. Overall acceptance remains the coordinator’s separate decision.

Candidate source: `389f6f9067c40de4ebed10a48d6048ed90d58b0c`. Original and current accepted baseline: `286a98fc67486fa91bb19f34a9c0be347f5db029`.

Primary mean: **8.555556 → 10.000000/10**, paired gain **+1.444444**. Three families improved; all three baseline-below-ceiling families were required to improve. There were no family regressions, candidate zero dimensions, or candidate protected failures.

| Family | Baseline repetitions | Baseline mean / range | Candidate repetitions | Candidate mean / range |
|---|---|---|---|---|
| v601 | 5, 5, 5 | 5.000000 / 5–5 | 10, 10, 10 | 10.000000 / 10–10 |
| v602 | 10, 10, 10 | 10.000000 / 10–10 | 10, 10, 10 | 10.000000 / 10–10 |
| v603 | 10, 10, 8 | 9.333333 / 8–10 | 10, 10, 10 | 10.000000 / 10–10 |
| v604 | 10, 10, 10 | 10.000000 / 10–10 | 10, 10, 10 | 10.000000 / 10–10 |
| v605 | 10, 1, 10 | 7.000000 / 1–10 | 10, 10, 10 | 10.000000 / 10–10 |
| v606 | 10, 10, 10 | 10.000000 / 10–10 | 10, 10, 10 | 10.000000 / 10–10 |

All seven frozen numeric/protected gates passed: candidate mean≥8, every candidate family≥7, no candidate zero dimensions, no candidate critical failures, paired gain≥1, no family regression, and the ceiling-aware improvement count. Five baseline transcripts had an explanation barrier; the candidate had none.

The independent grader read all 36 complete masked conversations, recorded 180 dimension-specific quotations and 216 protected-invariant assessments, checked quotation UTF-8 bytes, and froze the grades before labels were opened. The frozen aggregate was produced once using the unchanged helper. No scores changed after unblinding.

Blind grades SHA256: `998f2a43e36d02360968a0f1d0ad7e7cfca34930f6e51670d87c65e854a07712`.
Aggregate SHA256: `82ad9a10e93ffc958f1b88a11c99f10de40707421e7ac9cd06594a43143585b8`.

Claude was graded only after primary grades were frozen and aggregated. Actual retained model metadata identifies `claude-opus-5-5`, CLI `2.1.300 (Claude Code)`. The four independent content scores were **10, 10, 9, 10**; all four passed content and transport, with zero material accuracy or protected failures. Noncritical wording/representation limitations are retained in the private case assessments and safe secondary review.

Exact observed budget: **36** complete primary arm transcripts, **54** primary CLI generations, **4** secondary calls, **40** evaluated runs and **58** target generations total; **0** retries. All target calls completed before the frozen deadline. No new target calls were made by the grader.

The receipt audit independently verified frozen pins, archive commit comments and hashes, all 767 payload-file hashes, six case commands/configurations, exact source bundle and retained-package hashes, all 54 stdout/stderr/response hash receipts, complete transcript bytes, exact prior-role replay prompts, no tool/error events, and all four secondary event streams and output hashes. The requested primary model is pinned as `gpt-6.1-sol`; retained primary JSONL does not separately expose a served-model identity.

This is tool-disabled text teaching with static representations. It does not establish browser rendering, audio playback, video quality, actual persistence, human learning, retention or mastery. Boundary evidence reuses the prior measured runner plus reviewed delta; this grader made no new same-byte boundary claim. Full marks apply to this small frozen rubric and scope. Engineering, runtime, rendered-delivery and installation acceptance require their own evidence.

Safe receipts: `PRIMARY-FINAL.json`, `PRIMARY-INTEGRITY.json`, `SECONDARY-REVIEW.json`. Private transcript/anchor evidence remains under `grading/`; this report contains no holdout prompts or anchors.
