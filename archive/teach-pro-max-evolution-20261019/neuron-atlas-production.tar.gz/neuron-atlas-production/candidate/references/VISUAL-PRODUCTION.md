# Explanatory production craft

Use this reference for substantial still, interactive or narrated artifacts. It supplements the accepted teaching policy; it does not change consent, optional assessment, privacy, source integrity or evidence requirements. Its recipes are choices, not a universal scene quota or mandated stack.

## Begin with a relationship, not a template

State what the learner should see change and why. A figure should reveal a mechanism, useful comparison or structure; an equation, diagram and control must describe the same conditions. Identify the smallest complete causal chain and its misconception. Choose the representation before choosing a renderer.

Write a compact art direction: hierarchy, composition, visual vocabulary, typography, color meanings, density, screen/export size and responsive alternative. A palette alone is not a design. Give each significant mark a job; remove unexplained hubs, grid lines, decorative arrows and ambient motion. Use breathing room to separate relationships, not to pad an empty stage. Retain a complete immediately accessible overview while replay or layers focus attention.

For a technical figure, direct labels and exact values beat distant legends. Label direction, units, assumptions and relevant domain. Use shape or words alongside color. Positive and negative contributions must remain distinguishable if the palette is removed. Put the mathematical notation beside the geometric object it describes. A dark, light or high-contrast style can all work; adapt to the learner instead of treating one brand palette as a quality certificate.

## Make the mathematics an independent authority

Use one executable model for controls, outputs and worked snapshots when practical. Separate its semantics from layout and style. Test literal cases independently, check gradients against finite differences away from nondifferentiable points, and disclose conventions at kinks. Check dimensional consistency, domains, axis direction/range, signs, normalization and units. Do not use a second untested calculator in the video.

Display rounding honestly. An animation that interpolates between two valid endpoints can still pass through invalid or misleading intermediate states. Animate a model parameter and recompute dependent quantities, or label a nonphysical transition as visual repositioning. Never imply that a morph between formulas proves an algebraic step.

Generated imagery can supply atmosphere, appearance or a metaphor; composite authoritative labels, equations, geometry and charts with exact tools. Rasterizing an exact vector at delivery does not invalidate its semantics, but retain the editable vector and inspect the raster's smallest label at its intended viewing size.

## Choose the medium by the cognitive job

| Learner needs | Strong starting point | Failure to avoid |
| --- | --- | --- |
| See a mechanism at once | Exact annotated SVG/HTML or scientific plot | A diagram of generic boxes that omits the operative relationship |
| Compare conditions | Aligned small multiples or baseline/current view | Asking the learner to remember an overwritten prior state |
| Test a cause | Native controls coupled to a deterministic model | Many sliders whose effects are only visible in a distant numeric readout |
| Open an explanation | Native details/summary or accessible disclosure | Hover-only answers or essential information hidden by default |
| Recall optionally | Explicit flashcard reveal with reset/next | Implying a flip or self-rating proves mastery |
| Watch a transformation | Seekable geometric/vector animation | Slide fades or text substitution described as explanatory motion |
| Follow a narrated story | Timed visual model plus measured audio/captions | Narration reading a wall of text while the mechanism stays inert |
| Explore inside a film | Native video clock linked to chapters/transcript/live model | A second timer drifting from the video or editable controls silently changing recorded facts |

Consult the maintained tool registry and current host. A listed tool, installed CLI, successful render and excellent output are four different observations. Use existing domain tools before building a general platform. The demonstrated neuron example is a production recipe, not a general renderer for every topic.

## Still-image recipe

1. Compose an editable vector at the delivery aspect ratio. Use a reading order that carries the causal relationship; not every mechanism belongs left-to-right.
2. Encode quantitative relationships in geometry where useful. For signed sums, show origin, positive/negative direction and the resulting coordinate; ensure bar length corresponds to magnitude.
3. Add one useful contrast: an inactive state, boundary case or competing interpretation. Label its changed conditions.
4. Export SVG plus high-resolution PNG/PDF when the requested destinations need them. Preserve live text in editable source; check fonts and licensing before embedding fonts.
5. Inspect at full size and intended display size, in grayscale where semantic color matters, and at print scale. Check clipping, overlap, confusing adjacency and label density.

## Interactive explorer recipe

The first view should already explain the whole relationship. Expose one purposeful action with its effect nearby, then offer more controls where useful. Maintain a fixed baseline when comparing changes; make reset explicit. Distinguish changing an input, changing a parameter manually and performing a training update.

Prefer a single model state, derived outputs and explicit transitions. Apply multi-parameter optimizer updates simultaneously from old gradients. Validate numbers at the boundary and reject invalid/out-of-range updates without partial mutation. Do not silently clamp and then display the unclamped value.

Mobile requires recomposition, not uniform shrinking or a clipped desktop canvas. Keep the complete simple mechanism readable at once: landscape flow can become a vertical sequence or matched small multiples. A genuinely dense figure may scroll, but provide a readable overview and textual equivalent. Check the actual effect after each representative control change; 'no NaN' and 'no document overflow' do not establish correct or readable interaction.

For Q&A, make the question a meaningful visible summary and reveal a concise explanation linked to the model. For flashcards, provide an explicit reveal action, keyboard focus and a stable reading order. Preserve learner agency: optional practice is review material unless actual performance is collected with consent. No hidden score or completion-based mastery.

## Narrated video recipe

Write the spoken explanation and visual beats together. Say what the animation cannot show alone; avoid reading every visible label. Choose a voice appropriate to language and context, and record engine, model/voice ID, speed and licence/use terms. Spell symbols and abbreviations for speech deliberately; a symbol name and its displayed mathematical meaning must agree.

Synthesize segments, measure actual durations and use those durations for the timeline. Include breathing room for a new equation or a critical result. Keep scene/caption boundaries on known media times; avoid truncating the final word with a shortest-input mux. Segment captions into readable phrases, preserve meaningful punctuation, and retain a complete transcript. Human listening or a capable audio-review tool must assess pronunciation, pacing, intelligibility and artifacts before claiming that review occurred. ASR and waveform statistics are useful checks, not substitutes for listening.

Use a deterministic seekable timeline. Motion should reveal accumulation, influence, transformation or timing; retain stable entity names/colors. Vary composition when the relationship changes, not colors randomly between scenes. Inspect representative intermediate states, not only polished endpoints. Render a draft to check timing, then export the requested final resolution/frame rate with audio and captions. Confirm duration, dimensions, streams, black/frozen-frame surprises and end-of-audio coverage. A silent render is not a narrated-video success.

## Interactive-video explorer recipe

Use the native video's currentTime and seeking/seeked/timeupdate events as the source of truth. Choose an active cue with an explicit half-open interval [start,end), with a defined final-frame behavior. Allow direct concept links and transcript seeking. A jump backward or playback-rate change must update the explanation correctly without replaying prior events.

Keep recorded facts and live experimentation separate. One workable state machine:

- FILM: recorded example and media-clock-driven explanation; no claim the controls affect the prerecorded pixels.
- EXPLORE: learner deliberately pauses the film, captures return time and previous playback state, and opens the live model with a named preset.
- RETURN: restore the recorded context/time, remove the live-state ambiguity, then resume only as the explicit action requests. Do not autoplay audio on initial load or surprise the learner on a focus event.

Use native video controls, captions, readable transcript, chapter links and a static key-state equivalent. For portable file-based delivery, classic scripts avoid file:// ES-module restrictions; inline cue data can construct TextTrack/VTTCue while a standalone WebVTT file is also shipped. Test file:// and served modes if both are promised. Missing media must show a useful error and static explanation, not a blank player. A normal video player plus a disconnected slider is not an interactive-video explorer.

## Review the finished experience

Review five separate claims:

1. Mathematical/scientific correctness: equations, numbers, domains and encoded relationships.
2. Explanatory craft: does the artifact make the intended connection visible without requiring the author to explain the interface?
3. Aesthetic craft: hierarchy, composition, rhythm, typography, density, direct labeling and coherent visual language at actual display size.
4. Interaction/media delivery: actual parameter effects, comparison/reset, keyboard/focus, seek behavior, synchronization, captions and audio.
5. Portability/access: local assets, responsive reflow, static/no-script route, reduced motion, print, and clear evidence of what assistive-technology or listening checks were not performed.

An author cannot establish these merely by reading their own source. Obtain an independent rendered review when feasible; give the reviewer the actual artifact and task rather than a desired conclusion. Keep failures and changes inspectable. Recheck the affected states after a fix; do not keep regenerating correct media without a reason.

An approved plan is not a delivered artifact; a test count is not a quality score; a satisfying explanation is not measured durable learning. Use precise claims: what was inspected, what worked and what remains unknown. Do not self-certify every topic or every future artifact as 'world-class'.

## Demonstrated production example

In this review bundle, `candidate/` and `demo/` are siblings. These relative links refer to the delivered example, not to an installed global path:

- [Interactive model, Q&A, flashcards and video explorer](../../demo/index.html).
- [Exact baseline SVG](../../demo/exports/baseline.svg), [inactive contrast SVG](../../demo/exports/inactive.svg), [updated SVG](../../demo/exports/trained.svg), and [portrait SVG](../../demo/exports/baseline-portrait.svg).
- [Narrated MP4](../../demo/video/neuron-narrated.mp4), [captions](../../demo/video/captions.vtt), [transcript](../../demo/video/transcript.md), [editable film source](../../demo/video/film.py) and [media metadata](../../demo/video/metadata.json).
- [Authoritative model](../../demo/model.js), [generated model snapshots](../../demo/model-snapshots.json), [static mathematical explanation](../../demo/lesson.html) and [delivery/evidence summary](../../reports/DELIVERY.md).

The proposed patch is an instruction overlay, not a complete installable skill. If promoting it into a complete skill package, include the worked example at the chosen package-relative examples location and adjust these example links as part of that separately versioned package. Do not claim this review-bundle layout installs on its own.
