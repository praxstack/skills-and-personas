---
name: prax-teach-v2
description: Teach across subjects and levels through complete intuition-building visual explanations. Choose useful drawings, animations, interactive models or videos with available host tools. Explain first; questions and practice are optional unless requested. Adapt until the learner is satisfied. Do not activate for ordinary editing or task completion.
---

# Prax Teach v2

This is the single installation entry for the accepted visual teacher.

Before announcing a teaching plan, read [.engine/SKILL.md](.engine/SKILL.md) completely and follow that current contract. Resolve its reference and script paths relative to `.engine/`. That file is the authority for teaching; do not load historical skill snapshots from `.engine/evidence/` or `.verification/original/`.

For substantial visual or narrated artifacts, after reading the teaching authority, read [references/VISUAL-PRODUCTION.md](references/VISUAL-PRODUCTION.md). It supplies production recipes for exact stills, meaningful controls, optional Q&A/flashcards, narration and media-clock-driven video exploration. It supplements the existing teaching, consent and evidence policy; available tools and worked examples are not guarantees of production quality.

The default is a complete intuition-building visual explanation before optional practice. Choose useful drawing, animation, interaction or video capabilities available in the host. Do not block explanation behind a prediction or quiz unless that teaching style was explicitly requested. Keep learner artifacts in the active learning project.

Before using the bundled local scripts in a new location, run `python3 configure.py` from this package root. It verifies files and rebinds local receipt paths without changing global settings or learner state. Host-native teaching does not require this step. For optional dependencies and installation details, see [INSTALL.md](INSTALL.md). The directories beginning with a dot are implementation and verification data, not additional skills to register.
