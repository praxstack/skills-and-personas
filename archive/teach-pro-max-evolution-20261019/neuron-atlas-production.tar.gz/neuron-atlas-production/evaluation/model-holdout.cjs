#!/usr/bin/env node
'use strict';

// Frozen independently of the candidate implementation. Do not weaken on failure.
const assert = require('node:assert/strict');
const path = require('node:path');
const modelPath = path.resolve(process.argv[2] || path.join(__dirname, '../demo/model.js'));
const { BASE, evaluate, step } = require(modelPath);
const keys = ['x1', 'x2', 'w1', 'w2', 'b', 'target', 'eta'];
const initial = { x1: .8, x2: .4, w1: 1.5, w2: -1, b: -.2, target: 1, eta: .5 };
let checks = 0;

function close(actual, expected, label, tolerance = 1e-11) {
  assert.equal(typeof actual, 'number', `${label}: numeric output`);
  assert.ok(Number.isFinite(actual), `${label}: finite output`);
  assert.ok(Math.abs(actual - expected) <= tolerance * Math.max(1, Math.abs(expected)),
    `${label}: expected ${expected}, received ${actual}`);
  checks++;
}
function snapshot(s) { return JSON.stringify(s); }
function expected(s) {
  const c1 = s.x1 * s.w1, c2 = s.x2 * s.w2;
  const z = c1 + c2 + s.b, a = z > 0 ? z : 0;
  const error = a - s.target, loss = error * error / 2;
  const dz = z > 0 ? error : 0;
  return { c1, c2, z, a, error, loss, grad: { w1: dz * s.x1, w2: dz * s.x2, b: dz } };
}
function inspect(s, literal, label) {
  const before = snapshot(s), out = evaluate(s);
  for (const k of ['c1', 'c2', 'z', 'a', 'error', 'loss']) close(out[k], literal[k], `${label}.${k}`);
  assert.ok(out.grad && typeof out.grad === 'object', `${label}.grad exists`);
  for (const k of ['w1', 'w2', 'b']) close(out.grad[k], literal.grad[k], `${label}.grad.${k}`);
  assert.equal(snapshot(s), before, `${label}: evaluate must not mutate state`);
  checks++;
  return out;
}
function checkStep(s, label) {
  const before = snapshot(s), e = expected(s), next = step(s);
  assert.ok(next && next !== s, `${label}: returns new state`);
  for (const k of keys) {
    const want = ['w1', 'w2', 'b'].includes(k) ? s[k] - s.eta * e.grad[k] : s[k];
    close(next[k], want, `${label}.${k}`);
  }
  assert.equal(snapshot(s), before, `${label}: simultaneous update leaves original intact`);
  checks++;
  inspect(next, expected(next), `${label}.evaluation`);
  return next;
}
function rejects(fn, label) {
  assert.throws(fn, e => e instanceof RangeError || e instanceof TypeError, label);
  checks++;
}

assert.equal(typeof evaluate, 'function');
assert.equal(typeof step, 'function');
assert.ok(Object.isFrozen(BASE), 'BASE must be frozen');
for (const k of keys) assert.equal(BASE[k], initial[k], `BASE.${k}`);
const baseBefore = snapshot(BASE);

inspect(Object.freeze({ ...initial }), {
  c1: 1.2, c2: -.4, z: .6, a: .6, error: -.4, loss: .08,
  grad: { w1: -.32, w2: -.16, b: -.4 }
}, 'literal baseline');
const updated = checkStep(Object.freeze({ ...initial }), 'literal simultaneous update');
for (const [k, n] of Object.entries({ w1: 1.66, w2: -.92, b: 0 })) close(updated[k], n, `literal next.${k}`);
close(evaluate(updated).a, .96, 'literal next prediction');
close(evaluate(updated).loss, .0008, 'literal next loss');

const inactive = Object.freeze({ ...initial, b: -1 });
inspect(inactive, { c1: 1.2, c2: -.4, z: -.2, a: 0, error: -1, loss: .5,
  grad: { w1: 0, w2: 0, b: 0 } }, 'literal inactive');
const inactiveNext = checkStep(inactive, 'inactive update');
for (const k of keys) close(inactiveNext[k], inactive[k], `inactive unchanged.${k}`);

// Binary-exact kink fixture avoids making a rounding accident define the convention.
const kink = Object.freeze({ x1: 1, x2: 1, w1: 1, w2: -1, b: 0, target: 1, eta: .5 });
inspect(kink, { c1: 1, c2: -1, z: 0, a: 0, error: -1, loss: .5,
  grad: { w1: 0, w2: 0, b: 0 } }, 'zero derivative convention');
checkStep(kink, 'zero derivative update');

for (const [i, s] of [
  { x1: -1.25, x2: .75, w1: -1.2, w2: .8, b: -.15, target: -.5, eta: .05 },
  { x1: 0, x2: -1, w1: -2, w2: -.75, b: .25, target: 0, eta: .2 },
  { x1: 1, x2: 0, w1: 0, w2: -2, b: .5, target: -.5, eta: 0 },
  { x1: -1, x2: -1, w1: 1, w2: 1, b: -1, target: 2, eta: 1 }
].entries()) {
  inspect(Object.freeze(s), expected(s), `signed/zero fixture ${i}`);
  checkStep(Object.freeze(s), `signed/zero step ${i}`);
}

// Deterministic independent holdout generation; values are not exported to authoring fixtures.
let seed = 0x6e657572;
function random() {
  seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
  return (seed >>> 0) / 4294967296;
}
function range(a, b) { return a + random() * (b - a); }
let accepted = 0, attempts = 0;
while (accepted < 72 && attempts++ < 1000) {
  const s = { x1: range(-1.5, 1.5), x2: range(-1.5, 1.5),
    w1: range(-1, 1), w2: range(-1, 1), b: range(-.8, .8),
    target: range(-1, 1), eta: range(0, .03) };
  const truth = expected(s);
  if (Math.abs(truth.z) < .15) continue;
  const label = `holdout ${accepted++}`, out = inspect(Object.freeze(s), truth, label);
  for (const k of ['w1', 'w2', 'b']) {
    const h = 1e-6;
    const up = { ...s, [k]: s[k] + h }, down = { ...s, [k]: s[k] - h };
    const derivative = (expected(up).loss - expected(down).loss) / (2 * h);
    close(out.grad[k], derivative, `${label}.central derivative.${k}`, 2e-7);
  }
  checkStep(s, `${label}.step`);
}
assert.equal(accepted, 72, 'holdout generator must fill its sample');

const bounds = { x1: [-2, 2], x2: [-2, 2], w1: [-3, 3], w2: [-3, 3],
  b: [-3, 3], target: [-2, 2], eta: [0, 1] };
for (const [k, [lo, hi]] of Object.entries(bounds)) {
  for (const value of [lo, hi]) {
    const s = Object.freeze({ ...initial, [k]: value });
    inspect(s, expected(s), `inclusive bound ${k}`);
  }
  for (const value of [NaN, Infinity, -Infinity, lo - .0001, hi + .0001, '1', null, undefined, true]) {
    const s = { ...initial, [k]: value }, before = snapshot(s);
    rejects(() => evaluate(s), `evaluate rejects invalid ${k}`);
    rejects(() => step(s), `step rejects invalid ${k}`);
    assert.equal(snapshot(s), before, `invalid ${k} stays unchanged`);
  }
  const missing = { ...initial }; delete missing[k];
  rejects(() => evaluate(missing), `missing ${k}`);
  rejects(() => step(missing), `step missing ${k}`);
}
for (const value of [null, undefined, [], 1, 'state']) {
  rejects(() => evaluate(value), 'invalid state container');
  rejects(() => step(value), 'invalid step state container');
}

// Old gradient drives every parameter. A bound crossing must reject the entire operation.
for (const s of [
  { x1: 2, x2: 2, w1: 3, w2: 3, b: 3, target: -2, eta: 1 },
  { x1: 2, x2: 0, w1: 2, w2: 0, b: -3, target: -2, eta: .5 },
  { x1: -2, x2: 0, w1: -3, w2: 0, b: 0, target: -2, eta: 1 }
]) {
  const before = snapshot(s);
  rejects(() => step(s), 'atomic out-of-bounds update');
  assert.equal(snapshot(s), before, 'rejected update must leave every original field unchanged');
  rejects(() => step(Object.freeze({ ...s })), 'frozen atomic out-of-bounds update');
}
assert.equal(snapshot(BASE), baseBefore, 'BASE remains unchanged after all calls');
console.log(JSON.stringify({ status: 'pass', checks, holdoutCases: accepted,
  scope: 'model exports, literal values, simultaneous updates, derivative convention, numeric holdout, validation and nonmutation' }));
