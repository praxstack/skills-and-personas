# Visual production candidate — product specification v1

Status: frozen after CEO and engineering reviews; implementation decisions authorized by the user's autonomous-run request. This does not claim the user reviewed this document. This is a new isolated production run, not an edit to the accepted skill's governing evaluator or human-owned identity policy.

## Outcome

Deliver a rigorous issue inventory and a researched matrix of 20 production approaches, plus a portable candidate addition to Prax Teach demonstrated through a coherent, mathematically correct neuron explanation in still, interactive, Q&A, flashcard, narrated-video and interactive-video forms. Excellent aesthetics are an explicit product target; neither test counts nor self-awarded adjectives establish it.

## Scope

One complete, carefully art-directed artificial-neuron mechanism is the implementation slice. It explains inputs, signed contributions, bias, ReLU, loss and one real gradient update. It bridges to layered networks without claiming a full deep-learning curriculum. The original course and accepted package remain unchanged. Candidate instructions and runnable examples are reviewable separately. No general rendering platform, new accounts, paid generations, publication, analytics, learner profiles or compulsory assessments.

## Exact model and symbols

Inputs x₁=0.8 and x₂=0.4. Weights w₁=1.5 and w₂=−1; bias b=−0.2. z=w₁x₁+w₂x₂+b=0.6. ReLU a=max(0,z)=0.6. For target y=1 and squared loss L=½(a−y)², L=0.08. At this active ReLU state gradients (∂L/∂w₁,∂L/∂w₂,∂L/∂b)=(−0.32,−0.16,−0.4). With simultaneous gradient descent rate η=0.5, updated parameters are (1.66,−0.92,0), prediction0.96 and loss0.0008. At z≤0, use the explicit ReLU derivative convention0; never imply this is a biological neuron simulator. Inactive contrast with b=−1 gives z=−0.2,a=0.

All numerical visual views derive from one browser/Node executable model and one shared preset fixture. An independent evaluator can check literal values and finite differences. Distinguish model precision, displayed rounding and measured facts. Preserve signs, axes, domains, units (dimensionless toy values) and model assumptions.

## Requirements

- R1: Issue inventory distinguishes observed defects, reasoned risks, preferences, unknowns and observable shortcuts; critique work rather than infer a person's intent. Include portability, accessibility, math, production and evidence claims.
- R2: Exactly20 distinct researched approaches, direct primary sources, suitability, limits, outputs, accessibility and actual availability; recommend by semantic job rather than popularity.
- R3: Editable exact SVG still plus high-resolution PNG. Labels and mathematical relationships remain text/vector; no generated-image authority. Include meaningful negative and inactive contrasts.
- R4: Responsive interactive model exposes the whole computation at desktop and390px without hiding a required node behind horizontal scrolling. Native labeled controls, explicit reset, fixed baseline vs current comparison, immediate explanatory output and parameter-locking during narration if needed.
- R5: Q&A expansion and flashcard reveal are functional and optional. No assessment grade, mastered label, persistent learner state or answer-before-attempt claim.
- R6: Narrated MP4 with real changing mathematical geometry (not only crossfading slides), editable source, local synthesis provenance, measured duration, captions/WebVTT, transcript and representative keyframes. No autoplay audio or music that masks narration.
- R7: Interactive-video explorer supports seeking by concept, synchronized current-concept text, transcript selection, replay, deliberate pause-to-explore and resume. Exploring must not silently alter prerecorded video facts: clearly distinguish fixed recorded example from live model. Native video controls and readable static alternative remain available.
- R8: Candidate skill guidance is progressive disclosure: a compact entry addition, detailed production playbook and links to actual demonstrated artifacts. No change to original evaluators, policy or historical receipts; no universal framework.
- R9: Tests inspect actual numerical/control outcomes, preset and gradient parity, seek cue transitions, reset and playback synchronization. Browser review covers desktop/mobile, tab/focus, reduced motion, no-script, zoom/reflow, console and frame/image output. Audio metadata/ASR are not subjective listening review; state any unperformed listening/AT checks.
- R10: Deliver a portable local bundle, reproduction instructions, source/provenance metadata and honest evidence report. No absolute author-machine dependency in learner runtime. External sources linked; generated artifacts work offline after extraction. Runtime needs no package install.

## Art direction

Scientific atlas: midnight navy canvas, soft lavender for positive contribution, coral for opposing contribution, mint for resultant output. Modern sans text, precise mono numbers, restrained display typography. Strong composition, direct labels, signed geometric encoding, minimal ornamental surfaces. Responsive recomposition preserves the complete causal chain. Reject generic repeated lab cards, giant empty hubs, unlabeled ornaments, arbitrary color changes and equations separated from the object they explain. Fonts use shipped/local fallbacks without mandatory network access.

## Engineering decisions before freeze

Use one pure browser/Node JavaScript model, immutable baseline and shared preset/timeline data. Compute all gradients from the pre-update snapshot and update all parameters simultaneously; no display rounding feeds computation. Reject non-finite inputs; explicitly show the zero-gradient inactive/kink convention rather than claiming a finite-difference derivative at z=0.

Use a static learner bundle with classic scripts or an equivalent self-contained build that actually opens via file://. No runtime fetch, ESM import, CDN or installed package is required. Inline caption/cue data can populate native TextTrack/VTTCue for local-file playback; also ship the independent WebVTT file and transcript. Test the extracted artifact from a different path with network disabled, as well as localhost. MP4 and other assets use relative paths.

The video's currentTime is the only film clock. Film mode locks the companion scene to recorded snapshots. Explore pauses playback, captures its return time and enables a separately labeled live state. Return restores the recorded scene/time and resumes only after a deliberate user action; native play during exploration must perform the same return transition. Seeking, replay, ended, metadata-not-ready, rejected play and missing media have deterministic recovery. Native controls, visible error text and the complete static explanation remain available.

Proposed source boundary is at most eight meaningful modules: model, authored content/timeline, browser host, styles, still builder, film renderer, local narration/build orchestration, and checks. Generated frames/assets do not create new services. Snapshot JSON exported from the JS model supplies any Python/Manim renderer; a second implementation of the neuron math is prohibited. Render sequentially within local resources, then record measured size/duration and inspect actual frames and audio.

## Acceptance and evidence boundaries

Mathematical/control/portability criteria are hard pass/fail. Aesthetic review is separate: independent reviewer inspects finished still and actual browser states against the rejected artifact and this art direction; every specific required finding is resolved or explicitly remains open. No automatic or universal 'world-class' certification. Test suite changes cannot turn a failing candidate into a passing one within the same frozen run. Practice is optional. No learner performance or learning improvement claim.

## Work sequence

CEO review → engineering review → freeze this spec/run boundary → implement coherent media slice → independent code/quality review → repair candidate only → recheck changed scope. At most two correction candidates, or stop after two no-gain candidates or budget expiry. Preserve rejected outputs and receipts. Do not run an infinite loop.
