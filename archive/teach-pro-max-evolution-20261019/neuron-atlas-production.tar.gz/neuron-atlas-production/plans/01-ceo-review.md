---
status: REVIEWED_WITH_CONCERNS
phase: ceo-review
mode: HOLD_SCOPE
date: 2026-10-18
scope: isolated production candidate and one complete cross-media neuron example
---
# CEO review: Prax Teach visual production v2

Recommendation: deliver one excellent artificial-neuron explanation across stills, a causal interactive explorer, optional Q&A/flashcards, a short narrated video, and an explorer synchronized with that real video. Extract portable production guidance into an isolated candidate. The central proof is the learner's finished experience, including audible narration and inspectable intermediate mechanisms. A rewritten instruction file and a collection of passing tests cannot substitute for that proof.

This is a scope and strategy review, not implementation, code review, a learning study, active installation, or acceptance of a changed evaluator. All implementation and verification below are requirements for later phases, not claims that they ran.

## Authority, evidence, and system audit

The user authorized autonomous decisions inside this task. This spawned review therefore chooses the recommended task options without routine questions, following the skill's spawned-session rule. Upgrades, telemetry, routing injection, account creation, paid services, global configuration changes, and unrelated housekeeping are excluded. Only this plan file is owned by this reviewer. Sidecar task files and global review logs are left to the orchestrator; their absence is disclosed rather than claimed as completed skill machinery.

Read sources:

- `reports/REVIEW.md` in the audit root: current artifact/capability audit, 94 lines; findings are documented observations from that audit, not measurements rerun here.
- `baseline/prax-teach-v2/SKILL.md`: canonical root loader.
- `baseline/prax-teach-v2/.engine/SKILL.md`: accepted teaching authority, read completely.
- `/Users/prax/.agents/skills/gstack-plan-ceo-review/SKILL.md` and its `sections/review-sections.md`: review procedure.

The audit directory is not a Git repository (`git rev-parse --show-toplevel` failed there). Branch, remote, PR base, 30-commit history, diff, stash, and churn comparisons are consequently unavailable for this directory. Do not infer a clean branch or make claims about upstream work from that absence. The audit records accepted source commit `389f6f9067c40de4ebed10a48d6048ed90d58b0c` and ZIP SHA-256 `c4827533185ad7db90aaf3af25edd97f6cf9d3a8b3e868a1b683ef3ba552205f`; these are provenance leads to be checked by the orchestrator's freeze/integrity step. No local `CLAUDE.md`, `TODOS.md`, `DESIGN.md`, or separate architecture document was found by the scoped file inventory. No TODO/FIXME/HACK/XXX matches were found in the two accepted entry files inspected. This is not a whole-package debt scan.

The source audit reports 22 passing JavaScript tests and passing validators while finding poor mobile composition, hidden network mechanisms, disconnected controls, repetitive templates, and no exercised narrated export. Those test results belong to the prior audit. They establish the strategic problem: current engineering checks do not establish production craft.

`DESIGN_SCOPE = true`: diagram composition, responsive reflow, controls, video, captions, optional practice, and interaction states all affect the learner's experience. The separately assigned 20-approach research is an input owned by the orchestrator; no research matrix is fabricated here. Route selection below is conditional on its feasibility findings, existing authorized tools, and the unchanged task constraints.

## Step 0: premise, alternatives, and decisions

### Premise challenge

1. The problem is repeatable explanatory production, with visible deficiencies in an actual delivered course. It is not a missing universal framework.
2. The desired outcome is that a learner can see how inputs become contributions, a sum, an activation, and an output; change a cause; compare the effect; and watch/listen to the same story without contradictory numbers or labels.
3. Doing nothing preserves a technically passing package whose production claims exceed its demonstrated media delivery. Merely changing the palette preserves the causal and responsive defects.
4. A beautiful neuron example does not repair the entire existing course or prove cross-subject generality. It supplies an inspectable reference and a narrower demonstrated production route.

### What already exists

| Subproblem | Existing source/flow | Reuse decision |
|---|---|---|
| Canonical entry and explanation-first behavior | Root loader and `.engine/SKILL.md` | Preserve; candidate guidance must not revive quiz barriers or historical snapshots |
| Exact static lesson and HTML companion | Accepted Markdown renderer and artifact contract | Reuse supported renderer for canonical text; keep rich host artifact distinct |
| Consent, persistence, assessment safety | Accepted teacher and engine | Preserve unchanged; no learner-state tracking needed for this demonstration |
| Visual media routing | `references/VISUALIZATION-ROUTER.md`, inherited handbook, tool registry | Extend guidance in candidate only; do not invent a new platform |
| Browser interaction | Packaged floating-point lab plus supported task-specific HTML/CSS/JS host route | Use host-authored neuron artifact; never label it packaged-runtime verified |
| Static diagram authoring | SVG/HTML and optional Flint route | Reuse exact vector primitives and data; generated imagery cannot own equations/geometry |
| Narration/video | Handbook guidance; audit identifies local synthesis and render tools | Exercise a real route; availability alone is not production evidence |
| Baseline rejected course | Audit screenshots and source locations | Use as an explicit comparison, not a template to recolor |

### Implementation alternatives

These coverage scores describe how much of this task each option covers, not measured product quality.

| Option | Summary | Effort / risk | Pros | Cons | Reuses | Coverage |
|---|---|---|---|---|---|---|
| A: minimal patch | Tighten candidate prose and polish one still plus a basic neuron slider | S; human ~1 day / agent ~1–2h; low implementation risk | Small diff; rapid visual direction; cheap rollback | Omits demonstrated narration, video synchronization, and practice delivery; fails requested breadth | Accepted prose, static renderer, vector diagram | 4/10 |
| B: complete vertical example, recommended | One exact neuron model feeds stills, explorer, optional cards/Q&A, narration timeline and video; extract portable candidate guidance | M/L; human ~3–5 days / agent several focused hours plus render/review time; medium production risk | All requested media have concrete evidence; shared model reduces contradictions; bounded and reversible | Requires real audio/video QA and careful responsive composition; one topic does not prove generality | Accepted contracts, task-specific host route, local media tools | 10/10 for this bounded task |
| C: general media framework | New reusable curriculum/runtime/schema platform and multi-subject renderer | XL; human weeks / agent days with integration uncertainty; high scope risk | Broad future reuse if successful; central infrastructure | Delays visible proof, duplicates supported routes, widens maintenance and policy surface | Selected primitives only | 6/10 now; future breadth is speculative |

Decision D1: choose B. It satisfies the user's requested media and the preference for explicit, engineered-enough work. A omits essential outcomes. C uses infrastructure as a proxy for a good explanation.

Decision D2: HOLD SCOPE. All media above were already requested, so they are not CEO expansions. Review them rigorously without adding a course builder, accounts, publishing service, automatic grading backend, or general rendering engine.

Decision D3: exact subject is a bounded artificial neuron, not a biology-to-deep-learning course rewrite. Show signed contributions, bias, total, ReLU activation curve, output, squared loss and one real simultaneous gradient update. Use the exact fixed example and inactive contrast in `spec/03-product-spec.md`; do not independently select a competing formula or preset. The audited hidden 2→4→1 capstone remains a recorded separate defect; this example must not pretend to fix it.

Decision D4: video is mandatory. A static-state stepper, muted animation, storyboard, or page containing a video-shaped placeholder does not satisfy it. Deliver a playable encoded video with narration, captions/transcript, editable sources, and inspected frames. Interactive-video means actual media time drives the explanatory state, with seek/chapter controls and a clear way to pause and explore a related state.

Decision D5: local, no-account production first. Select the best feasible authorized installed route after the research/tool inventory. Use an available local voice with a short audition and listening review. A more expensive-looking tool is not a reason to introduce billing or accounts. If local narration cannot meet the frozen craft target after the allowed attempts, report that boundary; do not silently relabel a lesser output.

Decision D6: Q&A and flashcards are optional learner actions after the explanation. Provide authored, grounded questions with revealable explanations and transfer-oriented contrasts. No autonomous model service is needed for a finite worked example, and no mastery scores or learner-state writes follow from clicking through it. Label self-study answer reveals accurately; do not market a source-visible static artifact as protected assessment.

Decision D7: every deliverable is candidate-only. Keep baseline, accepted skill, governing evaluator, identity policy, private holdouts, installed symlinks and the existing course protected. The orchestrator freezes the authorized v2 task contract before candidate edits; this plan recommends scope and never silently changes that contract.

### Complexity and temporal decisions

One authored mechanism with render adapters is sufficient. Count meaningful modules rather than generated frames. More than eight source modules or two new services triggers a simplification review; multiple output files are expected for distinct media. No server, database, user account or new service is required.

| Stage | Resolve now | Decision |
|---|---|---|
| Foundations, human hour 1 / agent ~10–20min | What is authoritative? | One exact model and one content/timeline source; freeze protected/mutable paths before edits |
| Core logic, human hours 2–3 / agent ~30–60min | Which experiment explains cause? | Retained baseline/current states; one highlighted parameter and linked contribution/sum/activation; deeper controls progressively disclosed |
| Integration, human hours 4–5 / agent ~45–90min plus media work | What is interactive video? | Actual HTML media element/time as clock; synchronized chapters/scene; user exploration pauses and visibly enters explore mode; explicit return to film |
| Polish/verification, human hour 6+ / agent ~1–3h plus bounded render/listen cycles | What counts as finished? | Math assertions plus observed browser behavior, rendered critique, video decode, captions, and actual listening; no craft claim from test counts |

Effort is planning uncertainty, not a deadline or promise that media review compresses automatically. The stop rule remains the frozen task budget and at most two same-path repair attempts; two no-gain candidates stop rather than weakening standards.

## Dream state delta

```text
CURRENT                            THIS PLAN                         12-MONTH IDEAL
Passing teacher/runtime checks -> One complete, exact, polished -> Portable judgment across subjects
Uneven artifact craft              neuron example across media       with multiple validated exemplars
Unexercised narrated guidance      Candidate production recipes      and truthful capability boundaries
```

The learner should encounter a finished idea immediately, then gain control over it. They can compare two neuron states, see the signed terms move, hear why the activation changes, pause the film at that step and inspect the same quantities, then choose a recall question. The candidate should teach an agent how to select and execute this pattern in another harness without depending on this one implementation. Generality remains an explicit future question.

## Complete issue inventory from the audit

| ID | Observed issue / shortcut | User impact | This plan's response |
|---|---|---|---|
| I1 | `style.css:2` minimum 620px SVG; mobile inspection checked document overflow only | Activation/output leave the readable view | Recompose whole mechanism for narrow screens; inspect relationship visibility, not page overflow |
| I2 | Network capstone shows probability map/loss, hides network/activations/gradients; 100/500/2000-step jumps | Results appear without causes | Neuron example must expose intermediate operations; log the larger capstone as still unfixed |
| I3 | Six controls, no retained baseline, activation curve, reset or contribution focus | Comparison lives in memory; control purpose unclear | Baseline/current comparison, adjacent cause/effect, activation graph, complete reset, progressive controls |
| I4 | Default-state explanatory paragraph does not track changes | Words and picture disagree | Derive live explanation and quantities from authoritative state |
| I5 | Repeated 760×330 stages, identical card shells, empty regions, circles/lines/default sliders | Template styling substitutes for explanatory art direction | Subject-specific composition, explicit visual grammar, density and hierarchy critique on actual renders |
| I6 | Biology blocks have no named meaning; unused `.coach` style | Ambiguous visual semantics; decorative rather than explanatory marks | Every visual encoding maps to a named claim; do not carry biological imagery into artificial neuron without analogy limits |
| I7 | 34 math checks, 58 mostly endpoint control states overread as full quality | Narrow evidence presented as broad completion | Record exact assertions, observed UI states and unperformed checks separately |
| I8 | Keyboard evidence is one slider arrow; reduced-motion evidence a boolean; no-script check a string | Accessibility behavior unproven | Exercise complete control paths, reduced-motion behavior and static explanation; qualify assistive-tech claims |
| I9 | Archived attempt-11 entry used before current clean teacher | Quiz-first behavior falsely attributed to current teacher | Canonical loader only; explanation first; optional practice |
| I10 | Art-direction standard underspecified | Quality depends on agent improvisation | Candidate production brief, comparison patterns, subject-specific layout and independent rendered critique |
| I11 | Packaged browser binding implements floating point | Other-subject runtime claims exceed actual delivery | Task-specific neuron host route; accurate capability label |
| I12 | Video/TTS exist as instructions/tool routes, no exercised export | Requested medium can disappear behind prose | Real narrated export, captions, sync, provenance and listening review |
| I13 | Engineering evaluation lacks an artistic tier | Ugly but correct work passes | Separate frozen craft assessment from unchanged math/policy checks |
| I14 | Historical bounded acceptance excludes generated audio/video | Old scores misused as universal quality proof | Report demonstrated route and topic only; no universal or learning-superiority claims |

This inventory preserves the distinction between execution failure and missing production support. New prose alone does not repair I1–I8, and one neuron example does not repair the complete old course.

## Section 1: architecture review

**WARNING A1:** independent renderers can drift in arithmetic, labels and ordering. Select one pure model and semantic scene/timeline source. Adapters may compose differently by medium, but cannot silently change the example.

**WARNING A2:** the existing floating-point runtime is not a neuron engine. Use its supported host-authoring path rather than expanding and recertifying a universal runtime.

```text
PROTECTED: accepted loader/engine/evaluators/baseline  [read-only comparison]

candidate production guidance             exact neuron model + example data
             |                                      |
             v                                      v
      canonical lesson text <--- semantic states + captions/narration timeline
             |                  |           |                 |
       static HTML          SVG/PNG     interactive       narrated video
       (text companion)     stills       explorer          encoder
                                             \              /
                                              video explorer
                                              actual media clock

OUTSIDE CONTENT HASH: review receipts, assertions, screenshots, listening notes
```

State and adapter coupling is justified because numbers must agree. Display layout must remain decoupled because a phone needs recomposition. A single model defect affects all media; independent expected-value assertions are essential. At 10×/100× example complexity, diagrams, interaction density and video render time fail before local arithmetic. This run deliberately does not generalize to those loads.

```text
model input -> finite/type/range validation -> authoritative state -> render adapters -> files
   nil ---------> missing-input error; no render
   empty -------> empty-scene error; no empty success
   invalid -----> explicit validation error; preserve last valid state
   valid -------> complete state, all intermediates -> complete outputs
   render error ----------------------------------> named failure; no delivery promotion
```

Rollback is directory-level candidate removal or prior candidate selection, never alteration of the accepted symlink. Security boundaries are local files and finite UI inputs; no production endpoints are introduced.

## Section 2: error and rescue map

Names below are proposed explicit error categories, not claims about existing implemented exception classes. Engineering review maps them to concrete code.

| Method/codepath | Trigger / exception category | Rescue planned? | Rescue action | Learner/operator sees |
|---|---|---|---|---|
| Model input validation | MissingInputError, InvalidNumberError, OutOfRangeError; NaN/infinity/string | Yes | Reject; preserve last valid state and mark invalid control | Specific input explanation; never contradictory numbers |
| State construction | EmptySceneError, MissingLabelError, NonFiniteStateError | Yes, fail build | Stop artifact promotion with scene/field context | Incomplete build status |
| Static/vector render | FontUnavailableError, LayoutOverflowError, RenderProcessError | Yes | Use approved local font fallback only if inspected; stop otherwise | Named render failure and last accepted artifact |
| Browser module load | AssetLoadError, SyntaxError | Yes, fallback surface | Static companion remains available; visibly report unavailable interaction | Explanation readable; interaction not falsely claimed |
| Media synthesis | VoiceUnavailableError, SynthesisExitError, EmptyAudioError | Yes | One supported retry/alternate local route within two-attempt rule | No video-success claim until real narration exists |
| Media encoding | EncoderExitError, MissingFrameError, InvalidMediaError | Yes | Stop output promotion; retain source and log stderr | Named build failure; no broken video link as success |
| Media playback | NotSupportedError, network/media decode error | Yes | Visible retry/static/transcript choices; distinguish unavailable medium | Readable explanation; explicit video failure |
| Timeline seek | InvalidSeekError, unavailable duration metadata | Yes | Wait for metadata, clamp to duration, ignore stale event | Valid chapter selection or clear loading state |
| Q&A/card content | MissingAnswerError, InvalidQuestionReference | Yes, fail build | Reject incomplete content before delivery | No empty or fabricated answer |
| Artifact write/manifest | PermissionError, FileNotFoundError, HashMismatchError | Yes, fail build | Write in staging; promote only complete verified set | Prior complete candidate remains usable |

No live LLM call is needed. Malformed model JSON, refusal, hallucinated fields and empty service responses are avoided through authored finite content, not hidden catch-all recovery. If an implementation introduces such a call, it must explicitly extend this registry during engineering design and remain within the frozen scope.

```text
failure -> category + input/scene context -> retry allowed and budget remains?
                                               | yes -> bounded supported retry -> validate
                                               | no  -> visible boundary + retained sources
                                                          |
                                                  never mark delivered
```

## Section 3: security and threat model

| Finding | Likelihood / impact | Mitigation |
|---|---|---|
| S1: HTML/Markdown/Q&A text interpreted as executable markup | Medium / medium | Author finite trusted content; escape any dynamic text; no remote free-text service or eval |
| S2: render commands receive shell-interpolated labels or arbitrary output paths | Low / high | Fixed argument arrays/trusted project roots; no shell construction from lesson text; protected-path checks |
| S3: third-party CDN, remote font, speech service or tracking silently added | Medium / medium | Local assets and local narration; no mandatory network/credentials; inventory dependencies and licenses |
| S4: optional practice starts learner tracking without consent | Medium / high | Ephemeral UI state only; no profile, analytics, localStorage progress, mastery inference or `.prax-teach` writes |
| S5: baseline/evaluator overwritten while improving candidate | Low / high | Frozen protected paths, integrity comparison and candidate-only writes; no active install |

No auth/role model, multi-user identifiers, database or payment data is introduced. Explicitly validate slider ranges, query parameters if present, caption/text lengths and external URL schemes. Local media build logs contain paths and scene IDs but no learner transcript or credentials. This review does not claim a penetration test.

## Section 4: data flow and interaction edge cases

```text
finite values -> model -> signed terms -> sum/bias -> activation -> output
                   |          |            |            |
                   +----------+------------+------------+--> live labels/prose/stills

authored script -> narration segments -> actual audio durations -> timeline -> encoded video
       | empty/missing      | failed synthesis           | invalid seek    | decode error
       +-> stop            +-> stop/retry                +-> clamp/wait    +-> visible failure

user control -> validated current state -> compare with retained baseline
video time --------------------------------> filmed state
pause + explore -> explicit EXPLORE mode -> changed state
return to film ----------------------------> timeline state at current video time
```

| Interaction | Edge case | Planned handling / required observation |
|---|---|---|
| Parameter change | Endpoint, zero, negative sign, rapid drag, keyboard change | Full chain recomputes; sign and contribution words update; no stale explanation |
| Baseline compare | Repeated pin/reset; baseline equals current | Stable snapshot; clear same-state indication; reset restores all displayed terms |
| Activation choice if offered | Switching while value is off graph | Curve/domain/units/labels update together; preserve correct input state |
| Video play | Autoplay denied, delayed metadata, missing asset | User play control; loading/error text; readable transcript |
| Seek/chapter | Rapid seeks, ended video, seek while exploring | Last requested valid time wins; film/explore modes remain legible |
| Video-to-explorer | Slider change while playing | Pause first; explicit explore mode; no racing clock overwriting user's experiment |
| Navigation/resize | Mid-video resize, back navigation, orientation | Preserve valid state; reflow full mechanism; do not restart audio unexpectedly |
| Optional cards | Double reveal, next/back, final card, keyboard | Deterministic index; no accidental score or persistence; all controls named |
| No script/reduced motion | Script unavailable or motion preference enabled | Full static explanation and worked examples; no required animation for understanding |

```text
STATIC/READY -> PLAYING <-> PAUSED -> ENDED
                  |          |        |
                  +-- explore/change -+--> EXPLORE
                                             |
                                         return to film -> PAUSED (same valid time)
LOADING -> READY or ERROR; ERROR -> explicit retry or static/transcript
Forbidden: PLAYING and EXPLORE controlling one scene simultaneously.
```

Empty/nil/invalid content stops the relevant build; network/decode errors visibly degrade delivery. None of these behaviors is claimed tested in this CEO phase.

## Section 5: code quality review

**WARNING Q1:** a copied formula in SVG scripts, browser logic and video scenes would create drift. Keep the model pure and small; use independent expected results in tests rather than duplicate production arithmetic everywhere.

**WARNING Q2:** hardcoded positional diagrams become unreadable on phones. Use two intentional layouts driven by the same semantic state, not a 620px minimum-width diagram in a scroll wrapper.

**WARNING Q3:** a large schema, generic plugin system, content CMS, animated framework or rendering service is not justified by one mechanism. Organize around model, content/timeline, compositions, and delivery adapters. Avoid inheritance and classes unless they reduce actual complexity.

**WARNING Q4:** brittle screenshot counts, phrase assertions and generic success banners can recreate the original false confidence. Verification should assert meaningful values/effects and record limits. Do not write tests that merely mirror implementation strings.

Candidate guidance must distinguish policy, production method and worked examples. Keep the root loader small. Add portable reference material in the candidate, with explicit tool-discovery and fallback rules, without copying the entire existing teacher into a parallel system.

## Section 6: test review

```text
NEW UX             explorer, compare/reset, video chapters, explore/return, Q&A/cards
   -> browser E2E: real changes, exact displayed outputs, keyboard order, 390px + desktop
NEW DATA           model -> all media; narration -> timed captions -> video
   -> unit expected values + artifact integration + timeline/caption validation
NEW CODEPATHS      positive/negative/zero/boundary input, activation choice, film/explore
   -> unit boundaries + browser transitions; failure inputs rejected explicitly
NEW ASYNC WORK     synthesis, frame generation, encode, media metadata/seek
   -> build integration + induced missing asset/failed command; atomic staging check
NEW INTEGRATIONS   installed voice/render/encode tools; browser media playback
   -> tool version/provenance + actual output decode + real playback/listening
NEW RESCUES        categories in Section 2
   -> targeted failure injection and visible fallback; no silent pass
```

Required test specifications for engineering review:

1. Independently calculate signed contributions, sum and activation for baseline, one meaningful contrast, zero and boundaries; compare all displayed quantities and formal explanation.
2. Move a real slider through a cause/effect contrast; observe contribution, sum marker, activation marker, output and explanation together. Endpoints alone are insufficient.
3. At narrow width, the complete input→sum→activation→output chain remains readable in an overview without required horizontal panning.
4. Pin baseline, change one parameter and reset; verify baseline/current provenance and no stale text.
5. Play, seek, pause, explore, return and reach end on actual encoded video; timeline and visible state must agree.
6. Decode media, inspect representative keyframes and boundaries, check caption intervals against actual duration, and listen to the actual narration. File existence and ffprobe metadata alone do not establish intelligibility or sync.
7. Traverse complete controls with keyboard; inspect focus/name/order and reduced-motion static equivalence. Do not claim a screen-reader or full WCAG result without that specific review.
8. Load no-script/static companion; it contains all causal steps and worked result. Test missing video to show a useful visible failure.
9. Confirm explanation before optional practice, no learner-state writes and no answer-protection claim for revealable self-study material.
10. Compare original baseline, current accepted version and candidate using the unchanged frozen contract and protected regression checks; receipts outside the attested content hash.

Friday-night confidence test: opening the delivered entry on a narrow viewport, watching the real film with sound, seeking to the weighted sum, entering explore mode, changing one cause and verifying the same exact result in the static explanation.

Hostile QA: negative/zero values, rapid seeks while changing a slider, missing media/font, disabled script, 200% zoom and a stale baseline. Chaos: terminate synthesis/encode mid-write; no partial candidate can be marked complete.

Use many deterministic model checks, fewer artifact/integration checks, and a small number of meaningful full-journey browser checks. Random inputs require a recorded seed. Timing tests must inspect media timestamps rather than sleeps; UI waits should use states. Visual critique and listening remain qualitative evidence, not numeric learning scores. Existing accepted prompt/policy/evaluator suites remain unchanged; engineering review identifies the precise runnable suites before execution.

## Section 7: performance review

**WARNING P1:** full-resolution video frames and repeated synthesis dominate time and disk. Cache validated narration/frames by source hash, bound resolution/duration/frame rate in the frozen build spec, and regenerate changed segments only when safe. Record measured time/file size; do not invent p99 numbers.

**WARNING P2:** a browser explorer must not encode video or rebuild a full scene graph on every drag. Pure neuron arithmetic is trivial; update the existing SVG/DOM on animation frames as needed. Avoid a perpetual loop when paused and honor reduced motion.

**WARNING P3:** importing large fonts/frameworks for one local page harms portability. Prefer local assets and small modules. Inspect font fallback and initial rendering. Video should be user-started and preload metadata rather than download multiple encodes unnecessarily.

No database queries, N+1 associations, connection pools or background server workers are introduced. Maximum content is one bounded example, finite cards and a short film; 100× curriculum size is intentionally outside this implementation. Top slow paths are narration synthesis, scene/frame rendering and encoding; engineering review sets concrete bounds based on installed tools rather than claiming unknown latencies.

## Section 8: observability and debuggability review

**WARNING O1:** successful shell exits do not establish good media. Build receipts need source hashes, tool versions, exact commands/arguments, stage duration, expected output paths, actual duration and failure context.

**WARNING O2:** reviewers need a simple local evidence index linking stills, browser screenshots, video, transcript, cue data, listening notes, tests and known limits. This is a report artifact, not a monitoring platform.

**WARNING O3:** log actual inspected states and defects. Distinguish automated assertion, browser observation, frame inspection, listening and inference. No metrics dashboard, telemetry collector or external alerting service is warranted. A failed stage should stop the local build visibly; the runbook is rerun that named stage from editable source under the existing attempt budget.

Three weeks later, a reviewer should be able to identify which source/voice/parameters produced a frame, compare that state with the model and rebuild it. No learner activity needs to be logged.

## Section 9: deployment and rollout review

**WARNING D1:** installation is outside this task. Success means a complete isolated candidate and reviewable artifact set, not changing the active skill or publishing a site.

**WARNING D2:** partial output must not become the entry page's advertised final media. Build into a staging output, validate required files, then promote the complete candidate directory or manifest. Keep sources and receipts separate.

```text
freeze baseline/contract -> author candidate -> stage outputs -> validate math/media
        -> inspect browser/frames/audio -> compare baseline and accepted -> reviewable candidate
                                                       |
                                               defects within budget -> repair
                                               otherwise -> honest limitation
```

```text
bad candidate? -> stop promotion -> retain evidence -> select last acceptable candidate
                        |                                  |
                        +---------- accepted install remains untouched
```

There are no schema migrations, rolling servers or deploy-time mixed versions. Local asset path consistency is the analogous risk. Smoke-check the exact delivered entry and all its media links after promotion, not just a development server path. A later active install requires separate authorization and checks.

## Section 10: long-term trajectory review

Reversibility: **5/5**, provided all changes remain isolated and no active installation or evaluator is touched.

Debt to avoid: a neuron-only template described as universal guidance; hardcoded device pixels; duplicated arithmetic; voice/tool commands presented as cross-harness requirements; media claims based on historical receipts; an enormous root skill. Candidate guidance should state explanatory jobs and required outputs, provide executable examples as examples, and let each harness discover authorized tools.

The next useful phase is a second contrasting subject using the same portable guidance, only after this example earns review. It is deferred; no automatic phase expansion. A six- or twelve-month maintainer should see the source of truth, editable assets, provenance, capability boundaries and rebuild instructions without a new platform's architecture manual.

## Section 11: design and UX review

The art direction must answer the subject, rather than apply a palette to generic cards. Present a coherent neuron scene with stable named objects and signed contribution encodings, an adjacent activation graph, and a strong visual hierarchy. Labels/equations use real vector/text rendering. A restrained color system reinforces roles while words and signs carry meaning. The accepted paper/ink/blue default is not an artistic quality certificate. The current isolated product spec selects a scientific-atlas direction: midnight navy, lavender positive contributions, coral opposing contributions and mint output; follow that direction while retaining signs, words and accessible contrast. Respect explicit current user style direction and accessibility.

First: finished whole mechanism and clear explanatory claim. Second: one integrated control with retained comparison. Third: optional deeper parameters and media/practice. Avoid duplicated lesson prose, unnecessary banners, equal-weight cards, blank stage padding and decorative arrows. Use spacing, scale, alignment, typography and composition that have an explanatory purpose.

```text
entry: finished explanation + still overview
            |
            +-> inspect causal explorer -> compare/reset -> exact formal bridge
            +-> play narrated film -> chapter seek -> pause/explore -> return to film
            +-> optional Q&A / flashcards -> reveal explanation -> return to mechanism
            +-> transcript/static/print (always available)
```

| Feature | Loading | Empty | Error | Success | Partial |
|---|---|---|---|---|---|
| Explorer | Static overview visible | Build rejects missing scene | Named failure + static path | Full mechanism + live exact state | No-script explanation remains complete |
| Video | Poster/transcript + native progress | No empty-success placeholder | Visible playback failure | Real audible film + captions | Transcript/stills available; disclose absent video |
| Video explorer | Wait for media metadata | Invalid timeline rejected | Clear sync boundary | Actual media time linked to scene | Explicit paused explore state |
| Q&A/cards | Finite content available | Invalid empty deck rejected | Useful authored-content message | Optional reveal/navigation | Explanation unaffected |

Responsive intention includes a portrait composition, not scaled-down desktop text. At 200% zoom and narrow width, labels and controls stay readable and the entire relationship remains apparent. Keyboard focus must be visible; controls need names, output descriptions, touch targets and logical reading order. Reduced motion must retain every causal state; audio must not be the only explanation.

Rendered craft review should compare baseline and candidate side by side at matching viewport sizes. Critique hierarchy, semantic clarity, density, mathematical label consistency and responsive composition separately. Quality preferences are qualitative evidence; they are not proof of learning gains. A live rendered design review belongs after implementation, alongside actual listening and playback inspection.

## Failure modes registry

All tests below are planned. `Planned` never means already rescued, tested or observed.

| Codepath | Failure mode | Rescue | Test | User sees | Logged |
|---|---|---|---|---|---|
| Input/model | NaN, invalid range, missing field | Reject/preserve valid state | Planned unit + UI | Specific input issue | Context planned |
| Cross-media data | Still/video/UI disagree | Fail validation/promotion | Planned independent expected values | No final inconsistent candidate | State/source hash planned |
| Narrow layout | Mechanism clipped off-screen | Portrait recomposition | Planned rendered/browser review | Complete overview | Screenshot/viewport planned |
| Controls | Stale prose or baseline | Derive from same state | Planned browser contrast/reset | Current and baseline identified | Inspected states planned |
| Synthesis | Missing/empty/bad narration | Bounded route repair; stop | Planned audio decode/listening | Honest missing-media status | Tool/voice/stderr planned |
| Encoding | Corrupt/truncated movie | No promotion | Planned decode/keyframes | No broken final-media claim | Encode receipt planned |
| Timeline | Seek/slider clock race | Explicit film/explore modes | Planned rapid transition test | Stable current mode/time | Transition evidence planned |
| Playback | Unsupported/missing asset | Visible failure + transcript | Planned induced missing file | Explanation and failure label | Browser evidence planned |
| Practice | Missing answer or accidental scoring | Validate finite content; no tracking | Planned content/flow review | Optional self-study | Content check planned |
| Delivery | Partial file set or wrong relative paths | Atomic promotion + link check | Planned exact-entry smoke | Complete candidate or explicit boundary | Manifest planned |
| Scope | Baseline/evaluator changed to pass | Protected integrity checks | Planned before/after comparison | Accurate candidate status | External receipts planned |

No critical gap is silently accepted by this plan. Each listed mitigation still requires implementation evidence. An implemented `rescued=no, tested=no, silent=yes` path blocks a completion claim.

## NOT in scope and follow-up ledger

No separate `TODOS.md` is written because this phase owns only this plan. These are explicit deferred/cut proposals for the orchestrator to retain; none is silently scheduled.

| Item | Decision / why | Value / cost | Effort / priority / dependency |
|---|---|---|---|
| Repair all ten chapters and network capstone | Defer; this task proves one vertical example | Fixes real recorded debt; multiplies content production and review | L human / M agent; P2 follow-up; needs accepted direction |
| Second contrasting subject | Defer; needed to test portability, not this scene | Tests generality; requires a new subject brief and evidence | M human / S–M agent; P2; first example review |
| Universal scene/runtime/course platform | Cut for this task | Possible scale reuse; broad architecture and maintenance before proof | XL; P3 reconsider only with repeated real demand |
| Paid TTS/video, new accounts, remote publication | Exclude | Could improve reach/voice; billing/auth/distribution outside authorization | Separate approval and evidence |
| Active skill install or accepted-evaluator revision | Exclude | Future rollout possible; changes protected system and governance | Separate explicit approval/version |
| Full learner outcome study or mastery certification | Defer | Can establish learning effects; substantial study design and consent | L/XL; P3; quality and safety established first |
| Analytics, login, persistent flashcard scheduling | Cut | Not required for explanation; expands privacy and service scope | No implementation in this run |

## Stale diagram audit

This phase changes only this newly authored plan. Its diagrams describe proposed architecture, flows, states, errors, deployment, rollback and learner journey. Accepted-package diagrams were not rewritten or certified current. During implementation, update these diagrams if the actual bounded architecture differs; do not silently treat the plan as implementation evidence.

## Implementation Tasks

All tasks are unimplemented handoffs, synthesized from the findings above. The engineering review should refine concrete filenames and commands after choosing the feasible production route. Relative paths are under `production-v2/`, except read-only baseline comparison.

- [ ] **T1 (P1, human ~1h / agent ~15–30min)** — production contract — freeze baseline/current accepted comparison, exact task inputs, protected/mutable paths, frozen criteria, budgets and stop/rollback rule before candidate edits. Surfaced by D7, S5 and I13. Files: orchestrator-owned contract/receipts. Verify: immutable input hashes and no protected-path changes.
- [ ] **T2 (P1, human ~2–4h / agent ~30–60min)** — model/content — author exact neuron model, signed contributions, worked contrast, labels, formal bridge and static explanation. Surfaced by I3/I4/A1. Files: example source/model/content. Verify: independent expected calculations at baseline/contrast/boundaries.
- [ ] **T3 (P1, human ~4–6h / agent ~1–2h)** — stills/explorer — compose polished vector stills and responsive cause/effect explorer with baseline/reset/activation graph. Surfaced by I1/I3/I5/Q2. Files: example SVG/HTML/CSS/JS. Verify: real control effects, desktop/phone/zoom screenshots and whole-chain visibility.
- [ ] **T4 (P1, human ~1–2 days / agent ~2–4h plus render/review)** — narrated media — produce short real narrated film, transcript/captions, editable scene/timeline and synchronized video explorer. Surfaced by I12/D4/O1. Files: narration/timeline/render sources and media outputs. Verify: actual audio listening, decode, keyframes, cue alignment, playback/seek/explore/return.
- [ ] **T5 (P2, human ~2h / agent ~20–40min)** — practice — author finite optional Q&A and flashcards with clear reveal/navigation and no tracking/mastery claims. Surfaced by D6/I9/S4. Files: example content/UI. Verify: explanation first, keyboard complete flow, accurate worked answers and no learner-state writes.
- [ ] **T6 (P1, human ~3–5h / agent ~45–90min)** — candidate guidance — extract portable art direction, comparison, responsive, narration/video/export and verification recipes into isolated candidate references. Surfaced by I10/I11/I14/Q3. Files: candidate skill references only. Verify: policy/method/example separation, canonical routing preserved, no accepted/evaluator mutation.
- [ ] **T7 (P1, human ~4–6h / agent ~1–2h plus review)** — evidence and delivery — run suitable math/policy/artifact/control checks, inspect real renders and audio/video, compare baseline/current accepted/candidate, document limitations and link a complete artifact set. Surfaced by I7/I8/I13/O2/D2. Files: receipts/report/index outside content hash. Verify: actual exact entry and media, complete evidence index, protected-path integrity, bounded repair loop.

Task JSONL handoff is embedded because only this file may be written by this reviewer. The orchestrator may materialize it using its normal serializer; this block is data, not a claim that the skill's sidecar writer ran.

```jsonl
{"id":"T1","phase":"ceo-review","priority":"P1","component":"production contract","title":"Freeze inputs, criteria, boundaries, budget and rollback","source_finding":"D7 S5 I13","files":["contract and external receipts (orchestrator owned)"]}
{"id":"T2","phase":"ceo-review","priority":"P1","component":"model/content","title":"Author exact shared neuron example and worked contrast","source_finding":"I3 I4 A1","files":["example model and content"]}
{"id":"T3","phase":"ceo-review","priority":"P1","component":"stills/explorer","title":"Compose polished responsive stills and causal explorer","source_finding":"I1 I3 I5 Q2","files":["example vector and browser sources"]}
{"id":"T4","phase":"ceo-review","priority":"P1","component":"narrated media","title":"Produce narrated film and synchronized video explorer","source_finding":"I12 D4 O1","files":["narration timeline rendering sources and media"]}
{"id":"T5","phase":"ceo-review","priority":"P2","component":"practice","title":"Author optional grounded Q&A and flashcards","source_finding":"D6 I9 S4","files":["example practice content and UI"]}
{"id":"T6","phase":"ceo-review","priority":"P1","component":"candidate guidance","title":"Extract portable production recipes without policy changes","source_finding":"I10 I11 I14 Q3","files":["isolated candidate references"]}
{"id":"T7","phase":"ceo-review","priority":"P1","component":"evidence/delivery","title":"Inspect actual outputs and deliver complete evidence index","source_finding":"I7 I8 I13 O2 D2","files":["external receipts report and artifact index"]}
```

## Review concerns and completion summary

Handoff update: read `spec/03-product-spec.md` after writing this review. Its exact ReLU/loss/simultaneous-update model, scientific-atlas direction, offline bundle, changing video geometry and stop rules are consistent with the bounded recommendation and are the concrete input for engineering review. The orchestrator reports HyperFrames 0.8.169 local Kokoro TTS, FFmpeg 9 and Manim 0.22 as available; this reviewer has not independently exercised them. Engineering should select the best feasible exact-model route, preserve offline classic-JS delivery where required, and verify actual outputs rather than tool availability.

Outside-voice review has not run inside this bounded CEO assignment. The orchestrator should provide an independent pass when synthesizing this handoff with engineering review and the research matrix. No cross-model agreement or adversarial quality score is claimed. A new nested agent or Codex process is not started by this reviewer because the assignment limits ownership and the parent is already coordinating independent phases. This is a disclosed review limitation, not an unresolved product scope choice.

| Review area | Result |
|---|---|
| Mode / Step 0 | HOLD_SCOPE; B selected; seven explicit decisions |
| System audit | Non-git audit directory; canonical entries and prior audit inspected |
| 1 Architecture | 2 coupling/runtime findings; bounded shared-model approach |
| 2 Error/rescue | 10 codepaths/categories mapped; concrete implementation pending |
| 3 Security | 5 threats mapped; no new auth, paid service or learner tracking |
| 4 Data/UX | 9 interaction groups; film/explore state machine specified |
| 5 Quality | 4 findings; no new framework |
| 6 Tests | 6-category test diagram and 10 meaningful specifications |
| 7 Performance | 3 findings; no fabricated measurements |
| 8 Observability | 3 findings; receipts and evidence index, no telemetry platform |
| 9 Deployment | 2 risks; isolated candidate, atomic promotion, accepted install untouched |
| 10 Future | Reversibility 5/5; portability remains unproven |
| 11 Design | Responsive causal composition and all delivery states specified |
| Audit inventory | 14 documented issues/shortcuts preserved |
| Failure modes | 11 mapped; mitigations planned, none claimed implemented/tested |
| Deferred/excluded | 7 explicit follow-up/scope decisions |
| Tasks | 7 implementation tasks; JSONL embedded, no sidecar/global logs written |
| Outside voice | Not run in this assignment; parent synthesis requested |
| Lake score | Complete vertical option selected; no proxy certification |
| Unresolved product decisions | 0; concrete tool/file choices belong to engineering review |

STATUS: DONE_WITH_CONCERNS. The CEO scope review is complete and the plan is reviewable. Concerns are unexecuted production verification, pending engineering/research synthesis, and no independent outside-voice pass within this assignment. Next authorized phase is `/plan-eng-review`, then the frozen build spec, implementation and code/visual/audio review loop. Nothing in this report authorizes active installation, evaluator changes or claims of learning superiority.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|---|---|---|---|---|---|
| CEO Review | `/plan-ceo-review` | Scope and strategy | 1 | REVIEWED_WITH_CONCERNS | HOLD_SCOPE; 14 audit issues inventoried; complete vertical example selected; 7 build tasks |
| Outside Voice | Independent plan challenge | Find missed assumptions | 0 in this assignment | NOT RUN | Parent synthesis requested; no independent score claimed |
| Eng Review | `/plan-eng-review` | Architecture and tests | 0 in this assignment | REQUIRED NEXT | Feasible media route, concrete build spec and test commands pending |
| Design/Audio Review | Rendered and audible artifact review | Actual delivered craft | 0 | POST-IMPLEMENTATION | Browser, still, video and listening evidence required |
| Code Review | Code-quality loop | Implementation integrity | 0 | POST-IMPLEMENTATION | No implementation reviewed here |

**VERDICT:** CEO scope reviewed; engineering review required. This is not a shipping clearance or a claim of completed production.

NO UNRESOLVED DECISIONS
