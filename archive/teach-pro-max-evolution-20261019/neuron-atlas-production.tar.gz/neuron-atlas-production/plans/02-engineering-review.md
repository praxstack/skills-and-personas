# Engineering review: exact neuron production slice

Date: 2026-10-18. Status: DONE_WITH_CONCERNS. Mode: FULL_REVIEW within CEO HOLD_SCOPE.

Reviewed `01-ceo-review.md` and the draft `spec/03-product-spec.md`. Read the plan-eng-review skill and its review-sections reference. The user has authorized autonomous decisions; the spawned-session rule applies. Recommendations below are selected within that authorization. This is a plan review, not evidence of implementation. Only this plan and pre-freeze engineering clarifications in the draft spec are changed. Global configuration, telemetry, routing, active skills, baseline, evaluator and identity policy are untouched. Global review logs, task sidecars and memory writes are not performed under this bounded file ownership; the parent may materialize the embedded task/test handoff.

## Step 0: scope challenge

Accept the complete vertical slice: one mathematically exact neuron across still, explorer, optional Q&A/cards, narrated film and interactive video, with portable candidate instructions. Do not replace requested media with placeholders. Do not build a course/runtime platform. The source count budget is eight meaningful modules and zero services; generated assets and evidence are outputs. If additional source modules become necessary, first consolidate responsibilities and document why. All later work is candidate-only; freeze this spec and the original/accepted baseline before implementation.

What already exists:

- Accepted teaching/rendering contracts and the prior rejected artifacts are comparison inputs, not targets for edits.
- The new draft specifies exact values and a coherent media scope; the CEO review selects one complete example.
- The primary-source research matrix supplies 20 approaches. Local Manim 0.22, HyperFrames 0.8.169/Kokoro, FFmpeg and Chrome are parent-reported availability leads, not demonstrated production results in this review.
- Native HTML provides controls, video, text tracks, details, buttons, range inputs and responsive SVG. Reuse them instead of introducing a UI/video framework.
- No project test framework or local TODO file is identified in the new production directory. Use Node's built-in test/assert for pure logic and the existing browser automation installation for real behavior; do not install a test platform.

The CEO scoped inventory reports a non-Git audit directory. There is no branch-history regression claim here. Prior passing tests failed to establish craft; the new plan therefore inspects actual outputs, not only schemas and file presence.

## 1. Architecture

**1A [P1] (confidence 9/10): keep one numerical authority.** Spec line 17 says, “All numerical visual views derive from one browser/Node executable model and one shared preset fixture.” Any Python renderer must consume JSON snapshots exported by this JS model, never reimplement its math. Freeze baseline/current independently. Prefer a simple classic-script/CommonJS-compatible pure model. A build step can inline it into the host; shipped runtime must require no imports or server. This is [Layer 1], minimal dependency and DRY.

**2A [P1] (confidence 9/10): make offline delivery an actual supported entry.** Spec line 30 requires “generated artifacts work offline after extraction. Runtime needs no package install.” Browser modules loaded under file:// encounter security restrictions; external caption tracks can also need HTTP. Choose classic scripts, inline authored cues and programmatic native TextTrack/VTTCue, plus a separate downloadable VTT. Keep all media relative. Test file:// and HTTP from a renamed extracted folder with network disabled. A localhost-only demo would leave the portability requirement unproven. Primary sources: [MDN modules](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules), [native track](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/track), [media and local hosting](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/HTML_video_and_audio).

**3A [P1] (confidence 9/10): separate film state from live state.** Spec line 27 says, “Exploring must not silently alter prerecorded video facts.” Keep the actual media clock authoritative. The synchronized companion reads the recorded timeline; the free explorer owns a different state. A native play event in exploration returns to film deterministically, so using native controls cannot create contradictory narration. Never attach an unrelated animation clock or synthesize narration on playback.

```text
pure model + immutable presets ----> snapshot export ----> still SVG -> PNG
          |                                  |
authored text/timeline -----------------------+----> film renderer + local audio -> MP4
          |                                  |
          +----> static HTML + classic JS <---+----> native captions + transcript
                            |
                  isolated live explorer

FILM paused/playing -- Explore --> pause + save time --> EXPLORE
EXPLORE -- Return/native Play --> restore recorded scene + time --> FILM
FILM -- seek/replay/timeupdate --> derive scene from currentTime
ANY -- media failure --> visible message + static explanation/transcript
```

Use at most these source responsibilities: `model.js`, `content.js` (presets/text/cues), `index.html` + browser behavior as one host module, `style.css`, `build-still`, `render-film`, `build-media`, and `checks`. Filenames may differ; responsibilities must remain explicit. Static artifact outputs: SVG/PNG, MP4, VTT/transcript, keyframes and evidence. No database, worker queue, API auth or remote runtime. External source links do not execute code. Distribution is a local complete folder/ZIP with README and provenance; publication is excluded.

## 2. Code quality and mathematical edge cases

**4A [P1] (confidence 9/10): snapshot before simultaneous update.** Spec line 15 explicitly requires “simultaneous gradient descent rate η=0.5”. Calculate every derivative from the same old parameters, then construct a new parameter object. Never update w1 before calculating w2/b. Full precision feeds math; format only at the presentation edge. Baseline: contributions 1.2 and −0.4, z=a=0.6, L=0.08. Gradients −0.32/−0.16/−0.4. Updated parameters 1.66/−0.92/0, z=a=0.96, L=0.0008, within floating-point tolerance.

**5A [P1] (confidence 9/10): define finite domains and nonsmooth behavior.** Spec line 15 sets derivative 0 for z≤0. Validate finite numeric inputs, bounds and η≥0. Include positive/negative weights, zero inputs/contributions, cancellation, inactive z<0, exact z=0, active z>0, y=a and η=0. Finite differences only validate differentiable states away from zero; at the kink assert the declared convention. Explain inactive gradient descent staying stuck without claiming all learning always reduces loss. Negative display zero is normalized only for typography. Axis range must include every shown value or explicitly mark clipping; no sign encoded by color alone.

**6A [P2] (confidence 8/10): keep authored content and error recovery explicit.** Finite authored Q&A/cards use native details/buttons; no generated-answer service, localStorage or “mastered” state. Render user-controlled numbers through textContent/DOM, not interpolated HTML. Reset returns the live model to immutable baseline and updates geometry, prose and values together. Media metadata-not-ready defers/clamps requested seek; rejected play promises and missing files produce readable recoverable status. Put the state-machine diagram beside the host controller; put the snapshot-export flow beside the build orchestrator. No general schema engine or custom player controls.

## 3. Tests and observable review

All entries below are PLANNED, currently untested. Coverage percentages would be fabricated before implementation. Every critical path requires behavior assertions, not only existence checks. The independent evaluator uses literal expected numbers/finite differences and frozen acceptance criteria; it does not copy candidate functions as its oracle.

```text
CODE PATHS / CHECK TARGET                         USER FLOWS / ACTUAL OBSERVATION
model: valid -> forward -> loss -> gradients      open -> full chain visible [E2E]
       invalid/nonfinite -> explicit rejection    control -> contributions/sum/ReLU update [E2E]
       active | inactive | kink                  baseline comparison -> reset [E2E]
       update snapshot | eta=0                   Q&A/cards reveal + keyboard navigation [E2E]
export: model snapshots -> SVG/video fixtures     still inspect -> signs/axes/readable labels
host: input -> validate -> render                390px + desktop + 200% zoom/reflow [E2E]
      film clock -> cue lookup                   seek + transcript + replay + ended [E2E]
      explore -> pause/save -> return            native Play during exploration [E2E]
      metadata/play/media errors -> fallback     missing film -> visible error/static text [E2E]
build: synthesize -> align -> render -> encode    actual audio listening + representative frames
       fail -> explicit stop/no final promotion  extracted file:// offline open [E2E]
package: relative assets -> manifest -> extract   no-script explanation + native video/transcript
```

Test plan handoff (affected entry: delivered `index.html`, its still and media links):

- `checks/model.test.js`: assert literal baseline, inactive and updated values; simultaneous step and unchanged baseline; finite differences away from kink; declared kink derivative; invalid/non-finite inputs; η=0 and y=a. Comparison tolerance 1e-10 for deterministic baseline arithmetic; finite-difference tolerance chosen before run (suggest h=1e-5, absolute 1e-5).
- `checks/browser`: assert actual displayed values and SVG attributes change for an altered positive weight and inactive bias; reset restores every output; fixed baseline remains unchanged. Test rapid slider input, seeking across cue boundaries, backward seek, paused seek, replay/end, Explore/Return and native play. Check film scene never consumes live state. Check a denied play and broken media URL expose recovery; do not claim raw metadata tests cover these flows.
- Caption tests: cue start/end monotonic and inside measured media duration; current concept at before/at/after each boundary; final cue/ended state defined; real native text track present and synchronized under file://. Transcript selection seeks to the intended chapter without starting unsolicited audio.
- Responsive/accessibility review: desktop and 390px screenshots, 200% zoom/reflow, tab order, visible focus, meaningful labels, contrast, reduced-motion treatment, non-color signs and text equivalent for diagram. No-script retains the explanatory chain and transcript. Screen-reader compatibility cannot be certified from labels alone; record any unperformed AT inspection.
- Media/build checks: nonempty decodable MP4 with audio stream, measured duration/resolution/frame rate; full FFmpeg decode; first/middle/update/inactive/final keyframes; SVG text/vector structure, PNG dimensions and inspection. Listen to the real audio or explicitly leave listening review incomplete. Confirm narration refers to displayed facts at corresponding times. Audio stream existence/ASR is not listening evidence.
- Portability: extract ZIP to another path, disable network, launch exact entry via file://, exercise live controls, chapters, caption selection and media. Repeat HTTP smoke. Check runtime source for author-machine absolute paths, remote scripts/fonts, fetch/import and storage writes. Manifest checks cannot substitute for launch.
- Integrity/acceptance: independently compare rejected baseline and current accepted reference with candidate; verify protected hashes before/after. Keep receipts outside content hashes. Freeze these gates before candidate implementation; defects lead to candidate repairs, never evaluator relaxation.

No LLM service is introduced. Candidate guidance remains a prompt/instruction change, so run the already-existing accepted package/contract checks unchanged plus the task's held-out production review; do not invent a new evaluator or claim this example establishes subject generality.

## 4. Performance

**7A [P2] (confidence 8/10): bounded static work instead of runtime generation.** Fixed two-input math is O(1). Update only linked DOM/SVG values; avoid rebuilding the entire host on every range event or polling the video at a high rate. Use timeupdate/seeking/seeked/loadedmetadata events with one cue lookup; optional frame callbacks need a simple fallback. Cap charts to a fixed sample count, cache immutable curve primitives, and honor reduced motion. No N+1/database/cache service exists to optimize.

**8A [P2] (confidence 8/10): make media cost visible.** Render one local job at a time; a 24GB machine does not justify parallel high-resolution renders plus browser captures. Target 1920×1080, 30fps for the short MP4 and a high-resolution PNG, retaining editable vectors. Use H.264/AAC, yuv420p, faststart and preload=metadata. Do not embed base64 MP4 into HTML. Record actual size/render duration/encode settings, then verify decode and play. Broken audio or encoding fails the build visibly; no silent fallback to a mute slideshow.

## Failure modes and recovery

| Path | Failure | Required recovery/test | Visible outcome |
|---|---|---|---|
| Numerical input | NaN or out-of-domain value | Validate + unit/browser rejection | Last valid state and clear input status |
| Gradient step | Sequential mutation or rounding | Literal/finite-difference/snapshot assertions | Correct current state and retained baseline |
| Geometry | Signed term or graph clipped | Boundary model tests + actual screenshot inspection | Sign, scale and causal relation readable |
| Media build | Local voice/render/encode fails | Nonzero stop; retain logs; no promotion | Incomplete status, never fake MP4 evidence |
| Playback | Asset missing/play denied | Error/rejected-promise browser test | Native controls and static explanation survive |
| Timeline | Seek before metadata or boundary race | Pending seek + exact-boundary E2E | Scene follows actual media time |
| Explore | Slider mutates film/replay resumes wrong facts | State isolation/native-play E2E | Explicit mode and deterministic return |
| Caption delivery | file:// blocks external VTT | Inline native cues + extracted offline test | Working captions and independent transcript |
| Packaging | Missing/absolute asset path | Extract/relocate/offline launch | Portable complete bundle or explicit failure |

No uncovered silent failure is accepted. These are required mitigations, not completed test claims; any implementation path with no test, no handling and silent failure is a critical gap.

## NOT in scope

Full-course/capstone repair and a second subject are deferred because this task proves one mechanism. Universal scene schemas, custom video players, learner accounts/storage, telemetry, new service infrastructure, publishing and paid tools are excluded. Active installation, accepted-evaluator changes and learning-outcome claims require separate authorization/evidence. No new TODO file is created: the CEO follow-up ledger already retains those deferred items, and none blocks this slice.

## Implementation Tasks

- [ ] E1 [P1]: Freeze model, task contract, holdout criteria and protected hashes; create pure model/presets. Findings 1/4/5. Verify literal values and independent finite differences. Human ~2h / agent ~20–40min.
- [ ] E2 [P1]: Build scientific-atlas still and responsive explorer from that model; native optional Q&A/cards and static alternatives. Findings 1/5/6. Verify actual control effects, baseline/reset and desktop/390px/zoom/focus. Human ~1 day / agent ~1–2h.
- [ ] E3 [P1]: Export JS snapshots, synthesize local narration, render real changing geometry and encode MP4 with captions/transcript/keyframes. Findings 1/4/8. Verify numerical parity, decode, frame inspection and listening. Human ~1–2 days / agent ~2–4h plus review.
- [ ] E4 [P1]: Connect native video clock to recorded scene, seek/transcript and Explore/Return state machine; install inline native cues. Findings 2/3/6. Verify file:// and HTTP transitions, boundary cues and media errors. Human ~4h / agent ~45–90min.
- [ ] E5 [P1]: Package portable candidate/playbook/artifacts and run the frozen checks; independent actual-output/code review, at most two repair candidates. Findings 2/6/7/8. Verify relocated offline entry, protected hashes and evidence boundaries. Human ~1 day / agent ~1–2h plus review.

```jsonl
{"id":"E1","phase":"eng-review","priority":"P1","component":"model/contract","title":"Freeze boundaries and implement shared exact model","source_finding":"1 4 5"}
{"id":"E2","phase":"eng-review","priority":"P1","component":"stills/explorer","title":"Compose causal responsive atlas and optional practice","source_finding":"1 5 6"}
{"id":"E3","phase":"eng-review","priority":"P1","component":"media","title":"Render locally narrated film from exported model snapshots","source_finding":"1 4 8"}
{"id":"E4","phase":"eng-review","priority":"P1","component":"interactive video","title":"Bind native media clock and isolated explore state","source_finding":"2 3 6"}
{"id":"E5","phase":"eng-review","priority":"P1","component":"delivery/evidence","title":"Package and inspect extracted offline bundle under frozen gates","source_finding":"2 6 7 8"}
```

Core model/content must precede both still/browser and film adapters. Those adapters may proceed independently only after shared snapshots are fixed; integration and final evidence are sequential. Two possible lanes, one shared dependency; no concurrent edits of model/content. Root currently owns implementation, so no extra execution agents are launched by this reviewer.

## Completion and outside voice

Step 0 accepted CEO scope; architecture 3 findings, quality 3, performance 2; test diagram and explicit checks produced. All listed findings have selected mitigations; execution evidence remains pending. Complete media scope selected over placeholders. No new TODOs. At most two repair candidates and the frozen budget stop this run; two no-gain candidates also stop. A repair cannot mutate the spec/evaluator/gates. No global log completion or shipping clearance is claimed.

Parent outside-voice challenge received: “approve bounded vertical slice, challenge media full scope only justified if local render real; don't let report perfection delay artifacts.” Accepted within existing authorization: implementation follows freeze immediately, and no prose/media availability claim substitutes for the rendered film. Parent reports an actual 5.675s WAV audition from local HyperFrames 0.8.169/Kokoro-ONNX 0.6.1, voice af_heart at 0.95. This supports synthesis feasibility; it does not establish final narration quality, final-film rendering or listening review. Learner runtime paths remain relative; reproduction tools may discover their environment and record versions. This is an independent coordinating-agent challenge, not a claimed different-model review.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|---|---|---|---|---|---|
| CEO | `/plan-ceo-review` | Scope | 1 | REVIEWED_WITH_CONCERNS | HOLD_SCOPE, complete vertical example |
| Engineering | `/plan-eng-review` | Architecture/quality/tests/performance | 1 | PLAN REVIEWED | 8 findings mitigated in plan; tests/render/listening pending |
| Outside voice | Parent independent challenge | Missed assumptions | 1 | ABSORBED | Real render required; artifact production follows freeze |
| Code/design/audio | Finished artifact review | Product evidence | 0 | POST-IMPLEMENTATION | Required before completion claim |

**VERDICT:** Engineering plan ready for freeze and implementation; delivery acceptance awaits real implementation and review evidence.

NO UNRESOLVED DECISIONS
