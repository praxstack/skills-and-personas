# Code quality review — Neuron Atlas production candidate

Date: 2026-10-18. Initial review verdict: REQUEST CHANGES. Two required changes are listed below; neither requires changing the frozen spec/evaluator. This reviewer owns only this report. No implementation, evaluator, active installation or protected policy was edited. Workers were still finishing their owned assets during the initial read; absence of final packaging/browser/listening receipts is recorded as pending evidence, not invented code defects.

## Context and tests first

Read the complete `code-review-and-quality/SKILL.md`, frozen product specification, frozen behavioral acceptance criteria and independent model evaluator before implementation. Then read `demo/model.js`, `still.js`, `explorer.js`, `index.html`, `atlas.css`, `export-stills.cjs`, `video/film.py`, `build_audio.py`, `build_film.py`, cue data, video reproduction README, candidate loader/reference/patch/status. No hidden evaluator vectors were shared with implementers.

The mathematical evaluator checks independent literal arithmetic, derivatives away from the kink, the declared zero derivative convention, simultaneous atomic updates, bounds and nonmutation. It is meaningful numerical evidence, but cannot establish rendered geometry, responsive readability, media synchronization or production craft. Ran the frozen evaluator against the actual model: PASS. The source implements validation before calculation and validates the whole new state before returning it; no sequential parameter mutation or display rounding feeds computation.

The frozen browser criteria describe actual behaviors rather than DOM-presence assertions. At initial review there was no complete browser-run receipt to certify. I independently exercised a narrow actual-browser smoke below; the separate full browser/craft review remains necessary. No tests or acceptance thresholds were changed.

## Required findings

**CQ1 — Required, correctness/reproduction: narration cache ignores edited narration.** In `demo/video/build_audio.py`, the utterance loop writes `txt.write_text(sentence+'\n')`, then only `if not wav.exists():` decides whether to synthesize. If an author edits a sentence, a previous WAV is silently retained while captions/transcript are generated from the new words. Voice/speed changes have the same stale-cache risk. The delivered instructions explicitly present narration as editable, so this is a functional source-reproduction defect rather than a style preference. Repair: compare a stable synthesis key (text, voice, speed and relevant engine/model identity) before reuse, or resynthesize changed utterances; retain cache hits only with known matching provenance. Sent to video owner and parent promptly. Do not rerender unchanged final media merely to satisfy a test count.

**CQ2 — Required, product completeness: candidate guidance has no demonstrated-artifact links.** Frozen R8 requires a compact entry, production playbook and links to actual demonstrated artifacts. `candidate/references/VISUAL-PRODUCTION.md` currently ends at line 86 after generic recipes and has no links to the delivered neuron example, still, film, editable source or evidence index. `candidate/SKILL.md` links only to that reference; `CANDIDATE-STATUS.json` describes an isolated overlay. Repair: add a small explicitly scoped worked-example section with valid portable relative links and explain the package layout if the overlay is moved/applied. A sibling demo is valid for the review bundle; do not imply the overlay alone installs that demo. Sent to parent, who owns candidate delivery.

## Five axes

| Axis | Finding and assessment |
|---|---|
| Correctness | Core forward/loss/gradient logic matches frozen specification. Baseline is frozen; output/gradients are frozen. Step validates atomically. ReLU convention is explicit. Required CQ1 concerns editable narration cache; CQ2 concerns required demonstrated links. Video timing/caption wording and final-image craft still require artifact review. |
| Readability/simplicity | Four small classic JS files separate math, geometry and host behavior. The controller is compact and explicit enough for this bounded example. Python separates synthesis/encoding from scene composition. No request for a general framework or cosmetic rewrite. |
| Architecture | Browser and vector output share the JS calculator. Python reads exported snapshot state/results and computes only layout/interpolation. Native controls/disclosures/video/text tracks avoid a custom player dependency. Film state locks parameters, Explore pauses and captures time, and explicit Return/native Play restores recorded context. |
| Security | Numeric model inputs are bounded/finite. Dynamic prose uses textContent; SVG text is escaped and numeric coordinates derive from validated values. No runtime fetch, CDN, account, persistent learner storage or grading service was found in reviewed files. Build-time environment paths are local trusted configuration. No security blocker identified within this limited static local scope. |
| Performance | Fixed two-input math and small SVG are bounded. Replacing that SVG per input is acceptable at this scale; no evidence justifies adding render infrastructure. Native media uses its real clock, not a polling animation clock. Sources encode H.264/AAC with faststart and preload metadata. Local production rendering cost is separate from learner runtime. |

## Geometry and state inspection

Read the actual coordinate construction rather than relying on numeric readouts:

- `still.js` signed waterfall places every endpoint through one shared linear `xp` mapping from the cumulative values. Direction reverses for negative terms; the zero reference and dynamic low/high bounds remain present. Activation coordinates use an adaptive domain and output range; the point uses the same z/a returned by the model. Labels and accessible description consume those same values. This is genuine linked geometry, not only changing labels.
- Portrait and landscape are independently composed: portrait moves terms, addition and gate into a vertical chain, preserving their coordinate meanings. Source analysis does not prove every long dynamic label fits; screenshots and boundary states remain part of rendered review.
- Film Contributions uses a number line with 3.5 units of physical length per numerical unit and the same scale for input/weighted bars. Sum uses the number line's `n2p` coordinates for cumulative endpoints. Gate moves through the ReLU kink and flat branch. Learning puts the prediction on a number line and scales the error-square side by absolute error, so square area follows error squared. Python does not calculate a second gradient.
- Film scene labels describe chapter worked results rather than claiming exact frame-by-frame synchronization with prerecorded pixels. Cue selection uses half-open intervals, assigns the last cue at/after its end, and responds to actual seeking/timeupdate events. Current delivered cue intervals are contiguous. Frozen acceptance still requires checking native seeks, transcript seeks, final-frame behavior and failures in the final bundle.
- Optional Q&A uses native details/summary. Flashcard reveal toggles the hidden answer and aria-expanded; Next changes question/answer together and rehides it. No score/mastery/persistence mechanism is introduced.
- Native range inputs expose keyboard adjustment; disabled film controls are restored by Explore. Reset changes parameters and clears stale live-update explanation through the same render path. Invalid steps retain prior state and show an alert.

## Observable checks performed by this reviewer

Used headless installed Google Chrome through the existing Playwright dependency, opening the actual `demo/index.html` via file:// at 390×844. This is simulated browser coverage, not a physical-device or assistive-technology test.

- Initial model and media loaded: width 390, media readyState 4, measured browser duration 82.966667 seconds.
- Bias −1 produced actual output 0.
- Reset + gradient step produced w1=1.66, w2=−0.92 and bias within floating-point tolerance of 0; this agrees with the model arithmetic rather than a label-only assertion.
- Explore allowed a live bias change; Return restored recorded baseline bias −0.2, entered film mode and resumed the actual media element.
- One native English text track had 23 cues under file://; this establishes cue loading, not caption intelligibility/alignment or a subjective audio review.
- No page errors were observed during that narrow flow.
- Opened transcript at 390px and inspected the first seek button: x=16, width=358, right=374, white-space normal. Earlier source read predated an in-flight stylesheet update; the current behavior wraps within the viewport, so no obsolete nowrap finding is promoted.

These checks do not certify the entire acceptance matrix. Do not count dataset state mirrors as independent visual proof; rendered readouts/geometry must still be inspected. No subjective listening, real-time full watch, screen-reader pass, complete offline-relocation package pass or original-vs-candidate aesthetic verdict was performed by this reviewer.

## Candidate policy boundary

The loader addition requires the existing `.engine/SKILL.md` first and explicitly calls the new reference supplementary. It retains explanation-first behavior, optional practice and active-project artifact location. The reference repeatedly preserves consent/privacy/source-integrity/evidence policy, rejects automatic mastery claims and distinguishes availability/render/tests from production quality. The overlay status explicitly says it is not a complete installable skill. No policy regression was identified in these reviewed additions. Full base/package hash preservation remains the orchestrator's separate integrity receipt; I do not infer it merely from the patch text.

## Follow-up boundary

One initial review and one focused follow-up after CQ1/CQ2 repair are authorized. The follow-up should inspect the repaired cache/link behavior and any related changed paths, then record the final verdict here. No new evaluator, broad pipeline expansion or active installation is part of this review. Separate rendered craft/audio review is a product acceptance step, not replaced by this report.

## Focused follow-up after required repairs

Reviewed only CQ1/CQ2 corrections and their directly related source/evidence. No frozen gate or evaluator was edited.

**CQ1 resolved.** `synthesize_utterance` now binds exact sentence text, voice, speed, live HyperFrames/TTS/Kokoro version identity and actual WAV SHA-256 in a sidecar written only after successful nonempty-WAV synthesis. A missing receipt, mismatched request or changed bytes forces new synthesis through a temporary file. The import guard permits tests without invoking live TTS. I read tests first and independently ran `python3 -m unittest -v test_audio_cache.py`: all six regressions passed, covering matching reuse, changed text, voice/speed/engine changes, corrupt audio, unbound legacy audio and failed synthesis. These are behavioral cache checks; no final-audio quality inference follows from them.

Inspected `evidence/video-audio-cache-repair.json` and checked actual files: twelve sidecars match their WAV hashes; all twelve source-WAV hash bindings and all twelve provenance hash bindings in `metadata.json` match; all four recorded build-source hashes match. The repair receipt records actual regeneration of twelve legacy utterances and byte equality to previous audio. Current MP4 bytes match the repair receipt's unchanged-video hash. Final model snapshot SHA-256 also matches the rendered-film metadata after snapshot generation was added to `export-stills.cjs`; that exporter computes its baseline/inactive/trained states through the authoritative JS model. No final-film rerender is needed merely because a truthful narration cache was added and byte-identical audio regenerated.

**CQ2 content repair verified; final target pending.** The production reference now has a compact demonstrated-example section, links to actual model/still/film/source artifacts and an explicit sibling `candidate/`/`demo/` review-bundle layout. It correctly says a future isolated complete skill package must carry/adjust its example links. The regenerated patch contains that section. Thirteen artifact links resolve on disk. At this inspection, the remaining `../../reports/DELIVERY.md` link target has not yet been materialized by the parent; this is a pending final-delivery target, not a new design issue. CQ2 can close when that named file exists and is an honest evidence summary.

Follow-up verdict: CQ1 CLOSED; CQ2 awaiting the already-planned delivery-summary file. No other required code defect identified in the focused changed paths. Subjective listening remains explicitly NOT PERFORMED in metadata; no listening, screen-reader, full-watch or universal craft approval is implied. The separate full browser/rendered acceptance work remains outside this code review.

Final link verification: the parent materialized `reports/DELIVERY.md`; independently rechecked all fourteen reference links and every target resolves to an actual file. CQ2 CLOSED.

**Final code-review verdict: APPROVE for the bounded reviewed candidate code.** Both required findings are resolved, with the cache regressions and concrete file/hash/link checks above. This supersedes the initial REQUEST CHANGES and intermediate pending-link status. It is not active-install, publication, subjective-audio or overall product-craft acceptance; the unperformed listening/AT/full-watch limits remain explicit.

## Final focused media-boundary correction

Independently diffed current `demo/explorer.js` against the retained `evidence/rejected-media-boundary/explorer.js`. The sole behavioral change is cue comparison: authored bounds and native `currentTime` are floored to integer microseconds before applying strict half-open intervals. It does not add an epsilon window, nudge seek/return times, change media playback, alter model presets or introduce an application clock. The defined last-cue fallback at/after final duration is preserved. This is a narrow correction for observed Chrome seek precision; it does not claim identical clock precision in every browser.

Ran an independent real-media file:// probe in installed headless Chrome. All six cue starts select their intended cue; each of the five nonzero starts tested one media microsecond earlier selects the preceding cue. For example, seeking the authored 19.266666666666666 boundary yields actual currentTime 19.266666 and now correctly selects `sum`; 19.266665 still selects `contributions`. Backward seeks in the probe also reconcile correctly. Seeking exact measured duration 82.966667 selects `learning-result`. Eleven boundary probes plus final-duration check passed. The parent separately reports chapter/transcript/native controls and return-at-play coverage; those broader actions are not relabeled as this reviewer's independent checks.

**Approval remains: APPROVE bounded reviewed code, including this cue-boundary fix.** No new required defect identified; frozen specification/evaluation remain untouched. Subjective listening, AT and full-watch limitations above still apply.
