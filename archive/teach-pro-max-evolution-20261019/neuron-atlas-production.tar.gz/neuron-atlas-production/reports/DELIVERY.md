# Delivery and evidence

The product is one connected artificial-neuron explanation demonstrated across exact stills, an interactive model, optional Q&A/flashcards, a narrated film and a media-clock-driven explorer. It is a production reference and candidate instruction improvement, not a universal renderer or a replacement deep-learning curriculum.

## Open the work

- [Neuron Atlas: complete interactive explanation](../demo/index.html).
- [Baseline still](../demo/exports/baseline.png), [editable SVG](../demo/exports/baseline.svg), [portrait SVG](../demo/exports/baseline-portrait.svg), [inactive contrast](../demo/exports/inactive.png), [trained result](../demo/exports/trained.png).
- [Narrated film](../demo/video/neuron-narrated.mp4), [WebVTT captions](../demo/video/captions.vtt), [transcript](../demo/video/transcript.md), [editable film source](../demo/video/film.py).
- [Complete static mathematical derivation](../demo/lesson.html).
- [Twenty researched production approaches](../research/20-approaches.html).
- [Deep issue/shortcut inventory](DEEP-REVIEW.md), [code-quality review](04-code-quality-review.md), [independent rendered review](05-rendered-review.md).
- [CEO review](../plans/01-ceo-review.md), [engineering review](../plans/02-engineering-review.md), [frozen specification](../spec/03-product-spec.md).
- [Proposed skill patch](../candidate/proposed-changes.patch), [production reference](../candidate/references/VISUAL-PRODUCTION.md).

## What is established

The independent frozen mathematical evaluation passed 2,736 checks across 72 held-out numerical cases, including finite-difference derivatives away from the ReLU kink, simultaneous updates, invalid-input rejection and nonmutation. This establishes that bounded toy model's tested behavior; it is not a visual-quality score or human-learning evidence.

Six exact SVGs and six 2× PNGs cover baseline, inactive and trained states in landscape and portrait. An independent reviewer inspected actual exports, four final video keyframes, desktop and 390px browser states against the rejected course. The review found concrete improvements in signed geometry, mechanism visibility and responsive composition, with no required corrective finding in those inspected states. Optional refinements and limitations remain documented.

The local neural-narrated MP4 is 82.966667 seconds, 1920×1080 at 30 fps, H.264/AAC. Full decoding passed. Six concept cues and 23 short caption cues are shipped. Sentence audio boundaries were measured; within-sentence caption splits are proportional estimates, not forced alignment. The narration-cache defect found during review was repaired with six passing regressions; all 12 formerly unbound utterances were genuinely regenerated, their hashes matched the delivered audio, and a subsequent build needed no synthesis. No subjective listening or continuous full-length watch is claimed.

The separate parent-run [browser receipt](../evidence/browser-verification.json) passed actual offline file:// playback, forward/backward/transcript seeking, explore/edit/restore/resume, final-duration state, independently recomputed control effects, simultaneous training, reset, keyboard controls, reduced motion, native captions and no-script reading. Desktop and 390px diagrams fit without horizontal clipping. A 200% CSS-zoom layout check passed; browser-toolbar zoom, physical devices and assistive technology were not tested. No external requests, page exceptions or stored learner state were observed. The independently relocated demo also worked offline. These exercised checks do not constitute completion of every manual acceptance criterion.

## Boundaries

The accepted baseline, human-owned identity policy, frozen spec/evaluators, active skill and rejected course were not modified by this run. Candidate instruction changes are delivered as an isolated overlay and patch. `candidate/` alone is not a complete installable skill; its loader still depends on the complete accepted `.engine` tree. No old acceptance receipt is relabeled as certifying this overlay. Any installation/promotion should use a complete versioned package with explicit current evidence.

No paid service, public upload, account creation, analytics or learner-state collection was introduced. No learner performance has been observed. There is no universal 'world-class', assistive-technology-conformance or learner-outcome certification. Voice synthesis success, audio metadata, mathematical correctness, aesthetic review and learning evidence are separate claims.

## Remaining document-validation finding

All 13 canonical Markdown companions were rendered and checked for current source metadata and local links. The unchanged accepted validator reports 12 unsupported-form findings on disabled, labelled checklist boxes it generated in the two frozen review plans. These are static checklist displays, with no grading behavior. This renderer/validator mismatch remains unresolved; the frozen plans and validator were preserved. Other companion checks and frozen-file hashes passed. See [raw receipt](../evidence/document-validation.json).
