# Independent rendered craft review

Reviewed 2026-10-18. Reviewer did not author the current UI, stills or video and did not inspect or modify the frozen holdout vectors during this review. This is a bounded visual and interaction review against the existing product specification, not a certification of aesthetic excellence or a learning-outcome study.

**Disposition:** no required corrective finding arose from the inspected renders and exercised states. The candidate shows a concrete qualitative improvement over the supplied rejected screenshots: signed magnitude has become visible geometry, the ReLU operation has its own graph, and the phone layout preserves the complete computation. Optional refinements below do not block this bounded slice. Mathematical evaluator results and full browser acceptance remain separate evidence.

## Directly inspected artifacts

- Stills viewed with the image tool: `demo/exports/baseline.png`, `baseline-portrait.png`, `inactive.png`, `trained.png`.
- Production video keyframes viewed with the image tool: `evidence/video-keyframes/01-contributions-production.jpg`, `02-sum-production.jpg`, `03-gate-production.jpg`, `04-learning-production.jpg`. Draft and repaired intermediary keyframes were not used as evidence for the final film.
- Rejected comparison screenshots viewed directly: `/Users/prax/Developer/neuron-to-deep-learning/verification/desktop-2.png` and `mobile-2.png`.
- Fresh screenshots from actual headless Google Chrome, launched through the installed Playwright module, loading local `demo/index.html`: 1440×1000 and 390×844 CSS pixels. Full-page captures are `evidence/craft-desktop.png` and `craft-mobile.png`; detail captures are `craft-mobile-diagram.png`, `craft-mobile-film.png`, `craft-mobile-inactive.png`, `craft-desktop-trained.png`, `craft-desktop-negative.png`, and `craft-desktop-film-return.png`.

The full-page phone image is long; the diagram and film detail captures were also inspected at their actual readable size. A compressed full-page thumbnail alone would be inadequate to judge typography. Screenshots capture the candidate at review time; other agents were still preparing final artifacts, so these are time-specific observations rather than proof of a later bundle's identity.

## Mathematical geometry and explanation

**Signed multiplication and addition are visibly encoded.** In the baseline still, the positive term extends right from zero by approximately 300 image pixels; the negative contribution moves left by approximately 100 and bias by approximately 50 on the same scale. These match magnitudes 1.2, 0.4 and 0.2. Vertical guides connect successive endpoints. The final endpoint is 0.6. This geometry does explanatory work that the rejected uniform connector lines did not do. Signs remain in text as well as color.

The inactive still retains the same contribution lengths and extends the negative bias to magnitude 1, finishing left of zero at −0.2. Its ReLU point is on the horizontal zero-output branch, not below the horizontal axis. The trained still shows 0.8×1.66=1.328 and 0.4×−0.92=−0.368 with visibly different lengths and a zero bias represented by a point; the endpoint and ReLU output are 0.96. I observed no mismatched sign, swapped input/weight or contradictory endpoint in these three still states.

**The activation is a function rather than an unexplained box.** Both branches of ReLU are shown: constant zero for negative z, positive linear branch for positive z. Input z and output a are labeled on their respective axes; the active point has guides, and the inactive point sits on the zero branch. In the latest browser extreme-state capture the axes include numerical extent labels: a highly compressed positive branch at z=−15 is an effect of the explicitly unequal data ranges, not a negative ReLU output. That distinction matters when interpreting apparent screen slope.

The actual browser negative extreme was exercised through exposed inputs after opening “Inspect inputs and weights”: x₁=−2,w₁=3,x₂=2,w₂=−3,b=−3. It rendered contributions −6,−6 and −3 as leftward head-to-tail segments, endpoint −15 and output zero. The origin and all three terms stayed within the chart. This check concerns geometry and actual parameter effects, not merely an arithmetic label snapshot.

**The film's sampled frames also support the mathematics.** The contribution frame has a common zero with approximately 3:1 lengths for +1.2 and −0.4. The sum frame has explicitly directed head-to-tail arrows, correctly scaled 1.2:0.4:0.2, and a guide ending at 0.6. The gate frame shows the negative-bias case at (−0.2,0), a labeled domain, and the stated zero-derivative convention for z≤0. The learning frame places a=0.96 just left of target 1 on its number line. The small error square has about one-tenth the side of the larger reference square, consistent with one-hundredth the area. Its label says area is proportional to error squared, avoiding an unsupported claim that square area equals the half-squared loss numerically.

**Learning is anchored to a particular example.** The browser explains the baseline loss and gradients beside the simultaneous parameter update. The trained live state displays the updated parameters and output rather than a decorative success indicator. Numeric display uses rounded values and the page discloses rounding; zero-bias display does not expose floating-point residue as a false nonzero effect. The fixed comparison table and prerecorded example are explicitly distinguished from the live model. No mastery or generalization claim was observed.

## Composition and visual hierarchy

The new still has a clear left-to-right argument: multiply → add → gate. Large output values conclude each stage, while quieter labels identify the operation. The navy field, lavender positive terms, coral negative terms and mint output form a restrained semantic palette. The negative case retains the same composition, allowing direct comparison. Typography distinguishes prose from exact numbers, and the diagrams have fewer competing surfaces than the rejected panel containing a large empty node network.

The browser extends that argument into an article: mechanism, one primary bias control, optional input/weight controls, baseline comparison, loss/update, narrated exploration, and optional practice. The visual reading order agrees with the mathematical reading order. It uses generous space without placing unexplained oversized hubs between the explanatory text and its result. The gradient section is a purposeful two-column relationship on desktop and becomes a linear explanation on the phone.

At 390px the full live SVG recomposes vertically; it does not shrink the desktop chart or crop the output. Its inspected bounding box was 358px wide with a 360-unit viewBox, and core equation text uses 18px source sizing, approximately 17.9 CSS pixels at that width. The observed document width and scroll width were both 390px. The full computation is long enough to require vertical scrolling, but every required term and the output remains available without lateral traversal. That directly improves on the rejected phone screenshot, which visibly clips the sum/activation/output to the right and explicitly tells the learner to scroll the diagram horizontally.

The video keyframes have a consistent atlas visual language without being repeated title cards: independent contribution bars, head-to-tail sum arrows, activation axes, then a target number line/error area. Their titles and large numeric labels are legible at the inspected 1920×1080 size. The four images demonstrate distinct mathematical compositions; still images alone cannot establish the animation's temporal continuity or narration timing.

## Film/explore facts exercised in the browser

Using the actual concept button for the negative ReLU segment sought the media to **46.9 seconds**, paused, and set the companion bias to −1. Choosing “Pause & explore” and moving bias to +1 changed the live companion while the actual video stayed paused at 46.9. Choosing “Return & resume” restored bias −1 and resumed the actual video at the same 46.9-second position. The captured return state again showed z=−0.2,a=0.

The page explicitly states that film mode shows the chapter's worked result, not every interpolated animation frame or earlier live changes. That disclosure is necessary: a precomputed film should not silently impersonate a live recomputation. This sampled flow respected the separation. Initial page loads at both viewports produced no observed page exceptions, and the actual local video reported duration 82.966667 seconds. This limited observation does not replace a complete media/console/network or cue-boundary test.

## Optional refinements, not required corrective findings

1. Zero bias currently inherits coral styling. Its “0” and point are unambiguous, but a neutral zero treatment could make the positive/negative color rule more precise.
2. At 390px, a landscape film's detailed math is naturally small in the inline player. Native full-screen playback, captions, the live portrait diagram and the static/transcript alternatives mitigate this. A dedicated portrait film would improve phone viewing but is an additional production format, not required scope.
3. The additive still uses endpoint dots and guides rather than explicit arrowheads. The heading and signs make the intended direction recoverable, and the film supplies actual arrows. Arrowheads could reduce the inference for first-time readers if they preserve exact lengths and endpoint clarity.

These are preferences for a future iteration, not reasons to expand this candidate or weaken a frozen gate. No repair/review loop was requested by this report.

## Evidence boundaries

This review establishes what was visible in named images and the limited actual browser interactions described above. It does not establish universal visual quality, learning improvement, screen-reader usability, physical-device behavior, full keyboard coverage, all mathematical edge cases or exhaustive video cue synchronization. Full subjective listening, narration-naturalness review and continuous end-to-end film watching were **not performed** here. Those limits must remain in the final evidence report even when file metadata, captions or numerical tests pass.
