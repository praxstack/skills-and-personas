# Deep review: explanatory craft, mathematics and implementation

This is a scoped inventory of issues found in the inspected clean skill, its production guidance, the delivered neuron course, and the new candidate's verification obligations. It does not claim every file in the archive received a line-by-line audit, or that no undiscovered issue exists. Findings distinguish an observed defect, a capability gap, a reasoned risk and a preference. 'Shortcut' describes observable work; it does not infer a person's motivation.

The diagnosis is both a generation gap and a skill gap. The rejected course chiefly failed in execution: composition, causal comparison, responsive layout and honest verification were choices the existing teaching contract did not require me to get wrong. The skill also lacked demonstrated production recipes and strong evidence for narrated/video exploration. The new bounded example and proposed overlay address those observed gaps; they do not establish universal quality.

## Product and presentation

| # | Severity / evidence | Issue and consequence | Required remedy or scope |
| --- | --- | --- | --- |
| 01 | High / observed | The mobile diagram hides the activation/output off-screen. The simple mechanism cannot be read as a whole. | Recompose the causal chain for narrow screens; verify every required region fits and remains legible. |
| 02 | High / observed | The training capstone shows loss and probabilities but no hidden units, gradients or parameter changes. | Show the operative mechanism before accelerating training; avoid presenting metrics as explanation. |
| 03 | High / observed | Six simultaneous controls lack an anchored controlled comparison. The learner has to remember the overwritten baseline. | Fixed baseline/current views, nearby explanation and explicit reset. |
| 04 | High / observed | Explanatory paragraphs narrate defaults while live controls show a different state. | Derive current explanation from the model and label the fixed worked example separately. |
| 05 | Medium / observed | Identical bordered lab shells and repeated banners replace subject-specific composition. | Give structure, quantities and transformation different visual treatments. |
| 06 | Medium / observed | Large unused fixed-ratio SVG regions reduce useful information density. | Compose around relationships and label adjacency; use space deliberately rather than padding a template. |
| 07 | Medium / observed | Biology's rounded axon blocks are unlabeled and invariant; their role is ambiguous. | Name the represented structure or remove it. Never leave a mark that invites a false mechanism. |
| 08 | Medium / observed | Palette tokens were copied without the promised coach annotations or consistent technical typography. | Translate style into visual reasoning and hierarchy; a palette is not an art direction. |
| 09 | Medium / observed | Chapter navigation is a table of contents, not a prerequisite/branch map. | State the purpose and reason for progression; a full graph is unnecessary if one sentence establishes the connection. |
| 10 | Medium / preference | The user rejected the old aesthetics. A new dark scientific-atlas direction is a design hypothesis, not a universal improvement. | Inspect actual examples independently and retain the user's ability to reject the direction. |
| 11 | Medium / observed | Large focused heading outlines dominate saved screenshots, obscuring resting-state composition. | Retain visible keyboard focus but document and inspect both resting and focused states. |
| 12 | Medium / gap | No explicit artistic acceptance language beyond colors, font roles and generic inspection. | Define a concrete brief and inspect composition, hierarchy, density, diagram language and responsive states. |

## Mathematics and causal explanations

| # | Severity / evidence | Issue and consequence | Required remedy or scope |
| --- | --- | --- | --- |
| 13 | High / risk | A correct endpoint does not ensure quantitatively correct intermediate animation. | Recompute from authoritative parameters; inspect representative intermediate frames and label nonphysical layout transitions. |
| 14 | High / risk | Cross-media calculators can drift in signs, rounding, derivative conventions or presets. | Share one executable model and generated snapshots; check literal values independently. |
| 15 | High / risk | Sequential in-place parameter updates use changed gradients/weights and no longer implement the stated simultaneous step. | Compute every gradient from the old state, then atomically update all parameters. |
| 16 | High / risk | ReLU at zero is nondifferentiable; silent conventions can invalidate a gradient claim. | State the chosen zero derivative convention; use finite differences away from the kink. |
| 17 | High / risk | Invalid numbers or silent slider clamping can make numeric labels disagree with geometry. | Validate finite domains; reject invalid/out-of-domain steps atomically; display actual current state. |
| 18 | Medium / observed limit | Selected numerical tests are not proof of every gradient or every model state. | Use independent varied cases and targeted numerical derivatives, while keeping scope explicit. |
| 19 | High / risk | Negative weights, biological inhibition and software activation can be conflated. | State the analogy limit; the mathematical neuron is not a membrane or spike simulator. |
| 20 | Medium / risk | A sigmoid value may be presented as guaranteed calibrated confidence. | Distinguish numeric transform, probability modeling assumption and calibration. The present demonstrator uses ReLU without a probability claim. |
| 21 | Medium / observed | A four-case XOR fit can appear to prove generalization through its continuous background map. | Label binary training coverage and separate extrapolation from held-out performance. |
| 22 | Medium / risk | An axis/trend can be numerically accurate but misleading through scaling, omitted units or sign direction. | Mark domains, units, origin and reference conditions; compare encoded lengths with the values they represent. |

## Interaction, video and audio

| # | Severity / evidence | Issue and consequence | Required remedy or scope |
| --- | --- | --- | --- |
| 23 | High / gap | Packaged browser scope is one floating-point lesson; broad subject support depends on the authoring agent. | Demonstrate a new mechanism with real controls; do not infer a generic renderer from one example. |
| 24 | High / gap | A 'motion' route can verify ordered static fallback states without producing motion footage. | Name actual delivery precisely and require actual changing geometry for a video claim. |
| 25 | High / gap | No previously exercised narration/voice/pronunciation/listening/sync/export chain was established. | Synthesize, measure, time, render, inspect, caption and report listening evidence separately. |
| 26 | High / risk | Captions estimated from word counts can drift from real audio. | Use measured segment timing; inspect both caption segmentation and scene boundary alignment. |
| 27 | High / risk | A second app timer drifts when video seeks, buffers or changes playback rate. | Use media currentTime as source of truth; define cue boundary behavior. |
| 28 | High / risk | Live controls beside prerecorded pixels can imply edits affect the film. | Explicit FILM/EXPLORE state; pause intentionally; label fixed recorded facts and restore context on return. |
| 29 | High / risk | Audio may autoplay or resume unexpectedly after a seek/focus event. | Initial playback only through user action; explicit explore/return policy and native controls. |
| 30 | Medium / risk | External VTT and ES modules can fail when opening a local file. | Classic browser scripts, inline cue data/native TextTrack plus standalone WebVTT; test file and served routes if promised. |
| 31 | Medium / gap | Tool names and stale registry paths are mistaken for available, tested production. | Distinguish registry entry, installed version, successful execution and inspected output. Current Manim/HyperFrames skills are available in Codex even where older registry paths were absent. |
| 32 | Medium / risk | TTS metadata or ASR is described as listening review. | Clearly disclose which auditory checks were actually performed. Subjective pacing/timbre judgment remains distinct. |
| 33 | Medium / risk | Flashcard flips or Q&A expansion imply learning or silently collect analytics. | Optional reveal, no grading or storage without consent; no mastery labels from clicks. |

## Engineering, evidence and skill design

| # | Severity / evidence | Issue and consequence | Required remedy or scope |
| --- | --- | --- | --- |
| 34 | High / observed | 'No document overflow' passed while a required diagram was locally clipped. | Check visible semantic bounds and inspect the actual phone view, not only root scrollWidth. |
| 35 | High / observed | 58 control-state events were not 58 verified causal effects. | Assert expected numbers and diagram states after representative changes; state what each test proves. |
| 36 | Medium / observed | Keyboard, reduced-motion and no-script assertions were much narrower than their summary labels. | Test relevant behaviors; name unperformed AT and full navigation checks. |
| 37 | Medium / observed | Hardcoded author-machine build paths reduce reproducibility. | Learner runtime uses relative local assets; build scripts accept/discover tooling and fail clearly. |
| 38 | Medium / observed | Dense generated source and hand-maintained HTML complicate review and correction. | Readable modules with clear ownership; canonical text plus generated companion; avoid a general abstraction layer. |
| 39 | High / observed limit | Rebinding historical receipts is not a fresh browser or media run. | Preserve old provenance and separately record current checks. |
| 40 | High / observed | A stale archived skill attachment drove quiz-first behavior despite the current loader directing explanation-first. | Resolve current canonical entry, keep archive snapshots out of discovery, honor Answer now immediately. |
| 41 | Medium / gap | Adding more prose can mask missing production competence. | Every major guidance addition should correspond to a demonstrated useful artifact or observed failure. |
| 42 | Medium / risk | Specialist guidance contains brittle universal rules: only monospace text, never hard-cut, rotate dominant color each scene, always zero-baseline line charts. | Treat these as context-dependent recipes. Current Manim officially supports proportional Pango text; typography/layout must be inspected. Stable semantic colors and truthful scales outrank arbitrary variety. |
| 43 | High / risk | The candidate can 'improve' by editing its spec, acceptance criteria or evidence claims. | Freeze spec/evaluator/budget before changes; candidate edits only; stop rather than weaken criteria. |
| 44 | Medium / observed limit | A single polished neuron example cannot establish 'any artifact' or universal excellence. | Deliver a documented route and useful examples; keep generality, craft preference and learner outcomes separate. |

### Defects discovered during the implementation review

| # | Severity / evidence | Issue and correction |
| --- | --- | --- |
| 45 | High / observed, repaired | Narration build cached by WAV existence only. Edited text could silently keep old speech while producing new captions. Cache now binds text, voice, speed, actual engine versions and audio hash. Six behavioral regressions pass; all 12 unbound utterances were genuinely regenerated and matched the delivered audio bytes. |
| 46 | High / observed, repaired | Native media time rounded 56.833333333s to 56.833333s, potentially selecting the previous half-open cue on a concept seek. Cue membership now uses half-open integer-microsecond boundaries consistent with the native media clock; mathematical tolerances are unchanged. All six boundaries, one microsecond before, backward seeks and exact final duration were exercised. |
| 47 | Medium / observed provenance discrepancy | Earlier wrapper/help version strings differed. The repaired audio builder records versions from the actual executing project environment rather than normalizing inconsistent labels into an assumed version. Executable presence and help text alone were insufficient provenance. |
| 48 | Medium / observed validator limitation, unresolved | The accepted renderer generates disabled, labelled checklist inputs from review-plan Markdown, but its own document validator rejects every input as an unsupported grading runtime. Twelve findings remain across the two frozen plan companions. The plans contain no grading behavior. Frozen plans and accepted validation rules were preserved; this mismatch is disclosed rather than suppressed. |

## Observable shortcuts in my earlier work

- I expanded to ten chapters before establishing one excellent visual direction.
- I reused one generic stage rather than composing for each relationship.
- I exposed controls without a retained baseline or a consistent nearby causal explanation.
- I used horizontal scrolling as the answer to a simple mobile diagram.
- I treated selected arithmetic checks and event counts as a stronger delivery story than they supported.
- I let successful training replace visualization of how training worked.
- I produced a large source/bundle before obtaining evidence that its central visual explanation was good.

These are concrete shortcuts and execution failures. Calling them 'laziness' does not diagnose a model's internal motivation. The remedies are better choices, better artifacts and sharper observation—not stronger adjectives in the handoff.

## Research and source boundaries

See [20 production approaches](../research/20-approaches.md) for official sources and suitability decisions. Mathematical neuron/activation/gradient grounding: [D2L multilayer perceptrons](https://en.d2l.ai/chapter_multilayer-perceptrons/mlp.html), [D2L computational graphs/backpropagation](https://d2l.ai/chapter_multilayer-perceptrons/backprop.html). Font claim check: [Manim rendering text/formulas](https://docs.manim.community/en/stable/guides/using_text.html). This review distinguishes underlying technical facts from aesthetic judgments and implementation hypotheses.
