# A neuron, made visible

`neuron-narrated.mp4` is the learner artifact; `poster.jpg`, `captions.vtt`, `cues.js` and `transcript.md` supply the browser experience. Playback uses no external services. Keep the MP4 and companion assets beside the local demo.

`film.py` is the editable Manim source. It reads `../model-snapshots.json` exported by the JS model. It has no independent neuron implementation. Positions, bar lengths, sum endpoints and error-square areas come from those snapshots. Decimal display rounding never feeds model computation. Fonts: Avenir Next display, Menlo vector labels, native fallback if absent.

Reproduction: install Manim CE 0.22 and ffmpeg; provision hyperframes local Kokoro with kokoro-onnx 0.6.1. Set `HYPERFRAMES_PYTHON` to that local environment's Python if required. Run `python3 build_film.py` from this directory. It synthesizes missing utterances locally, measures them, renders 1920×1080 at 30 fps, checks segment duration parity, concatenates, muxes AAC narration and writes measured metadata. WAV reuse requires a matching `.provenance.json` binding the exact sentence, voice, speed, live tool versions and WAV hash. Missing or mismatched provenance triggers local resynthesis. No LaTeX required.

`build_audio.py` contains editable narration. Each sentence WAV is measured with ffprobe and padded by at least 0.4 seconds to a whole video frame. `timing.json` drives the renderer; `cues.js` drives browser concepts. Captions use measured sentence boundaries and estimated proportional timing for shorter 12-word cues; they are not word-aligned ASR. Four recorded states are immutable: baseline, baseline, inactive contrast, trained result. Explore mode is implemented by the host.

No subjective listening, assistive-technology review, or full real-time video watch is claimed. File probes and frame inspection cannot establish those checks.

Narration cache regression checks: `python3 -m unittest discover -s . -p test_audio_cache.py -v`. These use mocked synthesis and cover edits, configuration changes, corrupted audio, legacy unbound files and failed generation.
