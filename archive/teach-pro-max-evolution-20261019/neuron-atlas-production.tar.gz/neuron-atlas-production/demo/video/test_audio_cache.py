"""Behavior regressions for narration provenance; no real TTS or network calls."""
import json,pathlib,tempfile,unittest,wave
from build_audio import synthesize_utterance

class AudioCacheTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.root=pathlib.Path(self.temp.name);self.wav=self.root/'speech.wav';self.txt=self.root/'speech.txt';self.calls=[]
 def fake_tts(self,args,**kwargs):
  self.calls.append(args)
  out=pathlib.Path(args[args.index('--output')+1])
  with wave.open(str(out),'wb') as f:
   f.setnchannels(1);f.setsampwidth(2);f.setframerate(24000);f.writeframes(b'\0\0'*240)
 def invoke(self,text='Original sentence.',voice='af_heart',speed=.95,engine='test-engine-1'):
  return synthesize_utterance(text,self.txt,self.wav,voice=voice,speed=speed,engine_version=engine,runner=self.fake_tts)
 def test_unchanged_request_hits_bound_audio(self):
  self.assertEqual(self.invoke(),'synthesized');self.assertEqual(self.invoke(),'hit');self.assertEqual(len(self.calls),1)
 def test_changed_text_resynthesizes_and_rebinds(self):
  self.invoke();self.assertEqual(self.invoke(text='Edited sentence.'),'synthesized')
  receipt=json.loads(self.wav.with_suffix('.provenance.json').read_text())
  self.assertEqual(receipt['request']['text'],'Edited sentence.');self.assertEqual(len(self.calls),2)
 def test_voice_speed_and_engine_changes_each_resynthesize(self):
  self.invoke();self.invoke(voice='af_nova');self.invoke(voice='af_nova',speed=1.1);self.invoke(voice='af_nova',speed=1.1,engine='test-engine-2')
  self.assertEqual(len(self.calls),4)
 def test_corrupt_audio_resynthesizes(self):
  self.invoke();self.wav.write_bytes(b'corrupt');self.assertEqual(self.invoke(),'synthesized');self.assertEqual(len(self.calls),2)
 def test_unbound_legacy_audio_is_not_trusted(self):
  self.wav.write_bytes(b'old audio');self.assertEqual(self.invoke(),'synthesized');self.assertEqual(len(self.calls),1)
 def test_failed_synthesis_cannot_stamp_provenance(self):
  def fail(*args,**kwargs):raise RuntimeError('mock failure')
  with self.assertRaises(RuntimeError):
   synthesize_utterance('Fail',self.txt,self.wav,voice='af_heart',speed=.95,engine_version='test',runner=fail)
  self.assertFalse(self.wav.with_suffix('.provenance.json').exists())

if __name__=='__main__':unittest.main()
