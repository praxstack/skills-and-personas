"""Local narration build. Run from this directory; requires hyperframes, ffmpeg."""
import json,subprocess,os,math,pathlib,hashlib,wave,datetime
P=pathlib.Path(__file__).resolve().parent
chapters=[
 ('contributions','Signed contributions','baseline',[
 'A neuron starts with contributions, not votes.',
 'The first input, zero point eight, is multiplied by one point five. Its contribution grows to positive one point two.',
 'The second input is zero point four. A negative weight reverses it, giving negative zero point four.'
 ]),
 ('sum','Add the signed lengths','baseline',[
 'Now place those contributions head to tail on one shared scale.',
 'Start at zero. Move right by one point two, then left by zero point four.',
 'The bias subtracts another zero point two. The endpoint is zero point six. That signed sum is z.'
 ]),
 ('inactive','ReLU is a gate','inactive',[
 'ReLU keeps positive sums and clips negative sums to zero. Here, zero point six passes through unchanged.',
 'Change only the bias to negative one. The sum becomes negative zero point two, but the output is zero.',
 'In this example, the derivative at zero and below is defined as zero.'
 ]),
 ('learning','One simultaneous update','trained',[
 'Return to the active example. The target is one; the squared loss is zero point zero eight.',
 'Multiply each baseline gradient by one half, then subtract those amounts from all three parameters simultaneously.',
 'The new prediction is zero point nine six. The remaining error is ten times smaller; its squared loss is one hundred times smaller: zero point zero zero zero eight.'
 ])]
def sha(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()

def detect_engine_version(env):
 """Version identity comes from the executables used for this invocation."""
 hyperframes=subprocess.check_output(['hyperframes','--version'],text=True,env=env).strip()
 tts_cli=subprocess.check_output(['hyperframes','tts','--help'],text=True,env=env).splitlines()[0]
 kokoro=subprocess.check_output([env['HYPERFRAMES_PYTHON'],'-c','from importlib.metadata import version; print(version("kokoro-onnx"))'],text=True,env=env).strip()
 return {'hyperframes':hyperframes,'ttsCommand':tts_cli,'kokoro-onnx':kokoro}

def synthesize_utterance(sentence,txt,wav,*,voice,speed,engine_version,env=None,runner=None):
 """Use a WAV only if a previous successful synthesis bound all inputs and bytes.

 Unbound legacy WAVs are regenerated. Sidecars are emitted after a successful
 synthesis, never inferred from a text file found beside an existing WAV.
 """
 runner=runner or subprocess.run
 txt=pathlib.Path(txt);wav=pathlib.Path(wav);sidecar=wav.with_suffix('.provenance.json')
 request={'text':sentence,'voice':voice,'speed':float(speed),'engineVersion':engine_version}
 txt.write_text(sentence+'\n')
 try:
  receipt=json.loads(sidecar.read_text())
  hit=(receipt['request']==request and receipt['audioSha256']==sha(wav))
 except (OSError,ValueError,KeyError):
  hit=False
 if hit:return 'hit'
 temp=wav.with_name(wav.stem+'.render.wav')
 try:
  runner(['hyperframes','tts',str(txt),'--voice',voice,'--speed',str(speed),'--output',str(temp),'--json'],check=True,env=env)
  with wave.open(str(temp),'rb') as audio:
   if audio.getnframes()<=0:raise ValueError('Synthesized audio has no samples')
  audio_hash=sha(temp)
  temp.replace(wav)
  receipt={'schemaVersion':1,'request':request,'audioSha256':audio_hash,'synthesizedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  staged=sidecar.with_suffix('.tmp');staged.write_text(json.dumps(receipt,indent=2)+'\n');staged.replace(sidecar)
 finally:
  if temp.exists():temp.unlink()
 return 'synthesized'

def main():
 # Each sentence is synthesized separately, so captions have measured utterance boundaries.
 env=os.environ.copy()
 env.setdefault('HYPERFRAMES_PYTHON',str(P.parents[1]/'.tools/tts/bin/python'))
 engine_version=detect_engine_version(env)
 clock=0; cues=[]; captions=[]; rows=[]
 for ci,(ident,title,preset,sentences) in enumerate(chapters):
  start=clock; concat=[]
  for si,sentence in enumerate(sentences):
   stem=f'{ci+1:02}-{si+1:02}'; txt=P/'audio'/f'{stem}.txt'; wav=P/'audio'/f'{stem}.wav'
   synthesize_utterance(sentence,txt,wav,voice='af_heart',speed=.95,engine_version=engine_version,env=env)
   duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(wav)]))
   # pad each measured utterance to a whole video frame, plus .4s reading space.
   total=math.ceil((duration+.4)*30)/30
   padded=P/'audio'/f'{stem}-padded.wav'
   subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),'-af',f'apad=whole_dur={total}','-t',str(total),'-ar','24000',str(padded)],check=True)
   concat.append(f"file '{padded}'")
   words=sentence.split(); groups=[words[k:k+12] for k in range(0,len(words),12)]
   used=0
   for group in groups:
    a=clock+duration*used/len(words);used+=len(group);b=clock+duration*used/len(words)
    captions.append(dict(start=a,end=b,text=' '.join(group)))
   clock+=total
  (P/'audio'/f'{ident}-concat.txt').write_text('\n'.join(concat)+'\n')
  out=P/'audio'/f'{ident}.wav'
  subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(P/'audio'/f'{ident}-concat.txt'),'-c','copy',str(out)],check=True)
  cues.append(dict(id=ident,start=start,end=clock,title=title,text=' '.join(sentences),preset=preset))
  rows.append(dict(id=ident,duration=clock-start,sentences=sentences))
 chapter_cues=cues
 cues=[chapter_cues[0],chapter_cues[1],
  dict(chapter_cues[2],id='gate-active',end=chapter_cues[2]['start']+10.9,title='ReLU: positive sums pass',preset='baseline',text=chapters[2][3][0]),
  dict(chapter_cues[2],id='gate-inactive',start=chapter_cues[2]['start']+10.9,title='ReLU: negative sums stop',text=' '.join(chapters[2][3][1:])),
  dict(chapter_cues[3],id='learning-step',end=chapter_cues[3]['start']+16.2,title='Apply the baseline gradients',preset='baseline',text=' '.join(chapters[3][3][:2])),
  dict(chapter_cues[3],id='learning-result',start=chapter_cues[3]['start']+16.2,title='The updated prediction',text=chapters[3][3][2])]
 (P/'cues.json').write_text(json.dumps(cues,indent=2)+'\n')
 (P/'cues.js').write_text('window.NeuronFilmCues = '+json.dumps(cues,indent=2)+';\nwindow.NeuronFilmCaptions = '+json.dumps(captions,indent=2)+';\n')
 (P/'timing.json').write_text(json.dumps(rows,indent=2)+'\n')
 def ts(s):
  ms=round(s*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}.{ms%1000:03}'
 (P/'captions.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{i+1}\n{ts(c["start"])} --> {ts(c["end"])}\n{c["text"]}' for i,c in enumerate(captions))+'\n')
 (P/'captions.json').write_text(json.dumps(captions,indent=2)+'\n')
 (P/'transcript.md').write_text('# A neuron, made visible\n\n'+ '\n\n'.join(f'## {c["title"]}\n\n{c["text"]}' for c in chapter_cues)+'\n')
 print(json.dumps(rows,indent=2));print('TOTAL',clock)

if __name__ == '__main__':
 main()
