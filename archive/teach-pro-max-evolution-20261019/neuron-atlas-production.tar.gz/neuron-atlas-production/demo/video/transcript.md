# A neuron, made visible

## Signed contributions

A neuron starts with contributions, not votes. The first input, zero point eight, is multiplied by one point five. Its contribution grows to positive one point two. The second input is zero point four. A negative weight reverses it, giving negative zero point four.

## Add the signed lengths

Now place those contributions head to tail on one shared scale. Start at zero. Move right by one point two, then left by zero point four. The bias subtracts another zero point two. The endpoint is zero point six. That signed sum is z.

## ReLU is a gate

ReLU keeps positive sums and clips negative sums to zero. Here, zero point six passes through unchanged. Change only the bias to negative one. The sum becomes negative zero point two, but the output is zero. In this example, the derivative at zero and below is defined as zero.

## One simultaneous update

Return to the active example. The target is one; the squared loss is zero point zero eight. Multiply each baseline gradient by one half, then subtract those amounts from all three parameters simultaneously. The new prediction is zero point nine six. The remaining error is ten times smaller; its squared loss is one hundred times smaller: zero point zero zero zero eight.
