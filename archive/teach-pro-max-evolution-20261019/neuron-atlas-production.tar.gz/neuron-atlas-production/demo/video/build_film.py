"""Reproduce the 1080p30 film from the exported JS snapshots and local speech.
Requires Manim CE 0.22, ffmpeg/ffprobe, hyperframes local Kokoro backend.
No network, paid service or learner-runtime dependencies.
"""
import subprocess,json,pathlib,hashlib,platform
P=pathlib.Path(__file__).resolve().parent

def run(args):subprocess.run(args,cwd=P,check=True)
def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(path)]))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
run(['python3','build_audio.py'])
run(['manim','-r','1920,1080','--fps','30','film.py','Contributions','Sum','Gate','Learning'])
rows=json.loads((P/'timing.json').read_text());classes=['Contributions','Sum','Gate','Learning']
clips=[];audio=[];durations=[]
for row,cls in zip(rows,classes):
 v=P/'media/videos/film/1080p30'/f'{cls}.mp4'
 d=float(probe(v)['format']['duration'])
 if abs(d-row['duration'])>.034:raise RuntimeError(f'Scene duration mismatch {cls}: {d} vs {row["duration"]}')
 clips.append(f"file '{v}'");audio.append(f"file '{P/'audio'/ (row['id']+'.wav')}'");durations.append(d)
(P/'concat-video.txt').write_text('\n'.join(clips)+'\n');(P/'concat-audio.txt').write_text('\n'.join(audio)+'\n')
run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i','concat-video.txt','-c','copy','silent.mp4'])
run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i','concat-audio.txt','-c','copy','narration.wav'])
run(['ffmpeg','-v','error','-y','-i','silent.mp4','-i','narration.wav','-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart','-shortest','neuron-narrated.mp4'])
run(['ffmpeg','-v','error','-y','-ss','13','-i','neuron-narrated.mp4','-frames:v','1','poster.jpg'])
cues=json.loads((P/'cues.json').read_text());cues[-1]['end']=float(probe(P/'neuron-narrated.mp4')['format']['duration'])
(P/'cues.json').write_text(json.dumps(cues,indent=2)+'\n')
(P/'cues.js').write_text('window.NeuronFilmCues = '+json.dumps(cues,indent=2)+';\nwindow.NeuronFilmCaptions = '+(P/'captions.json').read_text().strip()+';\n')
meta={'chapterCount':4,'cueCount':6,'modelVersion':json.loads((P.parent/'model-snapshots.json').read_text())['version'],'modelSnapshotSha256':sha(P.parent/'model-snapshots.json'),'sourceSha256':sha(P/'film.py'),'inputHashes':{name:sha(P/name) for name in ['film.py','build_audio.py','build_film.py','test_audio_cache.py']},'narrationProvenanceHashes':{f.name:sha(f) for f in sorted((P/'audio').glob('*.provenance.json'))},'narrationHashes':{f.name:sha(f) for f in sorted((P/'audio').glob('[0-9][0-9]-[0-9][0-9].wav'))},'videoSha256':sha(P/'neuron-narrated.mp4'),'renderer':subprocess.check_output(['manim','--version'],text=True).strip(),'ffmpeg':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0],'speech':{'engine':'Kokoro ONNX local synthesis','engineVersion':json.loads(next((P/'audio').glob('*.provenance.json')).read_text())['request']['engineVersion'],'cachePolicy':'Exact text, voice, speed, live tool versions and WAV hash must match post-synthesis provenance; otherwise regenerate','voice':'af_heart','speed':.95,'local':True,'sentenceTiming':'WAV measured using ffprobe; 0.4s minimum silence padded to 30fps frames','captionTiming':'Measured sentence boundaries; within-sentence 12-word cue boundaries estimated proportionally by word count, not forced alignment'},'sceneDurations':durations,'media':probe(P/'neuron-narrated.mp4'),'checks':{'subjectiveListening':'NOT PERFORMED','completeRealtimeWatch':'NOT PERFORMED','representativeFrameInspection':'Performed on draft and production keyframes; see evidence','mathAuthority':'../model-snapshots.json, exported by the sole JS model; Python interpolates geometry only'},'host':platform.platform()}
(P/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'file':'neuron-narrated.mp4','duration':meta['media']['format']['duration'],'bytes':meta['media']['format']['size']}))
