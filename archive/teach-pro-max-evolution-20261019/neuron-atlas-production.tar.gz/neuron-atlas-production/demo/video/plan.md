# A neuron, made visible

Frozen product spec v1; four chapters, 1920×1080 at 30fps. Correct the idea that a neuron merely adds inputs: signed weights produce contributions, bias shifts the sum, ReLU gates it, and one simultaneous gradient step changes the geometry.

1. **Signed contributions** — input lengths transform into weighted, signed bars on a shared scale. Positive lavender; opposing coral. Native vector labels state each multiplication.
2. **The sum** — the same signed lengths become head-to-tail displacements on a number line; mint locates the resultant. Bias is a separate coral displacement.
3. **The gate** — a point moves along an explicitly labeled ReLU graph from the active example to the inactive contrast, with input and output projections. State the derivative convention.
4. **One learning step** — show baseline gradients and simultaneous parameter changes, then move the prediction toward the fixed target and shrink the squared-error area to one hundredth its former area. Only one update; no convergence claim.

All model numbers are read from ../model-snapshots.json. Python only lays out and interpolates geometry. Local Kokoro af_heart narration, no music. Chapter durations derive measured WAV lengths plus breathing time, quantized to frames. Four top-level cues drive the companion explorer; shorter captions subdivide each chapter using measured sentence utterances. No subjective listening claim.
