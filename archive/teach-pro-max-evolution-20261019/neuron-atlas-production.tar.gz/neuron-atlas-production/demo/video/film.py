"""Editable Manim film. Reads authoritative JS snapshots; no neuron calculator.
Render: manim -r 1920,1080 --fps 30 film.py Contributions Sum Gate Learning
"""
from manim import *
from pathlib import Path
import json
P=Path(__file__).resolve().parent
DATA=json.loads((P.parent/'model-snapshots.json').read_text())
TIMING={x['id']:x['duration'] for x in json.loads((P/'timing.json').read_text())}
B=DATA['baseline'];I=DATA['inactive'];T=DATA['trained']
BG='#0d1120';INK='#edf0fa';DIM='#929bb5';GRID='#354059';POS='#c5b9ff';NEG='#ffa698';OUT='#a6e9d1'
FONT='Menlo';TITLE='Avenir Next'
class AxisText(Text):
 def __init__(self,text,**kwargs):
  kwargs.setdefault('font',FONT);super().__init__(text,**kwargs)
def fmt(v,places=3):
 if abs(v)<1e-10:v=0
 return f'{v:.{places}f}'.rstrip('0').rstrip('.')
def txt(s,size=25,color=INK):return Text(s,font=FONT,font_size=size,color=color)
def bar(value,origin,scale,color):
 end=origin+RIGHT*value*scale
 return Line(origin,end,color=color,stroke_width=24)
class FilmScene(Scene):
 chapter='';number=''
 def setup(self):
  self.camera.background_color=BG
  self.began=self.time
 def heading(self,title,subtitle):
  eyebrow=txt('A NEURON, MADE VISIBLE   /   '+self.number,18,DIM).move_to([-6.2,3.4,0],aligned_edge=LEFT)
  head=Text(title,font=TITLE,font_size=45,color=INK,weight=MEDIUM).move_to([-6.2,2.68,0],aligned_edge=LEFT)
  note=txt(subtitle,20,DIM).move_to([-6.2,2.05,0],aligned_edge=LEFT)
  self.add(eyebrow,head,note)
  self.add(Line([-6.2,-3.34,0],[6.2,-3.34,0],color=GRID,stroke_width=1))
  self.add(txt('DIMENSIONLESS TOY MODEL',16,DIM).move_to([-6.2,-3.58,0],aligned_edge=LEFT))
 def fitwait(self):
  self.wait(max(.1,TIMING[self.chapter]-(self.time-self.began)-.6))
  self.play(FadeOut(Group(*self.mobjects)),run_time=.6)
class Contributions(FilmScene):
 chapter='contributions';number='01 / 04'
 def construct(self):
  self.heading('Weights give inputs direction','The length is magnitude. The direction is sign.')
  zero=np.array([.0,0,0]);scale=3.5
  axis=NumberLine(x_range=[-1,1.5,.5],length=8.75,include_numbers=True,label_constructor=AxisText,font_size=22,color=GRID).move_to([.875,-1.9,0])
  # Shared x-origin is exactly the number-line origin.
  x0=axis.n2p(0)[0]
  guides=VGroup(*[Line([axis.n2p(v)[0],-1.65,0],[axis.n2p(v)[0],1.1,0],color=GRID,stroke_opacity=.35,stroke_width=1) for v in [-1,-.5,0,.5,1,1.5]])
  self.play(Create(axis),Create(guides),run_time=1)
  origins=[np.array([x0,.85,0]),np.array([x0,-.65,0])]
  l1=txt(f'x₁ = {fmt(B["state"]["x1"])}',27).move_to([-5.8,.85,0],aligned_edge=LEFT)
  l2=txt(f'x₂ = {fmt(B["state"]["x2"])}',27).move_to([-5.8,-.65,0],aligned_edge=LEFT)
  a=bar(B['state']['x1'],origins[0],scale,POS);b=bar(B['state']['x2'],origins[1],scale,POS)
  self.play(FadeIn(l1),Create(a),run_time=1.2);self.wait(1)
  self.play(Transform(a,bar(B['result']['c1'],origins[0],scale,POS)),run_time=2)
  first=txt(f'× {fmt(B["state"]["w1"])}  →  +{fmt(B["result"]["c1"])}',25,POS).move_to([2.5,1.4,0])
  self.play(FadeIn(first),run_time=.6);self.wait(2)
  self.play(FadeIn(l2),Create(b),run_time=1.2);self.wait(1)
  self.play(Transform(b,bar(B['result']['c2'],origins[1],scale,NEG)),run_time=2)
  second=txt(f'× ({fmt(B["state"]["w2"])})  →  {fmt(B["result"]["c2"])}',25,NEG).move_to([1.6,-1.25,0])
  self.play(FadeIn(second),run_time=.6)
  self.add_subcaption('Signed weighted contributions share one scale.',duration=4)
  self.fitwait()
class Sum(FilmScene):
 chapter='sum';number='02 / 04'
 def construct(self):
  self.heading('Addition is a journey','Keep the same signed lengths. Put them head to tail.')
  axis=NumberLine(x_range=[-.4,1.6,.2],length=10,include_numbers=True,label_constructor=AxisText,font_size=23,color=GRID).move_to([0,-1.8,0])
  self.play(Create(axis),run_time=1)
  vals=[0,B['result']['c1'],B['result']['c1']+B['result']['c2'],B['result']['z']]
  ypos=[1,0,-1];colors=[POS,NEG,NEG]
  labels=[f'w₁x₁ = +{fmt(B["result"]["c1"])}',f'w₂x₂ = {fmt(B["result"]["c2"])}',f'b = {fmt(B["state"]["b"])}']
  dot=Dot(axis.n2p(0),radius=.09,color=OUT);self.add(dot)
  for j in range(3):
   p=np.array([axis.n2p(vals[j])[0],ypos[j],0]);q=np.array([axis.n2p(vals[j+1])[0],ypos[j],0])
   arrow=Arrow(p,q,buff=0,color=colors[j],stroke_width=8,max_tip_length_to_length_ratio=.18)
   lab=txt(labels[j],24,colors[j]).next_to(arrow,UP,buff=.2)
   self.play(GrowArrow(arrow),FadeIn(lab),dot.animate.move_to(axis.n2p(vals[j+1])),run_time=2)
   self.wait(1.6)
  result=txt(f'z = {fmt(B["result"]["z"])}',44,OUT).move_to([3,-2.65,0])
  projection=DashedLine([axis.n2p(vals[-1])[0],-1.05,0],axis.n2p(vals[-1]),color=OUT)
  self.play(Create(projection),FadeIn(result),run_time=1)
  self.add_subcaption('The endpoint of signed addition is z = 0.6.',duration=4)
  self.fitwait()
class Gate(FilmScene):
 chapter='inactive';number='03 / 04'
 def construct(self):
  self.heading('ReLU keeps only the positive part','a = max(0, z)')
  ax=Axes(x_range=[-.6,1.2,.3],y_range=[0,1.2,.3],x_length=6.7,y_length=3.3,axis_config={'color':GRID,'include_tip':False,'font_size':22,'label_constructor':AxisText}).move_to([-1.8,-.1,0])
  ax.add_coordinates()
  curve=VGroup(Line(ax.c2p(-.6,0),ax.c2p(0,0),color=OUT,stroke_width=7),Line(ax.c2p(0,0),ax.c2p(1.2,1.2),color=OUT,stroke_width=7))
  axislabels=VGroup(txt('sum z',22,DIM).next_to(ax,DOWN,buff=.35),txt('output a',22,DIM).next_to(ax,LEFT,buff=.25).rotate(PI/2))
  self.play(Create(ax),Create(curve),FadeIn(axislabels),run_time=1.5)
  p=Dot(ax.c2p(B['result']['z'],B['result']['a']),radius=.11,color=POS)
  vertical=DashedLine(ax.c2p(B['result']['z'],0),p.get_center(),color=POS)
  card=VGroup(txt('ACTIVE',20,POS),txt(f'z = {fmt(B["result"]["z"])}',30),txt(f'a = {fmt(B["result"]["a"])}',30,OUT)).arrange(DOWN,buff=.3).move_to([4.3,.6,0])
  self.play(FadeIn(p),Create(vertical),FadeIn(card),run_time=1);self.wait(5)
  newcard=VGroup(txt('BIAS = −1',20,NEG),txt(f'z = {fmt(I["result"]["z"])}',30,NEG),txt(f'a = {fmt(I["result"]["a"])}',30,OUT)).arrange(DOWN,buff=.3).move_to(card)
  # Movement follows the graph: along positive branch to kink, then flat left.
  self.play(p.animate.move_to(ax.c2p(0,0)),Uncreate(vertical),run_time=2)
  self.play(p.animate.move_to(ax.c2p(I['result']['z'],I['result']['a'])).set_color(NEG),Transform(card,newcard),run_time=1.4)
  self.wait(2)
  convention=txt('Convention: ReLU derivative = 0 for z ≤ 0',22,DIM).move_to([0,-2.98,0])
  self.play(FadeIn(convention),run_time=.7)
  self.add_subcaption('Negative sum, zero output. Derivative convention: zero at z ≤ 0.',duration=4)
  self.fitwait()
class Learning(FilmScene):
 chapter='learning';number='04 / 04'
 def construct(self):
  self.heading('One step toward the target','L = ½(a − y)²     ·     η = 0.5     ·     simultaneous update')
  g=B['result']['grad']
  grad=txt('∇L = ('+', '.join(fmt(g[k]) for k in ['w1','w2','b'])+')',28,NEG).move_to([-6.0,1.15,0],aligned_edge=LEFT)
  params=txt('(w₁, w₂, b) = ('+', '.join(fmt(B['state'][k]) for k in ['w1','w2','b'])+')',25).move_to([-6, .45,0],aligned_edge=LEFT)
  newparams=txt('(w₁, w₂, b) = ('+', '.join(fmt(T['state'][k]) for k in ['w1','w2','b'])+')',25,POS).move_to(params,aligned_edge=LEFT)
  rule=txt('θ ← θ − η∇L',27,POS).move_to([4.5,1.15,0])
  axis=NumberLine(x_range=[0,1.2,.2],length=8,include_numbers=True,label_constructor=AxisText,font_size=23,color=GRID).move_to([-1.7,-1.1,0])
  target=DashedLine(axis.n2p(B['state']['target'])+DOWN*.2,axis.n2p(B['state']['target'])+UP*.8,color=INK)
  targetlabel=txt('target = 1',21).next_to(target,UP,buff=.16)
  dot=Dot(axis.n2p(B['result']['a']),radius=.1,color=OUT)
  atext=txt('a = '+fmt(B['result']['a']),27,OUT).move_to([-4,-2,0])
  loss=txt('L = '+fmt(B['result']['loss'],4),27,NEG).move_to([-4,-2.65,0])
  # Error square: its side is |a-y| on a fixed 5-unit scale, so area ∝ squared error.
  side=abs(B['result']['error'])*5
  square=Square(side_length=side,color=NEG,fill_color=NEG,fill_opacity=.25).move_to([4.3,-1.5,0])
  squarelabel=txt('area ∝ error²',20,DIM).move_to([4.3,-2.85,0])
  self.play(FadeIn(grad),FadeIn(params),Create(axis),Create(target),FadeIn(targetlabel),FadeIn(dot),FadeIn(atext),FadeIn(loss),Create(square),FadeIn(squarelabel),run_time=1.5)
  self.wait(5)
  self.play(FadeIn(rule),run_time=.7);self.wait(2)
  self.play(Transform(params,newparams),run_time=2);self.wait(2)
  self.add(square.copy().set_fill(opacity=0).set_stroke(opacity=.22))
  small=Square(side_length=abs(T['result']['error'])*5,color=OUT,fill_color=OUT,fill_opacity=.5).move_to(square)
  newa=txt('a = '+fmt(T['result']['a']),27,OUT).move_to(atext,aligned_edge=LEFT)
  newloss=txt('L = '+fmt(T['result']['loss'],4),27,OUT).move_to(loss,aligned_edge=LEFT)
  self.play(dot.animate.move_to(axis.n2p(T['result']['a'])),Transform(square,small),Transform(atext,newa),Transform(loss,newloss),run_time=3)
  self.wait(1.5)
  final=txt('10× smaller error  →  100× smaller loss',23,OUT).move_to([0,1.15,0])
  self.play(FadeOut(grad),FadeOut(rule),run_time=.4)
  self.play(FadeIn(final),run_time=.7)
  self.add_subcaption('One simultaneous gradient update: prediction 0.96, loss 0.0008.',duration=5)
  self.fitwait()
