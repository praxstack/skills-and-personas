# Neuron Atlas: how a number becomes a prediction

This is an exact mathematical toy neuron, not a biological spike simulator. [Open the visual explorer](index.html) to change inputs, inspect signed contributions, and explore the recorded explanation.

## 1. Inputs become signed contributions

An input is a supplied number. A weight controls its influence. With x₁=0.8 and w₁=1.5, the first contribution is +1.2. With x₂=0.4 and w₂=−1, the second contribution is −0.4. The positive contribution pushes the score up; the opposing contribution pushes it down. The sign belongs to the product, so a negative input can reverse a negative weight's contribution.

## 2. Add a bias

The bias shifts the sum independently of the supplied input values. For b=−0.2:

**z = w₁x₁ + w₂x₂ + b = 1.2 − 0.4 − 0.2 = 0.6.**

The signed waterfall visual places each displacement on the same scale, so its endpoint represents z. All toy values here are dimensionless. Changing an input is inference on another example; manually changing a parameter is an experiment, not automatically training.

## 3. Apply an activation

ReLU is **a = max(0,z)**. It retains the positive part. At z=0.6, output a=0.6. Change only the bias to −1 and the sum becomes −0.2; ReLU outputs zero. This is a numeric piecewise-linear function. It does not reproduce a cell's membrane voltage or chemical signaling.

## 4. Measure an error and learn

Let the desired target be y=1 and define **L=½(a−y)²**. The initial error is −0.4 and loss is0.08. The gradient is local sensitivity of loss to a parameter. While this ReLU is active, the chain rule gives:

| Parameter | Gradient | Old value | New value with η=0.5 |
| --- | --- | --- | --- |
| w₁ | −0.32 | 1.5 | 1.66 |
| w₂ | −0.16 | −1 | −0.92 |
| b | −0.4 | −0.2 | 0 |

All three updates use the old gradients simultaneously: parameter ← parameter − η×gradient. The new sum is1.328−0.368+0=0.96, output0.96 and loss0.0008. That reduction is true for this example and rate, not a guarantee for every step or every model.

At z<0, ReLU's derivative is0, so this unit's parameter gradients are blocked for this squared-loss example. At z=0 the derivative is undefined; the implementation explicitly uses the common convention0. Finite-difference checks avoid treating that kink as a smooth point.

## 5. Connect units into layers

A later layer consumes outputs of earlier units. Composing learned nonlinear transformations creates a deep network. Stacking only affine transformations remains affine. A neuron in biology does not literally evolve into software; the connection is a progression of mathematical ideas loosely inspired by biological signaling.

## Explore the film honestly

The narrated film uses the fixed baseline and worked update above. Its chapter explanation follows the media clock. Choose pause-and-explore to stop it and inspect a live model. Changing a live control does not change the prerecorded pixels or narration. Return-to-film restores recorded context at the paused time. Native video controls, a readable transcript, captions and this static explanation remain available.

Q&A disclosures and flashcard reveals are optional review tools. No score, mastery inference, learning profile or browser storage is created. Reloading restores defaults.

## Sources and limits

Primary readings: [D2L: multilayer perceptrons and activation functions](https://en.d2l.ai/chapter_multilayer-perceptrons/mlp.html), [D2L: computational graphs and backpropagation](https://d2l.ai/chapter_multilayer-perceptrons/backprop.html). Retrieved2026-10-18. The particular arithmetic, visual design and synthetic example are authored for this demonstration. Numbers are displayed rounded; the executable model uses binary floating point and tests account for representational tolerance. All exported authoritative labels and relationships use exact authored text/vector geometry.

No learner performance has been observed. No learning-gain, universal quality or assistive-technology conformance claim follows from using the artifacts. Audio metadata, technical tests and subjective listening review are reported separately in the evidence summary.
