#!/usr/bin/env node
/* Rebuild editable exact SVGs and high-resolution PNGs. Build-time Playwright only. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const M=require('./model.js'),V=require('./still.js');
const output=path.join(__dirname,'exports');fs.mkdirSync(output,{recursive:true});
function playwright(){
  const candidates=[process.env.PLAYWRIGHT_MODULE,'playwright',path.join(os.homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean);
  for(const candidate of candidates){try{return require(candidate);}catch(error){if(error.code!=='MODULE_NOT_FOUND')throw error;}}
  throw new Error('Install Playwright for building PNGs or set PLAYWRIGHT_MODULE to its module path. SVGs require only Node.');
}
function chrome(){
  const candidates=[process.env.CHROME_PATH,'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/usr/bin/google-chrome','/usr/bin/chromium','/usr/bin/chromium-browser'].filter(Boolean);
  return candidates.find(candidate=>fs.existsSync(candidate));
}
(async()=>{
  const states={baseline:M.BASE,inactive:{...M.BASE,b:-1},trained:M.step(M.BASE)};
  const snapshotNames=['baseline','trained','inactive'];
  const snapshots={version:'1.0.0',units:'dimensionless illustrative values'};
  for(const name of snapshotNames)snapshots[name]={state:states[name],result:M.evaluate(states[name])};
  fs.writeFileSync(path.join(__dirname,'model-snapshots.json'),JSON.stringify(snapshots,null,2));
  const titles={baseline:'A neuron, made visible',inactive:'When the ReLU gate closes',trained:'After one simultaneous update'};
  const jobs=[];
  for(const [name,state] of Object.entries(states))for(const portrait of [false,true]){
    const stem=name+(portrait?'-portrait':'');const svg=V.render(state,{portrait,title:titles[name]});
    fs.writeFileSync(path.join(output,stem+'.svg'),svg);jobs.push({stem,svg,portrait});
  }
  const {chromium}=playwright(),executablePath=chrome();
  const browser=await chromium.launch(executablePath?{executablePath,headless:true}:{headless:true});
  try {
    for(const job of jobs){
      const page=await browser.newPage({viewport:{width:job.portrait?360:1120,height:job.portrait?860:435},deviceScaleFactor:2});
      await page.setContent(`<html><head><style>body{margin:0}svg{display:block}</style></head><body>${job.svg}</body></html>`);
      await page.locator('svg').screenshot({path:path.join(output,job.stem+'.png')});await page.close();
    }
  } finally {await browser.close();}
  console.log(`Exported ${jobs.length} editable SVGs and ${jobs.length} 2× PNGs into ${output}`);
})().catch(error=>{console.error(error.message);process.exitCode=1;});
