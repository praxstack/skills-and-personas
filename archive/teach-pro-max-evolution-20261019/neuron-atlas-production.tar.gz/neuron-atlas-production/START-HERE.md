# Neuron Atlas — production review and demonstrator

Open [the interactive Neuron Atlas](demo/index.html) locally. No server, account, network, package installation or autoplay is required. Keep the complete extracted folder together.

## See the artifacts

- [Interactive explorer and video explorer](demo/index.html): change signed contributions, compare with a retained baseline, take one simultaneous gradient step, pause the film to explore, then restore and resume.
- [Baseline PNG](demo/exports/baseline.png), [editable SVG](demo/exports/baseline.svg), [portrait PNG](demo/exports/baseline-portrait.png). The exports folder contains six SVGs and six PNGs across baseline, inactive and trained states.
- [83-second narrated film](demo/video/neuron-narrated.mp4), [transcript](demo/video/transcript.html), [captions](demo/video/captions.vtt), [rebuild instructions](demo/video/README.html).
- [Complete mathematical derivation](demo/lesson.html), optional Q&A and flashcards in the explorer.

## Read the review

- [Delivery, verification and limits](reports/DELIVERY.html).
- [48 issues and observable shortcuts](reports/DEEP-REVIEW.html).
- [Twenty researched production approaches](research/20-approaches.html).
- [CEO review](plans/01-ceo-review.html), [engineering review](plans/02-engineering-review.html), [frozen product specification](spec/03-product-spec.html).
- [Code-quality review](reports/04-code-quality-review.html), [independent rendered review](reports/05-rendered-review.html).

## Candidate skill guidance

[candidate/](candidate/CANDIDATE-STATUS.json) contains a proposed instruction overlay and patch, not a complete installable skill. The accepted engine and active skill remain outside this bundle. Read [the production guidance](candidate/references/VISUAL-PRODUCTION.md); promotion requires a complete versioned skill package. No active skill installation is claimed.

## Rebuild and verify

Runtime assets are local. Rebuilding images requires Node, Playwright and Chrome; run `node demo/export-stills.cjs`. Set `PLAYWRIGHT_MODULE` or `CHROME_PATH` if discovery cannot find them. Mathematical checks: `node evaluation/model-holdout.cjs demo/model.js`. Browser checks: `node evidence/browser-check.cjs` with the same tool overrides. Video reproduction requires Manim, ffmpeg and local Kokoro as documented in its README. Dependencies and intermediate renderer caches are excluded from this portable bundle.

The numerical model passed 2,736 held-out checks. The film fully decoded; actual stills, video keyframes and desktop/phone layouts were independently inspected. No subjective narration listening, continuous real-time film watch, assistive-technology or learner testing is claimed. Caption sub-sentence times are estimates. This is one demonstrated mechanism and a production reference, not a full deep-learning course or proof of universal visual excellence.
