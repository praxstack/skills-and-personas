"""AC-2.8, AC-8.7 (subprocess boundary), AC-8.8 (no broad except)."""
import ast
import json
import re
import sys

from ptk import host

PTK = host.PKG / "ptk"
BOUNDARY = {"host.py", "node.py"}


def _py():
    return [p for p in PTK.rglob("*.py") if "__pycache__" not in p.parts]


# expect.py may use these standard-library modules and nothing else: no ptk module at all,
# so neither capture code nor anything that imports it can reach the expectations (D17.5).
EXPECT_ALLOWED_IMPORTS = {"math", "fractions", "decimal", "struct", "inspect", "itertools", "functools", "re"}
DYNAMIC_IMPORTS = {"__import__", "import_module", "exec", "eval", "reload"}


def _expect_import_problems(src):
    problems = []
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.ImportFrom):
            if node.level or (node.module or "").split(".")[0] not in EXPECT_ALLOWED_IMPORTS:
                problems.append(f"line {node.lineno}: from {'.' * node.level}{node.module or ''} import ...")
        elif isinstance(node, ast.Import):
            problems += [f"line {node.lineno}: import {a.name}" for a in node.names
                         if a.name.split(".")[0] not in EXPECT_ALLOWED_IMPORTS]
        elif isinstance(node, ast.Call):
            name = getattr(node.func, "id", None) or getattr(node.func, "attr", None)
            if name in DYNAMIC_IMPORTS:
                problems.append(f"line {node.lineno}: dynamic {name}()")
    return problems


def test_expect_independent():
    """AC-2.8: ptk/expect.py imports nothing from ptk.capture, directly, dynamically or transitively."""
    # the checker itself catches each way of reaching capture code
    for planted in ("from .capture import c_runner", "from ptk.capture.c_runner import select",
                    "import ptk.capture", "from . import host", "import os, subprocess",
                    "import importlib\nm = importlib.import_module('ptk.capture')", "m = __import__('ptk')"):
        assert _expect_import_problems(planted), f"the lint missed: {planted!r}"
    problems = _expect_import_problems((PTK / "expect.py").read_text())
    assert not problems, f"expect.py imports outside its allowlist: {problems}"
    # and at run time, in a fresh interpreter: importing ptk.expect loads no other ptk module
    probe = "import sys, json, ptk.expect; print(json.dumps(sorted(m for m in sys.modules if m.startswith('ptk'))))"
    env = host.child_env({"PYTHONPATH": str(host.PKG), "PYTHONDONTWRITEBYTECODE": "1"})
    res = host.run([sys.executable, "-I", "-c", f"import sys; sys.path.insert(0, {str(host.PKG)!r}); {probe}"],
                   env=env, timeout=60)
    assert res.code == 0, res.stderr[-800:]
    loaded = json.loads(res.stdout)
    assert loaded == ["ptk", "ptk.expect"], f"importing ptk.expect loaded {loaded}"
    return {"loaded": loaded}


BROAD = {"Exception", "BaseException"}


def _broad_problems(src, label="<src>"):
    """Every handler that catches Exception or BaseException: bare, by name, as builtins.X, or inside a tuple."""
    def broad(t):
        if t is None:
            return True
        if isinstance(t, ast.Name):
            return t.id in BROAD
        if isinstance(t, ast.Attribute):
            return t.attr in BROAD
        if isinstance(t, ast.Tuple):
            return any(broad(e) for e in t.elts)
        return False
    return [f"{label}:{n.lineno}" for n in ast.walk(ast.parse(src))
            if isinstance(n, (ast.ExceptHandler,)) and broad(n.type)]


def test_no_broad_except():
    """AC-8.8: no `except Exception`, `except BaseException` or bare `except:` anywhere in ptk/,
    including tuples and `builtins.Exception`. The checker proves it catches each form first."""
    for planted in ("try:\n x()\nexcept:\n pass", "try:\n x()\nexcept Exception:\n pass",
                    "try:\n x()\nexcept (ValueError, Exception) as e:\n pass",
                    "try:\n x()\nexcept builtins.BaseException:\n pass",
                    "try:\n x()\nexcept* Exception:\n pass"):
        assert _broad_problems(planted), f"the lint missed: {planted!r}"
    assert not _broad_problems("try:\n x()\nexcept (ValueError, OSError):\n pass")
    bad = []
    for p in _py():
        bad += _broad_problems(p.read_text(), str(p.relative_to(host.PKG)))
    assert not bad, bad
    return {"files": len(_py())}


SPAWN_MODULES = {"subprocess", "multiprocessing", "pty", "pexpect", "sh", "plumbum", "concurrent.futures.process"}
SPAWN_CALLS = {"system", "popen", "spawnl", "spawnle", "spawnlp", "spawnlpe", "spawnv", "spawnve", "spawnvp",
               "spawnvpe", "execl", "execle", "execlp", "execlpe", "execv", "execve", "execvp", "execvpe", "fork",
               "forkpty", "posix_spawn", "posix_spawnp", "startfile", "create_subprocess_exec",
               "create_subprocess_shell", "ProcessPoolExecutor"}


def _spawn_problems(src, label="<src>"):
    """Any way to start a process: importing a spawning module (directly, from-import or dynamically),
    or calling os.system/popen/spawn*/exec*/fork/posix_spawn, asyncio's subprocess helpers, a process pool."""
    out = []
    for n in ast.walk(ast.parse(src)):
        if isinstance(n, ast.Import):
            out += [f"{label}:{n.lineno} import {a.name}" for a in n.names
                    if a.name in SPAWN_MODULES or a.name.split(".")[0] in SPAWN_MODULES]
        elif isinstance(n, ast.ImportFrom):
            mod = n.module or ""
            if mod in SPAWN_MODULES or mod.split(".")[0] in SPAWN_MODULES:
                out.append(f"{label}:{n.lineno} from {mod} import ...")
            out += [f"{label}:{n.lineno} from {mod} import {a.name}" for a in n.names if a.name in SPAWN_CALLS]
        elif isinstance(n, ast.Call):
            f = n.func
            name = f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", None)
            if name in SPAWN_CALLS:
                out.append(f"{label}:{n.lineno} {name}()")
            if name in ("__import__", "import_module") and n.args and isinstance(n.args[0], ast.Constant) \
                    and str(n.args[0].value).split(".")[0] in SPAWN_MODULES:
                out.append(f"{label}:{n.lineno} dynamic import of {n.args[0].value}")
    return out


def _boundary_env_problems(src, label):
    """In host.py and node.py every subprocess call passes an env built by the contract helper."""
    out = []
    for n in ast.walk(ast.parse(src)):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) \
                and n.func.value.id == "subprocess" and n.func.attr in ("Popen", "run", "call", "check_call",
                                                                        "check_output"):
            env = next((k.value for k in n.keywords if k.arg == "env"), None)
            ok = isinstance(env, ast.Call) and getattr(env.func, "id", None) == "contract_env"
            if not ok:
                out.append(f"{label}:{n.lineno} subprocess.{n.func.attr} without env=contract_env(...)")
    return out


def test_subprocess_boundary():
    """AC-8.7: only ptk/host.py and ptk/node.py start processes, and host.py hands every child the
    spec 5.5 env through contract_env(). The checkers prove they catch each planted form first."""
    for planted in ("import subprocess", "from subprocess import run", "import os\nos.system('x')",
                    "import os\nos.posix_spawn('x', [], {})", "os.execvp('x', [])", "from os import popen",
                    "import importlib\nimportlib.import_module('subprocess')", "__import__('subprocess')",
                    "import asyncio\nasyncio.create_subprocess_exec('x')", "import multiprocessing",
                    "from concurrent.futures import ProcessPoolExecutor", "import pty"):
        assert _spawn_problems(planted), f"the lint missed: {planted!r}"
    assert _boundary_env_problems("import subprocess\nsubprocess.run(['x'])", "p")
    assert _boundary_env_problems("import subprocess\nsubprocess.Popen(['x'], env=os.environ)", "p")
    assert not _boundary_env_problems("import subprocess\nsubprocess.run(['x'], env=contract_env(e))", "p")
    bad = []
    for p in _py():
        if p.parent == PTK and p.name in BOUNDARY:
            bad += _boundary_env_problems(p.read_text(), p.name)
            continue
        bad += _spawn_problems(p.read_text(), str(p.relative_to(host.PKG)))
    assert not bad, f"only ptk/host.py and ptk/node.py may start processes, always with the env contract: {bad}"
    node_src = (PTK / "node.py").read_text()
    assert not _spawn_problems(node_src), "node.py goes through host.run, it never spawns directly"
    return {"files": len(_py())}


def test_guard_constructs_match_schema():
    """Review WP2 P1-1: the constructs a claim may declare in `overrides` are exactly the ones the
    source guard refuses, so neither list can drift from the other."""
    from ptk.capture import guard
    schema = json.loads((host.PKG / "schemas" / "lesson.schema.json").read_text())
    enum = schema["$defs"]["claim"]["properties"]["overrides"]["items"]["enum"]
    assert sorted(enum) == sorted(guard.CONSTRUCTS), (sorted(enum), sorted(guard.CONSTRUCTS))
    return {"constructs": len(enum)}


# ---------------------------------------------------------------- AC-1.10 (SPEC v1.4)

# Sentences that make prediction the default, or let workspace files set the mode. Each pattern is
# one of the drifted v2.1 sentences (plan/EVIDENCE-PREDICT-FIRST.md) or its paraphrase family.
PREDICT_DEFAULT = [
    r"workspace(?: contract| files?)?[^.\n]{0,40}\b(?:wins?|beats?|overrides?|takes? precedence)\b",
    r"\bcontract (?:wins|beats|overrides)\b",
    r"\b(?:agents|mission|notes)\.md\b[^.\n]{0,80}\b(?:wins?|beats?|overrides?|takes? precedence)\b",
    r"counts as predict-first",
    r"\bin a predict-first workspace\b",
    r"\bpredict-first workspace\b",
    r"\bthe way (?:his|her|their|the) workspace asks\b",
    r"\bpredict-first wins\b",
    r"\bstart (?:each|every|the first)(?: learning)? (?:session|lesson|request|turn) with (?:one|a)\b[^.\n]{0,30}\bpredict",
    r"\b(?:by default|default(?: mode)? is)[^.\n]{0,30}\b(?:predict|quiz|socratic)",
    r"\bworkspace[^.\n]{0,40}\b(?:requires?|demands?) (?:a )?predict",
]
NO_PREDICT_FILES = ["SKILL.md", "README.md", "references/TEACHING.md", "references/LESSON-MODEL.md",
                    "ptk/route_rules.json", "ptk/route.py", "ptk/workspace.py"]
EXPLAIN_FIRST_STATED = {
    "references/TEACHING.md": [r"explanation first", r"every workspace", r"optional", r"answer now", r"workspace_conflict"],
    "SKILL.md": [r"explanation first", r"every workspace", r"workspace_conflict"],
    "ptk/route_rules.json": [r"explanation first", r"workspace_conflict"],
}


def _predict_default_problems(text, label="<text>"):
    low = text.lower()
    return [f"{label}: {m.group(0)!r}" for p in PREDICT_DEFAULT for m in re.finditer(p, low)]


def test_no_predict_first_default():
    """AC-1.10: TEACHING.md, SKILL.md and route_rules.json state the explanation-first rule of AC-1.3 and hold no
    instruction that makes prediction the default (README, LESSON-MODEL.md, route.py and workspace.py too).
    The lint first proves it catches each drifted sentence and passes the rule itself."""
    drifted = ["The workspace contract wins over these defaults.", "A workspace that only says \"Socratic\" counts as predict-first.",
               "In a predict-first workspace the first turn is one question.", "Teach Prax a C topic the way his workspace asks.",
               "When files disagree, predict-first wins.", "Start the first learning session with one short C output prediction.",
               "AGENTS.md, MISSION.md and NOTES.md are read first, and their teaching rules beat the skill's defaults.",
               "By default, ask one prediction question."]
    for s in drifted:
        assert _predict_default_problems(s), f"the lint missed: {s!r}"
    rule = ("Every teaching request gets the complete explanation first, in every workspace. Practice is optional and "
            "offered after it. Workspace files never switch the default to prediction; the route reports workspace_conflict.")
    assert not _predict_default_problems(rule), _predict_default_problems(rule)
    problems = []
    for rel in NO_PREDICT_FILES:
        problems += _predict_default_problems((host.PKG / rel).read_text(), rel)
    for rel, needs in EXPLAIN_FIRST_STATED.items():
        low = (host.PKG / rel).read_text().lower()
        problems += [f"{rel} does not state {n!r}" for n in needs if not re.search(n, low)]
    table = json.loads((host.PKG / "ptk" / "route_rules.json").read_text())
    problems += ["route_rules.json: workspace files are a mode stage"] * ("workspace" in table["precedence"])
    problems += ["route_rules.json: a workspace contract maps to a mode"] * ("contract_modes" in table)
    problems += [f"route_rules.json: default mode is {table['default_mode']!r}"] * (table["default_mode"] != "explain")
    for mode in ("explain", "lesson", "full-pack"):
        ft = table["first_turn"][mode]
        problems += [f"route_rules.json: the {mode} first turn asks a question"] * (ft["questions"] != 0 or ft["kind"] == "question")
        problems += [f"route_rules.json: the {mode} first turn does not offer practice after"] * \
            ("practice" not in ft["instruction"].lower())
    assert not problems, problems
    return {"files": len(NO_PREDICT_FILES), "drifted_caught": len(drifted)}


# ---------------------------------------------------------------- explanation first in the artifacts (SPEC v1.4)

# A sentence that asks the learner to predict, pick, choose, guess or commit, or to try before the answer.
BARRIER = [
    r"\bpredict(?:s|ed|ing|ion|ions)?\b",
    r"\b(?:pick|picks|choose|chooses|commit|commits|guess|guesses)\b",
    r"\bbefore (?:you )?(?:read|see|watch|reveal|open)\b",
    r"\b(?:answer|try|attempt)\b[^.?!\n]{0,30}\bfirst\b",
    r"\b(?:think|pause) (?:here|first|about it)\b",
]
# chrome.json strings shown only in a practice mode or in the optional check placed after the explanation.
# Each entry names where it appears; anything not listed here is default text and must hold no barrier.
PRACTICE_ONLY = {
    "qa_choose": "legend of the options: the Q&A's optional self-check after the last layer, and the IVE practice-mode options",
    "ive_ask_hint": "IVE, shown only while the film is stopped in practice mode (mode 'ask')",
    "ive_mode_label_ask": "IVE mode label, only in practice mode (mode 'ask')",
    "ive_mode_ask": "IVE mode line, only in practice mode (mode 'ask')",
    "ive_your_pick": "IVE verdict line, only after a practice-mode pick",
    "card_print": "flashcards, a practice artifact the learner opens on purpose",
    "card_true_false": "flashcards, a practice artifact the learner opens on purpose",
}
# The no-JS notes are default text with no exemption: they must say what is shown, never to predict first.
NOSCRIPT_KEYS = ("qa_noscript", "s_noscript", "x_noscript", "noscript")


def _barriers(text, label="<text>"):
    low = text.lower()
    return [f"{label}: {m.group(0)!r} in {text!r}" for p in BARRIER for m in re.finditer(p, low)]


def _default_texts():
    """(label, text) for every default artifact string: lesson storyboard titles, question prompts, scene
    asks and narration; every chrome.json string not in PRACTICE_ONLY; the Q&A page's visible text."""
    from ptk import errors, model, text
    from ptk.project import qa
    out = []
    lessons = sorted(p.parent for p in (host.PKG.parent.parent / "lessons").glob("*/lesson.json"))
    for d in lessons:
        lesson = model.load(d)
        for sc in lesson.data["storyboard"]:
            out.append((f"{d.name}:{sc['id']}.title", sc["title"]))
            if sc.get("ask"):
                out.append((f"{d.name}:{sc['id']}.ask", sc["ask"]))
            if sc.get("question"):
                out.append((f"{d.name}:{sc['id']}.question", sc["question"]["prompt"]))
            out += [(f"{d.name}:{sc['id']}.{i}", n["text"]) for i, n in enumerate(sc["narration"])]
        try:
            m = qa.model(lesson)
        except errors.ModelReferenceError:  # a lesson with no question options has no Q&A page
            continue
        practice = re.compile(r'<section class="practice".*?</section>', re.S)
        body = practice.sub("", qa._body(lesson, m))
        visible = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", body))
        out.append((f"{d.name}:qa page (outside the optional check)", visible))
    for k, v in json.loads(text.CHROME.read_text())["strings"].items():
        if k not in PRACTICE_ONLY:
            out.append((f"chrome:{k}", v))
    return lessons, out


def test_no_prediction_barrier_in_default_artifacts():
    """SPEC v1.4 (FREEZE-v2 item 5, AC-1.3, AC-6.8): a complete explanation first. No default artifact text
    (storyboard titles and narration, the Q&A page, explorer and stepper notes, IVE default strings, no-JS
    text, chrome.json) tells the learner to predict, pick, choose or commit before the answer. Practice-only
    strings are allowed and listed in PRACTICE_ONLY. The lint first proves it catches the v2.1 leftovers."""
    caught = ["Predict", "Predict this step, then reveal it.",
              "Without JavaScript every layer is shown at once. Predict each one before you read it.",
              "Which answer do you predict? Pick one of the three before the answer plays.",
              "Pause here and predict the output before you go on.", "Answer the layer above first.",
              "Choose one, then commit."]
    for s in caught:
        assert _barriers(s), f"the lint missed: {s!r}"
    for s in ("The question", "The next scene answers this question.", "Check yourself (optional)",
              "Without JavaScript every layer and the answer key are shown at once."):
        assert not _barriers(s), _barriers(s)
    from ptk import text
    strings = json.loads(text.CHROME.read_text())["strings"]
    problems = [f"PRACTICE_ONLY names {k!r}, which chrome.json does not have" for k in PRACTICE_ONLY if k not in strings]
    problems += [f"no-JS key {k!r} is exempted" for k in NOSCRIPT_KEYS if k in PRACTICE_ONLY]
    problems += [f"no-JS key {k!r} missing from chrome.json" for k in NOSCRIPT_KEYS if k not in strings]
    lessons, texts = _default_texts()
    assert len(lessons) == 4, [d.name for d in lessons]
    for label, t in texts:
        problems += _barriers(t, label)
    assert not problems, problems
    return {"texts": len(texts), "lessons": len(lessons), "practice_only": sorted(PRACTICE_ONLY)}
